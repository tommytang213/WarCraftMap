#!/bin/bash
set -euo pipefail
sed -i 's@http://archive.ubuntu.com@https://archive.ubuntu.com@g; s@http://security.ubuntu.com@https://security.ubuntu.com@g' /etc/apt/sources.list.d/ubuntu.sources
apt-get update > /tmp/issue397-packages.log 2>&1
apt-get install -y --no-install-recommends python3 lua5.3 >> /tmp/issue397-packages.log 2>&1
mkdir -p /tmp/workspace /tmp/validation-results
tar --exclude=.git --exclude=_build --exclude=__pycache__ -C /source -cf - . | tar -C /tmp/workspace -xf -
chown -R wurstuser:wurstuser /tmp/workspace /tmp/validation-results
su -s /bin/bash wurstuser -c 'export PATH=/home/wurstuser/.wurst:/usr/local/bin:/usr/bin:/bin; export PYTHONDONTWRITEBYTECODE=1; python3 -u /source/_build/issue-397/revalidation/validate-candidate.py'
