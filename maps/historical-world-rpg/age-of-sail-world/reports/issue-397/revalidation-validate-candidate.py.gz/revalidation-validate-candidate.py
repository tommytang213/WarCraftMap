"""Developer validation only; invokes unchanged release gates on private copies."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/tmp/workspace')
PROJECT = ROOT / 'maps/historical-world-rpg/age-of-sail-world'
OUT = Path('/tmp/validation-results')
sys.path[:0] = [str(PROJECT / 'tooling'), str(PROJECT.parent / '_shared/tooling')]
import package_release_candidate as candidate
import runtime_acceptance
import release_blocker_audit
from integration_evidence import source_identity
from package_wurst_campaign import _inspect_physical_map
from warcraft_campaign import MpqReader
from warcraft_lua_startup import startup_failures
from warcraft_map_info import parse_w3i
from warcraft_map_units import validate_units

revision = os.environ['SOURCE_REVISION']
identity = source_identity(PROJECT, revision)
campaign_config = candidate.load_campaign_config(PROJECT / 'physical-maps.json')
original_build = candidate.build_campaign
builds = []

def retain_build(*args, **kwargs):
    archive = original_build(*args, **kwargs)
    index = len(builds) + 1
    shutil.copyfile(archive, OUT / f'campaign-{index}.w3n')
    for name in ('results.json', 'execution.log'):
        shutil.copyfile(PROJECT / '_build/wurst-tests' / name, OUT / f'wurst-{index}-{name}')
    builds.append(hashlib.sha256(archive.read_bytes()).hexdigest())
    print(f'Retained clean build {index}: {builds[-1]}', flush=True)
    return archive

# Observe the two real clean builds without changing any production gate.
candidate.build_campaign = retain_build
publication = 'ready'
try:
    candidate.build_release_candidate(revision=revision)
except candidate.CandidatePublicationBlocked as error:
    publication = 'blocked'
    print(f'Expected publication block: {error}', flush=True)
assert len(builds) == 2
assert source_identity(PROJECT, revision) == identity
assert not (PROJECT / '_build/release/AgeOfSailWorld-phase9-rc1.zip').exists()
for suffix in ('.json', '.md'):
    shutil.copyfile(PROJECT / f'_build/release/requirement-traceability{suffix}', OUT / f'requirement-traceability{suffix}')

campaign = OUT / 'campaign-2.w3n'
reader = MpqReader(campaign)
rows = []
for physical in campaign_config.maps:
    path = OUT / f'{physical.id}.w3x'
    payload = reader.read(physical.package_path)
    path.write_bytes(payload)
    _inspect_physical_map(physical, path)
    nested = MpqReader(path)
    script = nested.read('war3map.lua')
    (OUT / 'syntax.lua').write_bytes(script)
    subprocess.run(['luac5.3', '-p', str(OUT / 'syntax.lua')], check=True)
    assert not startup_failures(script)
    info = parse_w3i(nested.read('war3map.w3i'))
    placements = validate_units(nested.read('war3mapUnits.doo'))
    assert json.loads(nested.read('runtime/build-identity.json')) == identity
    assert 'war3map.j' not in nested.members()
    rows.append({'id': physical.id, 'bootstrap': physical.bootstrap,
                 'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload),
                 'luaBytes': len(script), 'unitRecords': len(placements),
                 'memberCount': len(nested.members()), 'w3iFormat': info['format'],
                 'gameVersion': info['gameVersion'], 'scriptLanguage': info['scriptLanguage'],
                 'archiveInspection': 'pass', 'lua53Syntax': 'pass', 'retailExecution': 'not_run'})
(OUT / 'syntax.lua').unlink()
(OUT / 'map-inspection.json').write_text(json.dumps({'status': 'pass',
    'evidenceLevel': 'static_archive_inspection_and_lua_5_3_syntax',
    'retailExecution': 'not_run', 'sourceIdentity': identity, 'maps': rows}, indent=2) + '\n')

execution = json.loads((OUT / 'wurst-2-results.json').read_text())
log = (OUT / 'wurst-2-execution.log').read_bytes()
runtime = runtime_acceptance.audit_acceptance(execution=execution, execution_log=log,
                                             revision=revision, campaign=campaign)
blocker = release_blocker_audit.build_report(execution=execution, execution_log=log,
                                           revision=revision, campaign=campaign)
assert runtime['status'] == blocker['status'] == 'pass'
for name, report in (('runtime-acceptance', runtime), ('release-blocker', blocker)):
    (OUT / f'{name}.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
subprocess.run([sys.executable, str(PROJECT.parent / '_shared/tooling/validate_framework_fixture.py'),
                str(PROJECT.parent / 'conformance-campaign')], check=True)
shutil.copyfile(PROJECT.parent / 'conformance-campaign/_build/conformance-report.json', OUT / 'framework-conformance.json')
(OUT / 'summary.json').write_text(json.dumps({'status': 'pass', 'publication': publication,
    'sourceIdentity': identity, 'buildSha256': builds, 'wholeArchiveByteEquality': builds[0] == builds[1],
    'normalizedDeterminism': 'pass', 'mapsInspected': len(rows),
    'runtimeAcceptance': runtime['status'], 'releaseBlockerAudit': blocker['status'],
    'retailExecution': 'not_run'}, indent=2) + '\n')
print('Validation complete; no player candidate published and no retail execution claimed.', flush=True)
