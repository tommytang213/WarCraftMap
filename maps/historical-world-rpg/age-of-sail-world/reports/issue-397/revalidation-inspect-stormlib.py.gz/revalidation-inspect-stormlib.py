"""Independent MPQ read comparison; does not execute Warcraft or Lua."""
import ctypes as C
import ctypes.util
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, '/tmp/workspace/maps/historical-world-rpg/_shared/tooling')
from warcraft_campaign import MpqReader

library = ctypes.util.find_library('storm')
assert library, 'StormLib unavailable'
storm = C.CDLL(library)
handle, dword = C.c_void_p, C.c_uint32

def api(name, result, *arguments):
    function = getattr(storm, name)
    function.restype, function.argtypes = result, arguments
    return function

open_archive = api('SFileOpenArchive', C.c_bool, C.c_char_p, dword, dword, C.POINTER(handle))
close_archive = api('SFileCloseArchive', C.c_bool, handle)
open_file = api('SFileOpenFileEx', C.c_bool, handle, C.c_char_p, dword, C.POINTER(handle))
close_file = api('SFileCloseFile', C.c_bool, handle)
size_file = api('SFileGetFileSize', dword, handle, C.POINTER(dword))
read_file = api('SFileReadFile', C.c_bool, handle, C.c_void_p, dword, C.POINTER(dword), C.c_void_p)

def compare(path, nested_root=None):
    archive = handle()
    assert open_archive(str(path).encode(), 0, 0x100, C.byref(archive)), f'StormLib cannot open {path}'
    nested = []
    try:
        members = MpqReader(path).members()  # also enforces complete hash-table coverage
        for name, expected in members.items():
            file = handle()
            assert open_file(archive, name.replace('/', '\\').encode(), 0, C.byref(file)), name
            try:
                high = dword()
                size = size_file(file, C.byref(high))
                assert not high.value and size == len(expected), name
                buffer, read = C.create_string_buffer(size), dword()
                if size:
                    assert read_file(file, buffer, size, C.byref(read), None) and read.value == size, name
                actual = buffer.raw[:size]
                assert actual == expected, f'Independent reader disagreement: {name}'
                if name.endswith('.w3x') and nested_root is not None:
                    child = nested_root / Path(name).name
                    child.write_bytes(actual)
                    nested.append(compare(child))
            finally:
                assert close_file(file)
        return {'archive': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'membersCompared': len(members), 'status': 'pass', 'nested': nested}
    finally:
        assert close_archive(archive)

with tempfile.TemporaryDirectory(prefix='issue397-stormlib-') as directory:
    result = compare(Path(sys.argv[1]), Path(directory))
version = subprocess.check_output(['dpkg-query', '-W', '-f=${Version}', 'libstorm9'], text=True)
report = {'status': 'pass', 'reader': 'StormLib', 'version': version,
          'evidenceLevel': 'independent_archive_reader', 'retailExecution': 'not_run',
          'campaign': result}
Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + '\n')
print(f'StormLib {version}: byte-for-byte member agreement for the campaign and {len(result["nested"])} nested maps; retail not executed.')
