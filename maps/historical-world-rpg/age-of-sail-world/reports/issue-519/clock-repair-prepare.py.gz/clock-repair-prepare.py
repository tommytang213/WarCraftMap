import hashlib,json,re,sys,tempfile
from pathlib import Path
project=Path.cwd()/'maps/historical-world-rpg/age-of-sail-world'
sys.path.insert(0,str(project.parent/'_shared/tooling'))
from package_wurst_map import load_config,generate,verify_generated,_assemble
from wurst_execution import discover,PINNED_COMPILER_SHA256
root=Path(tempfile.mkdtemp(prefix='issue519-clock-repair-'))
root.chmod(0o755)
config=load_config(project/'package.json')
generate(config,root/'generated')
verify_generated(config,root/'generated')
compiled=_assemble(config,root,root/'generated')
selected={'ArmyFoodLogisticsTests.wurst','IndustryTests.wurst','TradeFinanceTests.wurst','LandArmyEffectsTests.wurst','CampaignLoadTransactionTests.wurst','WC3CompatibilityCompileFixture.wurst','MilitarySettlementRuntimeTests.wurst','RemoteRegionAuthorityTests.wurst','CampaignStartupTests.wurst'}
# Retain every regression whose existing @test body changed with the schema bump.
import subprocess
for path in (compiled/'wurst').glob('*.wurst'):
 if path.name in selected:
  continue
 text=path.read_text()
 original_path=project/'wurst'/path.name
 tracked=subprocess.run(['git','show','HEAD:'+str(original_path.relative_to(Path.cwd()))],text=True,capture_output=True)
 before=tracked.stdout if tracked.returncode==0 else ''
 unmodified=text
 matches=list(re.finditer(r'@test\s+function (\w+)\(\)',text))
 for match in reversed(matches):
  end=unmodified.find('\n@test',match.end())
  if end<0:end=len(unmodified)
  block=unmodified[match.start():end]
  name=match[1]
  old=re.search(r'@test\s+function '+re.escape(name)+r'\(\)',before)
  old_end=before.find('\n@test',old.end()) if old else -1
  old_block=before[old.start():old_end if old_end>=0 else len(before)] if old else ''
  keep=old is not None and block!=old_block
  if path.name=='MilitaryCombatEventsTests.wurst' and name.startswith('castCannon'):
   keep=True
  if not keep:
   text=text[:match.start()]+text[match.start():].replace('@test','',1)
 path.write_text(text)
from integration_evidence import instrument_tree,load_contract
instrument_tree(compiled, load_contract(project))
expected=discover(compiled)
(root/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
inputs={p.relative_to(compiled).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((compiled/'wurst').rglob('*.wurst'))}
(root/'inputs.sha256').write_text(''.join(f'{v}  {k}\n' for k,v in inputs.items()))
(root/'run.sh').write_text('''set -eu
export JAVA_TOOL_OPTIONS=-Xmx8g
cp -R /source/compile /tmp/compile
cd /tmp/compile
printf '%s  /home/wurstuser/.wurst/wurst-compiler/wurstscript.jar\\n' 'COMPILER_HASH' | sha256sum -c -
sha256sum -c /source/inputs.sha256 > /tmp/inputs.log
mkdir -p _build/dependencies /tmp/core
cp -R /stdlib _build/dependencies/WurstStdlib2
printf '%s\\n' /tmp/compile/_build/dependencies/WurstStdlib2 > wurst.dependencies
(cd /tmp/core && jar xf /home/wurstuser/.wurst/grill-cli/grill.jar core-jass/v3.0/common.j core-jass/v3.0/blizzard.j)
cp /tmp/core/core-jass/v3.0/common.j _build/common.j
cp /tmp/core/core-jass/v3.0/blizzard.j _build/blizzard.j
grill typecheck
grill test
sha256sum -c /source/inputs.sha256 >> /tmp/inputs.log
'''.replace('COMPILER_HASH',PINNED_COMPILER_SHA256))
Path('/tmp/issue519-clock-repair-path').write_text(str(root))
print(json.dumps(dict(path=str(root),tests=len(expected))))
