import hashlib,json,re,sys,tempfile
from pathlib import Path
project=Path.cwd()/'maps/historical-world-rpg/age-of-sail-world'
sys.path.insert(0,str(project.parent/'_shared/tooling'))
from package_wurst_map import load_config,generate,verify_generated,_assemble
from wurst_execution import discover,PINNED_COMPILER_SHA256
root=Path.cwd()/'_build/issue519-ci/wurst'
root.mkdir(parents=True, exist_ok=True)
root.chmod(0o755)
config=load_config(project/'package.json')
generate(config,root/'generated')
verify_generated(config,root/'generated')
compiled=_assemble(config,root,root/'generated')
selected={'ArmyFoodLogisticsTests.wurst','IndustryTests.wurst','TradeFinanceTests.wurst','LandArmyEffectsTests.wurst','WC3CompatibilityCompileFixture.wurst'}
# Retain every regression whose existing @test body changed with the schema bump.
import subprocess
for path in (compiled/'wurst').glob('*.wurst'):
 if path.name in selected:
  continue
 text=path.read_text()
 original_path=project/'wurst'/path.name
 tracked=subprocess.run(['git','show','HEAD:'+str(original_path.relative_to(Path.cwd()))],text=True,capture_output=True)
 before=tracked.stdout if tracked.returncode==0 else ''
 matches=list(re.finditer(r'@test\s+function (\w+)\(\)',text))
 for match in reversed(matches):
  name=match[1]
  keep=path.name=='MilitaryCombatEventsTests.wurst' and (name.startswith('legacyMilitaryIntegerVersion') or name.startswith('castCannon'))
  if not keep:
   text=text[:match.start()]+text[match.start():].replace('@test','',1)
 path.write_text(text)
from integration_evidence import instrument_tree,load_contract
instrument_tree(compiled, load_contract(project))
expected=discover(compiled)
(root/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
inputs={p.relative_to(compiled).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((compiled/'wurst').rglob('*.wurst'))}
(root/'inputs.sha256').write_text(''.join(f'{v}  {k}\n' for k,v in inputs.items()))
(root/'run.sh').write_text('''set -eu
export JAVA_TOOL_OPTIONS=-Xmx8g
cp -R /source/compile /tmp/compile
cd /tmp/compile
printf '%s  /home/wurstuser/.wurst/wurst-compiler/wurstscript.jar\\n' 'COMPILER_HASH' | sha256sum -c -
sha256sum -c /source/inputs.sha256 > /tmp/inputs.log
mkdir -p _build/dependencies /tmp/core
cp -R /stdlib _build/dependencies/WurstStdlib2
printf '%s\\n' /tmp/compile/_build/dependencies/WurstStdlib2 > wurst.dependencies
(cd /tmp/core && jar xf /home/wurstuser/.wurst/grill-cli/grill.jar core-jass/v3.0/common.j core-jass/v3.0/blizzard.j)
cp /tmp/core/core-jass/v3.0/common.j _build/common.j
cp /tmp/core/core-jass/v3.0/blizzard.j _build/blizzard.j
grill typecheck
grill test
sha256sum -c /source/inputs.sha256 >> /tmp/inputs.log
'''.replace('COMPILER_HASH',PINNED_COMPILER_SHA256))

print(json.dumps(dict(path=str(root),tests=len(expected))))
