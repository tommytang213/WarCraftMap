"""Finish the exact unittest discovery after a bounded repository preflight."""
from pathlib import Path
import json,re,sys,time,unittest

project=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(project.parent/'_shared/tooling'))
from integration_evidence import source_identity
from wurst_execution import source_revision
identity=source_identity(project,source_revision(project))
log=(project/'_build/issue463-repair-repository.log').read_text()
progress=log.splitlines()[-1]
assert progress and set(progress)=={'.'}, 'preflight did not end in successful unittest progress'
assert len(re.findall(r'(?m)^\.+$',log))==1, 'ambiguous preflight progress'
completed=len(progress)

def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite): yield from flatten(item)
        else: yield item

tests=list(flatten(unittest.defaultTestLoader.discover(str(project/'tests'),pattern='test_*.py')))
assert completed<len(tests)
rows=[dict(id=test.id(),status='pass',stage='bounded_repository_preflight') for test in tests[:completed]]
print(f'Preflight passed {completed}/{len(tests)} tests before its 900-second limit.',flush=True)
print('Resuming with '+tests[completed].id(),flush=True)

class Result(unittest.TextTestResult):
    def startTest(self,test):
        self.started=time.monotonic()
        super().startTest(test)
    def record(self,test,status):
        rows.append(dict(id=test.id(),status=status,stage='continuation',seconds=round(time.monotonic()-self.started,3)))
    def addSuccess(self,test):
        self.record(test,'pass'); super().addSuccess(test)
    def addError(self,test,error):
        self.record(test,'error'); super().addError(test,error)
    def addFailure(self,test,error):
        self.record(test,'failure'); super().addFailure(test,error)
    def addSkip(self,test,reason):
        self.record(test,'skip'); super().addSkip(test,reason)
    def addSubTest(self,test,subtest,error):
        if error is not None: self.record(test,'subtest_failure')
        super().addSubTest(test,subtest,error)

start=time.monotonic()
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(unittest.TestSuite(tests[completed:]))
report=dict(sourceIdentity=identity,discovered=len(tests),preflight=dict(exitCode=124,timeLimitSeconds=900,passed=completed),
            continuation=dict(testsRun=result.testsRun,seconds=round(time.monotonic()-start,3)),tests=rows,
            status='pass' if result.wasSuccessful() and len(rows)==len(tests) and all(r['status']=='pass' for r in rows) else 'fail')
assert source_identity(project,source_revision(project))==identity
(project/'_build/issue463-repair-python-results.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print('Combined scenario Python results: '+report['status']+f'; {len(rows)}/{len(tests)} results',flush=True)
sys.exit(0 if report['status']=='pass' else 1)
