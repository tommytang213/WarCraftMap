from pathlib import Path
import json,shutil,sys
project=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(project.parent/'_shared/tooling'))
import package_wurst_map as maps
from integration_evidence import source_identity
original_run=maps._run
def logged_run(stage, command, cwd):
    print('START: '+stage, flush=True)
    original_run(stage, command, cwd)
    print('PASS: '+stage, flush=True)
maps._run=logged_run
config=maps.load_config(project/'package.json')
executable=maps.validate_inputs(config,str(project/'_build/issue463-tools/bin/grill'))
revision=maps.source_revision(project); identity=source_identity(project,revision)
maps.validate_scenario(config)
root=project/'_build/issue463-ci-map'; generated=root/'generated'
maps.generate(config,generated);maps.verify_generated(config,generated)
compile_root=maps._assemble(config,root,generated)
(compile_root/'map'/config.source_map.name/'runtime/build-identity.json').write_text(json.dumps(identity,sort_keys=True)+'\n')
maps._run('Wurst dependency installation',[executable,'install'],compile_root)
maps._run('Wurst compilation',[executable,'typecheck'],compile_root)
print('START: pinned Wurst execution', flush=True)
maps.execute_tests(compile_root,executable,root/'execution',revision,project=config.project)
maps._run('map assembly',[executable,'build',str(Path('map')/config.source_map.name)],compile_root)
archive=maps._find_archive(compile_root/'_build');maps._inspect(config,archive,compile_root)
assert source_identity(project,revision)==identity,'source changed during validation'
config.output.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(archive,config.output)
print(f'PASS: full pinned suite, typecheck and archive inspection: {config.output}')
