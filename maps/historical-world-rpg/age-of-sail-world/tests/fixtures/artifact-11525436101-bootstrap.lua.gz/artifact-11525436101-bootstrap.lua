__wurst_objectClass = ({})
__wurst_objectFree = ({})
__wurst_objectMax = 0
__wurst_objectFreeCount = 0

function __wurst_deallocObject(object) 
	local descriptor = __wurst_objectClass[object]
	if (descriptor == nil) then
		error("Double free or invalid Wurst object.")
	end
	local wurstExpr = (descriptor.__wurst_dealloc)(object)
	__wurst_objectClass[object] = nil
	__wurst_objectFreeCount = (__wurst_objectFreeCount + 1)
	__wurst_objectFree[__wurst_objectFreeCount] = object
end

function __wurst_classToIndex(object) 
	if (object == nil) then
		return 0
	end
	return object
end

function __wurst_classFromIndex(index) 
	if (index == 0) then
		return nil
	end
	return index
end

function isInstanceOf(x, A) 
	return x ~= nil and __wurst_objectClass[x] ~= nil and __wurst_objectClass[x].__wurst_supertypes[A]
end

__wurst_objectIndexMap = nil
__wurst_number_wrapper_map = nil

function __wurst_objectToIndex(x) 
	if x == nil then
	    return 0
	end
	if type(x) == "number" then
	    if __wurst_number_wrapper_map[x] then
	        x = __wurst_number_wrapper_map[x]
	    else
	        local obj = {__wurst_boxed_number = x}
	        __wurst_number_wrapper_map[x] = obj
	        x = obj
	    end
	end
	if __wurst_objectIndexMap[x] then
	    return __wurst_objectIndexMap[x]
	else
	   local r = __wurst_objectIndexMap.counter + 1
	   __wurst_objectIndexMap.counter = r
	   __wurst_objectIndexMap[r] = x
	   __wurst_objectIndexMap[x] = r
	   return r
	end
end

function __wurst_objectFromIndex(x) 
	if type(x) == "number" then
	    x = __wurst_objectIndexMap[x]
	end
	if type(x) == "table" and x.__wurst_boxed_number then
	    return x.__wurst_boxed_number
	end
	return x
end

__wurst_string_index_map = nil

function __wurst_stringToIndex(x) 
	if x == nil then
	    return 0
	end
	if type(x) ~= "string" then
	    x = tostring(x)
	end
	local id = __wurst_string_index_map.byString[x]
	if id ~= nil then
	    return id
	end
	id = __wurst_string_index_map.counter + 1
	__wurst_string_index_map.counter = id
	__wurst_string_index_map.byString[x] = id
	__wurst_string_index_map.byIndex[id] = x
	return id
end

function __wurst_stringFromIndex(x) 
	local id = tonumber(x)
	if id == nil then
	    return ""
	end
	id = math.tointeger(id)
	if id == nil then
	    return ""
	end
	local s = __wurst_string_index_map.byIndex[id]
	if s == nil then
	    return ""
	end
	return s
end

Basics_ANIMATION_PERIOD = nil
Bootstrap_bootstrapOriginSelection = nil
CampaignHandoff_HANDOFF_REQUEST = nil
Colors_hexs = nil

function __wurst_arrIndex_string(t, k) 
	return ""
end

__wurst_arrMt_string = ({__index=__wurst_arrIndex_string, })
Colors_decs = nil
Colors_COLOR_WHITE_red = nil
Colors_COLOR_WHITE_green = nil
Colors_COLOR_WHITE_blue = nil
Colors_COLOR_WHITE_alpha = nil
Colors_COLOR_BLACK_red = nil
Colors_COLOR_BLACK_green = nil
Colors_COLOR_BLACK_blue = nil
Colors_COLOR_BLACK_alpha = nil
Colors_COLOR_GOLD_red = nil
Colors_COLOR_GOLD_green = nil
Colors_COLOR_GOLD_blue = nil
Colors_COLOR_GOLD_alpha = nil
CommandRouter_COMMAND_RELEASE = nil
CommandRouter_active = nil
CommandRouter_chatNatives = nil
CommandRouter_chatListener = nil
ErrorHandling_MUTE_ERROR_DURATION = nil
ErrorHandling_PRIMARY_ERROR_KEY = nil
ErrorHandling_HT = nil
ErrorHandling_suppressErrorMessages = nil
ErrorHandling_errorListeners = nil
ErrorHandling_errorListenerCount = nil
ErrorHandling_notifyingErrorListeners = nil
ErrorHandling_notifiedListener = nil
ErrorHandling_notifiedMessage = nil
ErrorHandling_errorListenerForce = nil
GameTimer_currentTime = nil
MagicFunctions_compiletime = nil
Player_localPlayer = nil
Printing_DEBUG_LEVEL = nil
Printing_DEBUG_MSG_DURATION = nil
ScenarioSettings_CAMPAIGN_CACHE_FILE = nil
ScenarioSettings_SCENARIO_BOOTSTRAP_MESSAGE = nil
String_CONT_BYTE_PROBE = nil
String_CONT_BYTE_MAP = nil
String_charset = nil
String_charsetlength = nil
String_PRINTABLE_ASCII = nil
String_CHAR_ORDER_MAP = nil
String_NON_CHARSET_ORDER_BASE = nil
Table_ht = nil
TypeCasting_typecastdata = nil
WC3Compatibility_WC3_COMPAT_PATCH_FAMILY = nil
WC3Compatibility_WC3_COMPAT_SCRIPT_BACKEND = nil
WC3Compatibility_WC3_HAS_MODERN_INVENTORY = nil
WC3Compatibility_WC3_HAS_NATIVE_SAVE_MANAGEMENT = nil
WC3Compatibility_WC3_HAS_FRAME_UI = nil
WC3Compatibility_WC3_HAS_PATHING_QUERIES = nil
WC3Compatibility_WC3_HAS_MODERN_UNIT_FIELDS = nil
hashtable_compiletime = nil
hashtable_compiletime1 = nil
wurst_stack_depth = nil
wurst_stack = nil
CampaignHandoff_storage_storage = ({})
CampaignHandoff_loader_storage = ({})
CampaignStartRequest_sequence_storage = ({})
CampaignStartRequest_status_storage = ({})
CampaignStartRequest_origin_storage = ({})
CampaignStartRequest_mapId_storage = ({})
CampaignStartRequest_instanceId_storage = ({})
CampaignStartRequest_settlementId_storage = ({})
WarcraftCampaignSaveStorage_cache_storage = ({})
WarcraftCampaignSaveStorage_mission_storage = ({})
Command_name_storage = ({})
Command_aliases_storage = ({})
Command_usage_storage = ({})
Command_summary_storage = ({})
Command_details_storage = ({})
Command_minimum_storage = ({})
Command_maximum_storage = ({})
Command_visibility_storage = ({})
Command_handler_storage = ({})
CommandRegistry_commands_storage = ({})
CommandRegistry_size_storage = ({})
CommandRegistry_debug_storage = ({})
CommandRegistry_pageSize_storage = ({})
CommandRegistry_text_storage = ({})
CommandRegistry_output_storage = ({})
CommandText_heading_storage = ({})
CommandText_invalidPage_storage = ({})
CommandText_unknownTopic_storage = ({})
CommandText_malformedHelp_storage = ({})
CommandText_unavailable_storage = ({})
CommandText_unknown_storage = ({})
CommandText_invalidArguments_storage = ({})
CommandText_conflict_storage = ({})
NewCampaignOriginController_pageSize_storage = ({})
NewCampaignOriginController_query_storage = ({})
NewCampaignOriginController_presentation_storage = ({})
NewCampaignOriginController_identity_storage = ({})
NewCampaignOriginController_observer_storage = ({})
OriginCatalog_definitions_storage = ({})
OriginCatalog_count_storage = ({})
OriginCommandHandler_controller_storage = ({})
OriginDefinition_polityId_storage = ({})
OriginDefinition_name_storage = ({})
OriginDefinition_physicalMapId_storage = ({})
OriginDefinition_packagePath_storage = ({})
OriginDefinition_regionalInstanceId_storage = ({})
OriginDefinition_settlementId_storage = ({})
PlayerCampaignIdentity_originPolityId_storage = ({})
CampaignHandoff = ({})
CampaignStartRequest = ({})
PhysicalMapLoader = ({})
WarcraftPhysicalMapLoader = ({})
CampaignSaveStorage = ({})
WarcraftCampaignSaveStorage = ({})
Command = ({})
CommandChatNatives = ({})
CommandHandler = ({})
CommandOutput = ({})
CommandRegistry = ({})
CommandText = ({})
NewCampaignOriginController = ({})
OriginCatalog = ({})
OriginCommandHandler = ({})
OriginDefinition = ({})
OriginSelectionObserver = ({})
OriginSelectionPresentation = ({})
PlayerCampaignIdentity = ({})
WarcraftCommandChatNatives = ({})
WarcraftOriginPresentation = ({})
WarcraftOutput = ({})
ErrorListener = ({})
Table = ({})

function CampaignHandoff:create() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CampaignHandoff
	CampaignHandoff_storage_storage[new_inst] = nil
	CampaignHandoff_loader_storage[new_inst] = nil
	return new_inst
end

function CampaignHandoff_dealloc(object) 
end

function dispatch_CampaignSaveStorage_writeTransactional(receiver, ...) 
	return (__wurst_objectClass[receiver].CampaignSaveStorage_writeTransactional)(receiver, ...)
end

function CampaignHandoff_CampaignHandoff_commitSelection(this, polityId, physicalMapId, regionalInstanceId, settlementId, __wurst_stackPos) 
	local sequence = nil
	local previous = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos
	wurst_stack_depth = (wurst_stack_depth + 1)
	sequence = 1
	previous = CampaignHandoff_CampaignHandoff_readRequest(this, "when calling readRequest in CampaignHandoff, line 77")
	if not((previous == nil)) then
		sequence = (CampaignStartRequest_sequence_storage[previous] + 1)
	end
	if (sequence <= 0) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	previous = CampaignStartRequest_new_CampaignStartRequest(sequence, "pending", polityId, physicalMapId, regionalInstanceId, settlementId, "when calling new_CampaignStartRequest in CampaignHandoff, line 82")
	wurst_stack_depth = (wurst_stack_depth - 1)
	return dispatch_CampaignSaveStorage_writeTransactional(CampaignHandoff_storage_storage[this], CampaignHandoff_HANDOFF_REQUEST, CampaignStartRequest_CampaignStartRequest_encode(previous, "when calling encode in CampaignHandoff, line 83"), "when calling writeTransactional in CampaignHandoff, line 83")
end

function dispatch_PhysicalMapLoader_load(receiver, ...) 
	return (__wurst_objectClass[receiver].PhysicalMapLoader_load)(receiver, ...)
end

function CampaignHandoff_CampaignHandoff_campaignStarted(this3, polityId1, physicalMapId1, packagePath, regionalInstanceId1, settlementId2, __wurst_stackPos4) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos4
	wurst_stack_depth = (wurst_stack_depth + 1)
	dispatch_PhysicalMapLoader_load(CampaignHandoff_loader_storage[this3], packagePath, "when calling load in CampaignHandoff, line 85")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function dispatch_CampaignSaveStorage_contains(receiver, ...) 
	return (__wurst_objectClass[receiver].CampaignSaveStorage_contains)(receiver, ...)
end

function CampaignHandoff_CampaignHandoff_hasRequest(this4, __wurst_stackPos5) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos5
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	return ((((dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this4], CampaignHandoff_HANDOFF_REQUEST, "when calling contains in CampaignHandoff, line 66") or dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this4], "origin", "when calling contains in CampaignHandoff, line 66")) or dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this4], "map", "when calling contains in CampaignHandoff, line 66")) or dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this4], "instance", "when calling contains in CampaignHandoff, line 66")) or dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this4], "settlement", "when calling contains in CampaignHandoff, line 66"))
end

function dispatch_CampaignSaveStorage_read(receiver, ...) 
	return (__wurst_objectClass[receiver].CampaignSaveStorage_read)(receiver, ...)
end

function CampaignHandoff_CampaignHandoff_readRequest(this1, __wurst_stackPos1) 
	local value = nil
	local fields = setmetatable(({}), __wurst_arrMt_string)
	local start = nil
	local count = nil
	local i = nil
	local temp = nil
	local stackTrace_tempReturn = nil
	local inlineDone = nil
	local inlineRet = nil
	local andLeft4 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos1
	wurst_stack_depth = (wurst_stack_depth + 1)
	if dispatch_CampaignSaveStorage_contains(CampaignHandoff_storage_storage[this1], CampaignHandoff_HANDOFF_REQUEST, "when calling contains in CampaignHandoff, line 68") then
		value = dispatch_CampaignSaveStorage_read(CampaignHandoff_storage_storage[this1], CampaignHandoff_HANDOFF_REQUEST, "when calling read in CampaignHandoff, line 69")
		inlineDone = false
		wurst_stack[wurst_stack_depth] = "when calling decodeCampaignStartRequest in CampaignHandoff, line 69"
		wurst_stack_depth = (wurst_stack_depth + 1)
		start = 0
		count = 0
		i = 0
		temp = StringLength(value)
		while true do
			if (inlineDone or (not(inlineDone) and (i > temp))) then
				break
			end
			if not(inlineDone) then
				if ((i == StringLength(value)) or (SubString(value, i, (i + 1)) == "|")) then
					if not(inlineDone) then
						if ((count >= 7) or (start == i)) then
							if not(inlineDone) then
								wurst_stack_depth = (wurst_stack_depth - 1)
							end
							if not(inlineDone) then
								inlineRet = nil
								inlineDone = true
							end
						end
					end
					if not(inlineDone) then
						fields[count] = SubString(value, start, i)
					end
					if not(inlineDone) then
						count = (count + 1)
					end
					if not(inlineDone) then
						start = (i + 1)
					end
				end
			end
			if not(inlineDone) then
				i = (i + 1)
			end
		end
		if not(inlineDone) then
			if ((not((count == 7)) or not((fields[0] == "v1"))) or (S2I(fields[1]) <= 0)) then
				andLeft4 = true
			else
				start = S2I(fields[1])
				wurst_stack[wurst_stack_depth] = "when calling toString in CampaignHandoff, line 53"
				wurst_stack_depth = (wurst_stack_depth + 1)
				value = tostring(start)
				wurst_stack_depth = (wurst_stack_depth - 1)
				andLeft4 = not((value == fields[1]))
			end
			if (andLeft4 or (not((fields[2] == "pending")) and not((fields[2] == "consumed")))) then
				if not(inlineDone) then
					wurst_stack_depth = (wurst_stack_depth - 1)
				end
				if not(inlineDone) then
					inlineRet = nil
					inlineDone = true
				end
			end
		end
		if not(inlineDone) then
			stackTrace_tempReturn = CampaignStartRequest_new_CampaignStartRequest(S2I(fields[1]), fields[2], fields[3], fields[4], fields[5], fields[6], "when calling new_CampaignStartRequest in CampaignHandoff, line 55")
		end
		if not(inlineDone) then
			wurst_stack_depth = (wurst_stack_depth - 1)
		end
		if not(inlineDone) then
			inlineRet = stackTrace_tempReturn
			inlineDone = true
		end
		if not(inlineDone) then
			inlineRet = 0
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		return inlineRet
	end
	if CampaignHandoff_CampaignHandoff_hasRequest(this1, "when calling hasRequest in CampaignHandoff, line 72") then
		stackTrace_tempReturn = CampaignStartRequest_new_CampaignStartRequest(1, "pending", dispatch_CampaignSaveStorage_read(CampaignHandoff_storage_storage[this1], "origin", "when calling read in CampaignHandoff, line 73"), dispatch_CampaignSaveStorage_read(CampaignHandoff_storage_storage[this1], "map", "when calling read in CampaignHandoff, line 73"), dispatch_CampaignSaveStorage_read(CampaignHandoff_storage_storage[this1], "instance", "when calling read in CampaignHandoff, line 73"), dispatch_CampaignSaveStorage_read(CampaignHandoff_storage_storage[this1], "settlement", "when calling read in CampaignHandoff, line 73"), "when calling new_CampaignStartRequest in CampaignHandoff, line 73")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return stackTrace_tempReturn
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return nil
end

function CampaignStartRequest:create1() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CampaignStartRequest
	CampaignStartRequest_sequence_storage[new_inst] = 0
	CampaignStartRequest_status_storage[new_inst] = ""
	CampaignStartRequest_origin_storage[new_inst] = ""
	CampaignStartRequest_mapId_storage[new_inst] = ""
	CampaignStartRequest_instanceId_storage[new_inst] = ""
	CampaignStartRequest_settlementId_storage[new_inst] = ""
	return new_inst
end

function CampaignStartRequest_dealloc(object) 
end

function CampaignStartRequest_CampaignStartRequest_encode(this2, __wurst_stackPos3) 
	local x = nil
	local y = nil
	local this5 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos3
	wurst_stack_depth = (wurst_stack_depth + 1)
	this5 = CampaignStartRequest_sequence_storage[this2]
	wurst_stack[wurst_stack_depth] = "when calling toString in CampaignHandoff, line 36"
	wurst_stack_depth = (wurst_stack_depth + 1)
	x = tostring(this5)
	wurst_stack_depth = (wurst_stack_depth - 1)
	x = __wurst_stringConcat(__wurst_stringConcat(__wurst_stringConcat(__wurst_stringConcat(__wurst_stringConcat(__wurst_stringConcat("v1|", x, "when calling __wurst_stringConcat"), "|", "when calling __wurst_stringConcat"), CampaignStartRequest_status_storage[this2], "when calling __wurst_stringConcat"), "|", "when calling __wurst_stringConcat"), CampaignStartRequest_origin_storage[this2], "when calling __wurst_stringConcat"), "|", "when calling __wurst_stringConcat")
	y = CampaignStartRequest_mapId_storage[this2]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x == nil)) then
		if not((y == nil)) then
			x = __wurst_rawConcat(x, y)
		end
	else
		x = y
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x == nil)) then
		if not(("|" == nil)) then
			x = __wurst_rawConcat(x, "|")
		end
	else
		x = "|"
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	y = CampaignStartRequest_instanceId_storage[this2]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x == nil)) then
		if not((y == nil)) then
			x = __wurst_rawConcat(x, y)
		end
	else
		x = y
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x == nil)) then
		if not(("|" == nil)) then
			x = __wurst_rawConcat(x, "|")
		end
	else
		x = "|"
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	y = CampaignStartRequest_settlementId_storage[this2]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x == nil)) then
		if not((y == nil)) then
			x = __wurst_rawConcat(x, y)
		end
	else
		x = y
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return x
end

function CampaignStartRequest_new_CampaignStartRequest(sequence1, status, origin, mapId, instanceId, settlementId1, __wurst_stackPos2) 
	local this6 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos2
	wurst_stack_depth = (wurst_stack_depth + 1)
	this6 = CampaignStartRequest:create1()
	wurst_stack[wurst_stack_depth] = "when calling construct_CampaignStartRequest in CampaignHandoff, line 28"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling CampaignStartRequest_init in CampaignHandoff, line 28"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	CampaignStartRequest_sequence_storage[this6] = sequence1
	CampaignStartRequest_status_storage[this6] = status
	CampaignStartRequest_origin_storage[this6] = origin
	CampaignStartRequest_mapId_storage[this6] = mapId
	CampaignStartRequest_instanceId_storage[this6] = instanceId
	CampaignStartRequest_settlementId_storage[this6] = settlementId1
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return this6
end

function PhysicalMapLoader:create2() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = PhysicalMapLoader
	return new_inst
end

function PhysicalMapLoader_dealloc(object) 
end

function PhysicalMapLoader_PhysicalMapLoader_load(this7, packagePath1, __wurst_stackPos7) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos7
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function WarcraftPhysicalMapLoader:create3() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = WarcraftPhysicalMapLoader
	return new_inst
end

function WarcraftPhysicalMapLoader_dealloc(object) 
end

function WarcraftPhysicalMapLoader_WarcraftPhysicalMapLoader_load(this8, packagePath2, __wurst_stackPos8) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos8
	wurst_stack_depth = (wurst_stack_depth + 1)
	compatLoadPhysicalMap(packagePath2, "when calling compatLoadPhysicalMap in CampaignHandoff, line 16")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function CampaignSaveStorage:create4() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CampaignSaveStorage
	return new_inst
end

function CampaignSaveStorage_dealloc(object) 
end

function CampaignSaveStorage_CampaignSaveStorage_contains(this9, slotId, __wurst_stackPos10) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos10
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CampaignSaveStorage_CampaignSaveStorage_read(this10, slotId1, __wurst_stackPos11) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos11
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CampaignSaveStorage_CampaignSaveStorage_writeTransactional(this11, slotId2, payload, __wurst_stackPos12) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos12
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function WarcraftCampaignSaveStorage:create5() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = WarcraftCampaignSaveStorage
	WarcraftCampaignSaveStorage_cache_storage[new_inst] = nil
	WarcraftCampaignSaveStorage_mission_storage[new_inst] = ""
	return new_inst
end

function WarcraftCampaignSaveStorage_dealloc(object) 
end

function WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains(this12, slotId3, __wurst_stackPos13) 
	local cache = nil
	local mission = nil
	local inlineDone1 = nil
	local inlineRet1 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos13
	wurst_stack_depth = (wurst_stack_depth + 1)
	cache = WarcraftCampaignSaveStorage_cache_storage[this12]
	mission = WarcraftCampaignSaveStorage_mission_storage[this12]
	wurst_stack[wurst_stack_depth] = "when calling compatHaveStoredString in CampaignSaveManager, line 191"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone1 = false
	if (cache == nil) then
		inlineRet1 = false
		inlineDone1 = true
	end
	if not(inlineDone1) then
		inlineRet1 = HaveStoredString(cache, mission, slotId3)
		inlineDone1 = true
	end
	if not(inlineDone1) then
		inlineRet1 = false
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return inlineRet1
end

function WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read(this13, slotId4, __wurst_stackPos14) 
	local cache1 = nil
	local mission1 = nil
	local inlineDone2 = nil
	local inlineRet2 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos14
	wurst_stack_depth = (wurst_stack_depth + 1)
	cache1 = WarcraftCampaignSaveStorage_cache_storage[this13]
	mission1 = WarcraftCampaignSaveStorage_mission_storage[this13]
	wurst_stack[wurst_stack_depth] = "when calling compatGetStoredString in CampaignSaveManager, line 194"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone2 = false
	if (cache1 == nil) then
		inlineRet2 = ""
		inlineDone2 = true
	end
	if not(inlineDone2) then
		inlineRet2 = GetStoredString(cache1, mission1, slotId4)
		inlineDone2 = true
	end
	if not(inlineDone2) then
		inlineRet2 = ""
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return inlineRet2
end

function WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_writeTransactional(this14, slotId5, payload1, __wurst_stackPos15) 
	local existed = nil
	local previous1 = nil
	local cache2 = nil
	local key1 = nil
	local value1 = nil
	local missionKey1 = nil
	local inlineDone3 = nil
	local inlineRet3 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos15
	wurst_stack_depth = (wurst_stack_depth + 1)
	existed = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains(this14, slotId5, "when calling contains in CampaignSaveManager, line 197")
	previous1 = ""
	if existed then
		previous1 = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read(this14, slotId5, "when calling read in CampaignSaveManager, line 200")
	end
	cache2 = WarcraftCampaignSaveStorage_cache_storage[this14]
	missionKey1 = WarcraftCampaignSaveStorage_mission_storage[this14]
	wurst_stack[wurst_stack_depth] = "when calling compatStoreString in CampaignSaveManager, line 201"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone3 = false
	if (cache2 == nil) then
		inlineDone3 = true
	end
	if not(inlineDone3) then
		StoreString(cache2, missionKey1, slotId5, payload1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	cache2 = WarcraftCampaignSaveStorage_cache_storage[this14]
	wurst_stack[wurst_stack_depth] = "when calling compatSaveGameCache in CampaignSaveManager, line 202"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone3 = false
	if (cache2 == nil) then
		inlineRet3 = false
		inlineDone3 = true
	end
	if not(inlineDone3) then
		inlineRet3 = SaveGameCache(cache2)
		inlineDone3 = true
	end
	if not(inlineDone3) then
		inlineRet3 = false
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	if inlineRet3 then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return true
	end
	if existed then
		cache2 = WarcraftCampaignSaveStorage_cache_storage[this14]
		key1 = WarcraftCampaignSaveStorage_mission_storage[this14]
		wurst_stack[wurst_stack_depth] = "when calling compatStoreString in CampaignSaveManager, line 206"
		wurst_stack_depth = (wurst_stack_depth + 1)
		existed = false
		if (cache2 == nil) then
			existed = true
		end
		if not(existed) then
			StoreString(cache2, key1, slotId5, previous1)
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
	else
		cache2 = WarcraftCampaignSaveStorage_cache_storage[this14]
		value1 = WarcraftCampaignSaveStorage_mission_storage[this14]
		wurst_stack[wurst_stack_depth] = "when calling compatFlushStoredString in CampaignSaveManager, line 208"
		wurst_stack_depth = (wurst_stack_depth + 1)
		existed = false
		if (cache2 == nil) then
			existed = true
		end
		if not(existed) then
			FlushStoredString(cache2, value1, slotId5)
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	cache2 = WarcraftCampaignSaveStorage_cache_storage[this14]
	wurst_stack[wurst_stack_depth] = "when calling compatSaveGameCache in CampaignSaveManager, line 209"
	wurst_stack_depth = (wurst_stack_depth + 1)
	existed = false
	if (cache2 == nil) then
		existed = true
	end
	if not(existed) then
		SaveGameCache(cache2)
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return false
end

function Command:create6() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = Command
	Command_name_storage[new_inst] = ""
	Command_aliases_storage[new_inst] = ""
	Command_usage_storage[new_inst] = ""
	Command_summary_storage[new_inst] = ""
	Command_details_storage[new_inst] = ""
	Command_minimum_storage[new_inst] = 0
	Command_maximum_storage[new_inst] = 0
	Command_visibility_storage[new_inst] = 0
	Command_handler_storage[new_inst] = nil
	return new_inst
end

function Command_dealloc(object) 
end

function CommandChatNatives:create7() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CommandChatNatives
	return new_inst
end

function CommandChatNatives_dealloc(object) 
end

function CommandChatNatives_CommandChatNatives_registerChat(this15, listener, sender, prefix, exact, __wurst_stackPos16) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos16
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandChatNatives_CommandChatNatives_retire(this16, listener1, __wurst_stackPos17) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos17
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandChatNatives_CommandChatNatives_eventListener(this17, __wurst_stackPos18) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos18
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandChatNatives_CommandChatNatives_eventPlayer(this18, __wurst_stackPos19) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos19
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandChatNatives_CommandChatNatives_eventText(this19, __wurst_stackPos20) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos20
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandHandler:create8() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CommandHandler
	return new_inst
end

function CommandHandler_dealloc(object) 
end

function CommandHandler_CommandHandler_execute(this20, sender1, arguments, __wurst_stackPos21) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos21
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandOutput:create9() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CommandOutput
	return new_inst
end

function CommandOutput_dealloc(object) 
end

function CommandOutput_CommandOutput_show(this21, recipient, message, __wurst_stackPos22) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos22
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function CommandRegistry:create10() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CommandRegistry
	CommandRegistry_commands_storage[new_inst] = ({})
	CommandRegistry_size_storage[new_inst] = 0
	CommandRegistry_debug_storage[new_inst] = false
	CommandRegistry_pageSize_storage[new_inst] = 0
	CommandRegistry_text_storage[new_inst] = nil
	CommandRegistry_output_storage[new_inst] = nil
	return new_inst
end

function CommandRegistry_dealloc(object) 
end

function CommandRegistry_CommandRegistry_visible(this22, c, __wurst_stackPos23) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos23
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	return ((Command_visibility_storage[c] == CommandRouter_COMMAND_RELEASE) or CommandRegistry_debug_storage[this22])
end

function CommandRegistry_CommandRegistry_find(this23, name, __wurst_stackPos24) 
	local CommandRegistry_commands_storage_local = CommandRegistry_commands_storage
	local Command_aliases_storage_local = Command_aliases_storage
	local Command_name_storage_local = Command_name_storage
	local i1 = nil
	local temp1 = nil
	local s1 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos24
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling lower in CommandRouter, line 144"
	wurst_stack_depth = (wurst_stack_depth + 1)
	s1 = StringCase(name, false)
	wurst_stack_depth = (wurst_stack_depth - 1)
	i1 = 0
	temp1 = (CommandRegistry_size_storage[this23] - 1)
	while true do
		if (i1 > temp1) then
			break
		end
		if ((Command_name_storage_local[CommandRegistry_commands_storage_local[this23][i1]] == s1) or hasAlias(Command_aliases_storage_local[CommandRegistry_commands_storage_local[this23][i1]], s1, "when calling hasAlias in CommandRouter, line 146")) then
			wurst_stack_depth = (wurst_stack_depth - 1)
			return CommandRegistry_commands_storage_local[this23][i1]
		end
		i1 = (i1 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return nil
end

function CommandRegistry_CommandRegistry_register(this24, name1, aliases1, usage, summary, details, minimum, maximum, visibility, handler, __wurst_stackPos26) 
	local CommandRegistry_text_storage_local = CommandRegistry_text_storage
	local CommandText_conflict_storage_local = CommandText_conflict_storage
	local wurst_stack_local = wurst_stack
	local d = nil
	local ma = nil
	local v = nil
	local this25 = nil
	local n = nil
	local mi = nil
	wurst_stack_local[wurst_stack_depth] = __wurst_stackPos26
	wurst_stack_depth = (wurst_stack_depth + 1)
	n = normalizeCommandLine(name1, "when calling normalizeCommandLine in CommandRouter, line 150")
	wurst_stack_local[wurst_stack_depth] = "when calling lower in CommandRouter, line 150"
	wurst_stack_depth = (wurst_stack_depth + 1)
	n = StringCase(n, false)
	wurst_stack_depth = (wurst_stack_depth - 1)
	if ((n == "") or (firstSpace(n, "when calling firstSpace in CommandRouter, line 151") >= 0)) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return "Malformed command registration: command names must be one token."
	end
	if ((minimum < 0) or (maximum < minimum)) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		wurst_stack_local[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not(("Malformed command registration: invalid argument bounds for '" == nil)) then
			if not((n == nil)) then
				n = __wurst_rawConcat("Malformed command registration: invalid argument bounds for '", n)
			else
				n = "Malformed command registration: invalid argument bounds for '"
			end
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		wurst_stack_local[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not((n == nil)) then
			if not(("'." == nil)) then
				n = __wurst_rawConcat(n, "'.")
			end
		else
			n = "'."
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		return n
	end
	if not((CommandRegistry_CommandRegistry_find(this24, n, "when calling find in CommandRouter, line 155") == nil)) then
		n = replace(CommandText_conflict_storage_local[CommandRegistry_text_storage_local[this24]], "{token}", n, "when calling replace in CommandRouter, line 156")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return n
	end
	v = 0
	mi = 0
	ma = StringLength(aliases1)
	while true do
		if (mi > ma) then
			break
		end
		if ((mi == StringLength(aliases1)) or (SubString(aliases1, mi, (mi + 1)) == ",")) then
			d = normalizeCommandLine(SubString(aliases1, v, mi), "when calling normalizeCommandLine in CommandRouter, line 160")
			wurst_stack_local[wurst_stack_depth] = "when calling lower in CommandRouter, line 160"
			wurst_stack_depth = (wurst_stack_depth + 1)
			d = StringCase(d, false)
			wurst_stack_depth = (wurst_stack_depth - 1)
			if (not((d == "")) and ((((firstSpace(d, "when calling firstSpace in CommandRouter, line 161") >= 0) or (d == n)) or not((CommandRegistry_CommandRegistry_find(this24, d, "when calling find in CommandRouter, line 161") == nil))) or hasAlias(SubString(aliases1, 0, v), d, "when calling hasAlias in CommandRouter, line 161"))) then
				n = replace(CommandText_conflict_storage_local[CommandRegistry_text_storage_local[this24]], "{token}", d, "when calling replace in CommandRouter, line 162")
				wurst_stack_depth = (wurst_stack_depth - 1)
				return n
			end
			v = (mi + 1)
		end
		mi = (mi + 1)
	end
	wurst_stack_local[wurst_stack_depth] = "when calling lower in CommandRouter, line 164"
	wurst_stack_depth = (wurst_stack_depth + 1)
	d = StringCase(aliases1, false)
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack_local[wurst_stack_depth] = "when calling new_Command in CommandRouter, line 164"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this25 = Command:create6()
	wurst_stack_local[wurst_stack_depth] = "when calling construct_Command in CommandRouter, line 32"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack_local[wurst_stack_depth] = "when calling Command_init in CommandRouter, line 32"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	Command_name_storage[this25] = n
	Command_aliases_storage[this25] = d
	Command_usage_storage[this25] = usage
	Command_summary_storage[this25] = summary
	Command_details_storage[this25] = details
	Command_minimum_storage[this25] = minimum
	Command_maximum_storage[this25] = maximum
	Command_visibility_storage[this25] = visibility
	Command_handler_storage[this25] = handler
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	CommandRegistry_commands_storage[this24][CommandRegistry_size_storage[this24]] = this25
	CommandRegistry_size_storage[this24] = (CommandRegistry_size_storage[this24] + 1)
	wurst_stack_depth = (wurst_stack_depth - 1)
	return ""
end

function CommandRegistry_CommandRegistry_visibleCount(this26, __wurst_stackPos30) 
	local CommandRegistry_commands_storage_local1 = CommandRegistry_commands_storage
	local CommandRegistry_debug_storage_local = CommandRegistry_debug_storage
	local Command_visibility_storage_local = Command_visibility_storage
	local wurst_stack_local1 = wurst_stack
	local n1 = nil
	local i2 = nil
	local temp2 = nil
	local c1 = nil
	wurst_stack_local1[wurst_stack_depth] = __wurst_stackPos30
	wurst_stack_depth = (wurst_stack_depth + 1)
	n1 = 0
	i2 = 0
	temp2 = (CommandRegistry_size_storage[this26] - 1)
	while true do
		if (i2 > temp2) then
			break
		end
		c1 = CommandRegistry_commands_storage_local1[this26][i2]
		wurst_stack_local1[wurst_stack_depth] = "when calling visible in CommandRouter, line 170"
		wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
		if ((Command_visibility_storage_local[c1] == CommandRouter_COMMAND_RELEASE) or CommandRegistry_debug_storage_local[this26]) then
			n1 = (n1 + 1)
		end
		i2 = (i2 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return n1
end

function CommandRegistry_CommandRegistry_pages(this27, __wurst_stackPos31) 
	local a = nil
	local b = nil
	local q = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos31
	wurst_stack_depth = (wurst_stack_depth + 1)
	a = ((CommandRegistry_CommandRegistry_visibleCount(this27, "when calling visibleCount in CommandRouter, line 174") + CommandRegistry_pageSize_storage[this27]) - 1)
	b = CommandRegistry_pageSize_storage[this27]
	q = (a // b)
	if ((q < 0) and not(((q * b) == a))) then
		q = (q + 1)
	end
	if (q < 1) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 1
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return q
end

function dispatch_CommandOutput_show(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandOutput_show)(receiver, ...)
end

function CommandRegistry_CommandRegistry_helpPage(this28, sender2, page, __wurst_stackPos32) 
	local wurst_stack_local2 = wurst_stack
	local CommandRegistry_pageSize_storage_local = CommandRegistry_pageSize_storage
	local CommandRegistry_commands_storage_local2 = CommandRegistry_commands_storage
	local CommandRegistry_debug_storage_local1 = CommandRegistry_debug_storage
	local Command_summary_storage_local = Command_summary_storage
	local Command_usage_storage_local = Command_usage_storage
	local Command_visibility_storage_local1 = Command_visibility_storage
	local shown = nil
	local i3 = nil
	local temp3 = nil
	local c2 = nil
	local x3 = nil
	local x4 = nil
	local y3 = nil
	wurst_stack_local2[wurst_stack_depth] = __wurst_stackPos32
	wurst_stack_depth = (wurst_stack_depth + 1)
	if ((page < 1) or (page > CommandRegistry_CommandRegistry_pages(this28, "when calling pages in CommandRouter, line 179"))) then
		x3 = CommandText_invalidPage_storage[CommandRegistry_text_storage[this28]]
		shown = CommandRegistry_CommandRegistry_pages(this28, "when calling pages in CommandRouter, line 180")
		wurst_stack_local2[wurst_stack_depth] = "when calling toString in CommandRouter, line 180"
		wurst_stack_depth = (wurst_stack_depth + 1)
		x4 = tostring(shown)
		wurst_stack_depth = (wurst_stack_depth - 1)
		dispatch_CommandOutput_show(CommandRegistry_output_storage[this28], sender2, replace(x3, "{pages}", x4, "when calling replace in CommandRouter, line 180"), "when calling show in CommandRouter, line 180")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 
	end
	x3 = CommandText_heading_storage[CommandRegistry_text_storage[this28]]
	wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x3 == nil)) then
		if not((" - Page " == nil)) then
			x3 = __wurst_rawConcat(x3, " - Page ")
		end
	else
		x3 = " - Page "
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack_local2[wurst_stack_depth] = "when calling toString in CommandRouter, line 182"
	wurst_stack_depth = (wurst_stack_depth + 1)
	x4 = tostring(page)
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x3 == nil)) then
		if not((x4 == nil)) then
			x3 = __wurst_rawConcat(x3, x4)
		end
	else
		x3 = x4
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x3 == nil)) then
		if not(("/" == nil)) then
			x3 = __wurst_rawConcat(x3, "/")
		end
	else
		x3 = "/"
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	shown = CommandRegistry_CommandRegistry_pages(this28, "when calling pages in CommandRouter, line 182")
	wurst_stack_local2[wurst_stack_depth] = "when calling toString in CommandRouter, line 182"
	wurst_stack_depth = (wurst_stack_depth + 1)
	x4 = tostring(shown)
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x3 == nil)) then
		if not((x4 == nil)) then
			x3 = __wurst_rawConcat(x3, x4)
		end
	else
		x3 = x4
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	shown = 0
	i3 = 0
	temp3 = (CommandRegistry_size_storage[this28] - 1)
	while true do
		if (i3 > temp3) then
			break
		end
		c2 = CommandRegistry_commands_storage_local2[this28][i3]
		wurst_stack_local2[wurst_stack_depth] = "when calling visible in CommandRouter, line 186"
		wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
		if ((Command_visibility_storage_local1[c2] == CommandRouter_COMMAND_RELEASE) or CommandRegistry_debug_storage_local1[this28]) then
			if ((shown >= ((page - 1) * CommandRegistry_pageSize_storage_local[this28])) and (shown < (page * CommandRegistry_pageSize_storage_local[this28]))) then
				y3 = Command_usage_storage_local[c2]
				wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not(("\n/" == nil)) then
					if not((y3 == nil)) then
						x4 = __wurst_rawConcat("\n/", y3)
					else
						x4 = "\n/"
					end
				else
					x4 = y3
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x4 == nil)) then
					if not((" - " == nil)) then
						x4 = __wurst_rawConcat(x4, " - ")
					end
				else
					x4 = " - "
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				y3 = Command_summary_storage_local[c2]
				wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x4 == nil)) then
					if not((y3 == nil)) then
						x4 = __wurst_rawConcat(x4, y3)
					end
				else
					x4 = y3
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local2[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x3 == nil)) then
					if not((x4 == nil)) then
						x3 = __wurst_rawConcat(x3, x4)
					end
				else
					x3 = x4
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			shown = (shown + 1)
		end
		i3 = (i3 + 1)
	end
	dispatch_CommandOutput_show(CommandRegistry_output_storage[this28], sender2, x3, "when calling show in CommandRouter, line 190")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function CommandRegistry_CommandRegistry_help(this29, sender3, a1, __wurst_stackPos33) 
	local c3 = nil
	local s3 = nil
	local n2 = nil
	local i4 = nil
	local temp4 = nil
	local inlineDone4 = nil
	local inlineRet4 = nil
	local i5 = nil
	local temp5 = nil
	local c4 = nil
	local inlineRet5 = nil
	local i6 = nil
	local temp6 = nil
	local c5 = nil
	local inlineRet6 = nil
	local inlineRet7 = nil
	local temp11 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos33
	wurst_stack_depth = (wurst_stack_depth + 1)
	s3 = a1
	inlineDone4 = false
	wurst_stack[wurst_stack_depth] = "when calling countArguments in CommandRouter, line 192"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if (a1 == "") then
		wurst_stack_depth = (wurst_stack_depth - 1)
		inlineRet4 = 0
		inlineDone4 = true
	end
	if not(inlineDone4) then
		n2 = 1
	end
	if not(inlineDone4) then
		i4 = 0
	end
	if not(inlineDone4) then
		temp4 = (StringLength(a1) - 1)
	end
	if not(inlineDone4) then
		while true do
			if (inlineDone4 or (not(inlineDone4) and (i4 > temp4))) then
				break
			end
			if not(inlineDone4) then
				if (SubString(s3, i4, (i4 + 1)) == " ") then
					if not(inlineDone4) then
						n2 = (n2 + 1)
					end
				end
			end
			if not(inlineDone4) then
				i4 = (i4 + 1)
			end
		end
	end
	if not(inlineDone4) then
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	if not(inlineDone4) then
		inlineRet4 = n2
		inlineDone4 = true
	end
	if not(inlineDone4) then
		inlineRet4 = 0
	end
	if (inlineRet4 > 1) then
		dispatch_CommandOutput_show(CommandRegistry_output_storage[this29], sender3, CommandText_malformedHelp_storage[CommandRegistry_text_storage[this29]], "when calling show in CommandRouter, line 193")
	elseif (a1 == "") then
		CommandRegistry_CommandRegistry_helpPage(this29, sender3, 1, "when calling helpPage in CommandRouter, line 195")
	else
		s3 = a1
		inlineDone4 = false
		wurst_stack[wurst_stack_depth] = "when calling positiveInt in CommandRouter, line 196"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if (a1 == "") then
			wurst_stack_depth = (wurst_stack_depth - 1)
			inlineRet5 = false
			inlineDone4 = true
		end
		if not(inlineDone4) then
			i5 = 0
		end
		if not(inlineDone4) then
			temp5 = (StringLength(a1) - 1)
		end
		if not(inlineDone4) then
			while true do
				if (inlineDone4 or (not(inlineDone4) and (i5 > temp5))) then
					break
				end
				if not(inlineDone4) then
					c4 = SubString(s3, i5, (i5 + 1))
				end
				if not(inlineDone4) then
					if (((((((((not((c4 == "0")) and not((c4 == "1"))) and not((c4 == "2"))) and not((c4 == "3"))) and not((c4 == "4"))) and not((c4 == "5"))) and not((c4 == "6"))) and not((c4 == "7"))) and not((c4 == "8"))) and not((c4 == "9"))) then
						if not(inlineDone4) then
							wurst_stack_depth = (wurst_stack_depth - 1)
						end
						if not(inlineDone4) then
							inlineRet5 = false
							inlineDone4 = true
						end
					end
				end
				if not(inlineDone4) then
					i5 = (i5 + 1)
				end
			end
		end
		if not(inlineDone4) then
			wurst_stack_depth = (wurst_stack_depth - 1)
		end
		if not(inlineDone4) then
			inlineRet5 = true
			inlineDone4 = true
		end
		if not(inlineDone4) then
			inlineRet5 = false
		end
		if inlineRet5 then
			inlineRet6 = true
		elseif (SubString(a1, 0, 1) == "-") then
			c4 = SubString(a1, 1, StringLength(a1))
			inlineRet5 = false
			wurst_stack[wurst_stack_depth] = "when calling positiveInt in CommandRouter, line 196"
			wurst_stack_depth = (wurst_stack_depth + 1)
			if (c4 == "") then
				wurst_stack_depth = (wurst_stack_depth - 1)
				inlineRet6 = false
				inlineRet5 = true
			end
			if not(inlineRet5) then
				i6 = 0
			end
			if not(inlineRet5) then
				temp6 = (StringLength(c4) - 1)
			end
			if not(inlineRet5) then
				while true do
					if (inlineRet5 or (not(inlineRet5) and (i6 > temp6))) then
						break
					end
					if not(inlineRet5) then
						c5 = SubString(c4, i6, (i6 + 1))
					end
					if not(inlineRet5) then
						if (((((((((not((c5 == "0")) and not((c5 == "1"))) and not((c5 == "2"))) and not((c5 == "3"))) and not((c5 == "4"))) and not((c5 == "5"))) and not((c5 == "6"))) and not((c5 == "7"))) and not((c5 == "8"))) and not((c5 == "9"))) then
							if not(inlineRet5) then
								wurst_stack_depth = (wurst_stack_depth - 1)
							end
							if not(inlineRet5) then
								inlineRet6 = false
								inlineRet5 = true
							end
						end
					end
					if not(inlineRet5) then
						i6 = (i6 + 1)
					end
				end
			end
			if not(inlineRet5) then
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			if not(inlineRet5) then
				inlineRet6 = true
				inlineRet5 = true
			end
			if not(inlineRet5) then
				inlineRet6 = false
			end
		else
			inlineRet6 = false
		end
		if inlineRet6 then
			temp11 = sender3
			c5 = a1
			n2 = CommandRegistry_CommandRegistry_pages(this29, "when calling pages in CommandRouter, line 197")
			inlineRet6 = false
			wurst_stack[wurst_stack_depth] = "when calling helpPageNumber in CommandRouter, line 197"
			wurst_stack_depth = (wurst_stack_depth + 1)
			i4 = 0
			temp4 = 0
			inlineRet4 = (StringLength(a1) - 1)
			while true do
				if (inlineRet6 or (not(inlineRet6) and (temp4 > inlineRet4))) then
					break
				end
				if not(inlineRet6) then
					if (SubString(c5, temp4, (temp4 + 1)) == "-") then
						if not(inlineRet6) then
							wurst_stack_depth = (wurst_stack_depth - 1)
						end
						if not(inlineRet6) then
							inlineRet7 = 0
							inlineRet6 = true
						end
					end
				end
				if not(inlineRet6) then
					i4 = ((i4 * 10) + S2I(SubString(c5, temp4, (temp4 + 1))))
				end
				if not(inlineRet6) then
					if (i4 > n2) then
						if not(inlineRet6) then
							wurst_stack_depth = (wurst_stack_depth - 1)
						end
						if not(inlineRet6) then
							inlineRet7 = 0
							inlineRet6 = true
						end
					end
				end
				if not(inlineRet6) then
					temp4 = (temp4 + 1)
				end
			end
			if not(inlineRet6) then
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			if not(inlineRet6) then
				inlineRet7 = i4
				inlineRet6 = true
			end
			if not(inlineRet6) then
				inlineRet7 = 0
			end
			CommandRegistry_CommandRegistry_helpPage(this29, temp11, inlineRet7, "when calling helpPage in CommandRouter, line 197")
		else
			wurst_stack[wurst_stack_depth] = "when calling lower in CommandRouter, line 199"
			wurst_stack_depth = (wurst_stack_depth + 1)
			c5 = StringCase(a1, false)
			wurst_stack_depth = (wurst_stack_depth - 1)
			c3 = CommandRegistry_CommandRegistry_find(this29, c5, "when calling find in CommandRouter, line 199")
			if (c3 == nil) then
				dispatch_CommandOutput_show(CommandRegistry_output_storage[this29], sender3, replace(CommandText_unknownTopic_storage[CommandRegistry_text_storage[this29]], "{topic}", a1, "when calling replace in CommandRouter, line 201"), "when calling show in CommandRouter, line 201")
			elseif not(CommandRegistry_CommandRegistry_visible(this29, c3, "when calling visible in CommandRouter, line 202")) then
				dispatch_CommandOutput_show(CommandRegistry_output_storage[this29], sender3, CommandText_unavailable_storage[CommandRegistry_text_storage[this29]], "when calling show in CommandRouter, line 203")
			else
				c4 = Command_usage_storage[c3]
				wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not(("Usage: /" == nil)) then
					if not((c4 == nil)) then
						c5 = __wurst_rawConcat("Usage: /", c4)
					else
						c5 = "Usage: /"
					end
				else
					c5 = c4
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((c5 == nil)) then
					if not(("\n" == nil)) then
						c5 = __wurst_rawConcat(c5, "\n")
					end
				else
					c5 = "\n"
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				c4 = Command_details_storage[c3]
				wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((c5 == nil)) then
					if not((c4 == nil)) then
						c5 = __wurst_rawConcat(c5, c4)
					end
				else
					c5 = c4
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				dispatch_CommandOutput_show(CommandRegistry_output_storage[this29], sender3, c5, "when calling show in CommandRouter, line 205")
			end
		end
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function dispatch_CommandHandler_execute(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandHandler_execute)(receiver, ...)
end

function CommandRegistry_CommandRegistry_dispatch(this30, sender4, input1, __wurst_stackPos34) 
	local line = nil
	local c6 = nil
	local cut = nil
	local stackTrace_tempReturn1 = nil
	local inlineDone5 = nil
	local inlineRet8 = nil
	local stackTrace_tempReturn2 = nil
	local inlineRet9 = nil
	local n3 = nil
	local i7 = nil
	local temp7 = nil
	local inlineRet10 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos34
	wurst_stack_depth = (wurst_stack_depth + 1)
	line = normalizeCommandLine(input1, "when calling normalizeCommandLine in CommandRouter, line 207")
	if (line == "") then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	inlineDone5 = false
	wurst_stack[wurst_stack_depth] = "when calling token in CommandRouter, line 210"
	wurst_stack_depth = (wurst_stack_depth + 1)
	cut = firstSpace(line, "when calling firstSpace in CommandRouter, line 72")
	if (cut < 0) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		inlineRet8 = line
		inlineDone5 = true
	end
	if not(inlineDone5) then
		stackTrace_tempReturn1 = SubString(line, 0, cut)
	end
	if not(inlineDone5) then
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	if not(inlineDone5) then
		inlineRet8 = stackTrace_tempReturn1
		inlineDone5 = true
	end
	if not(inlineDone5) then
		inlineRet8 = ""
	end
	c6 = CommandRegistry_CommandRegistry_find(this30, inlineRet8, "when calling find in CommandRouter, line 210")
	if (c6 == nil) then
		dispatch_CommandOutput_show(CommandRegistry_output_storage[this30], sender4, CommandText_unknown_storage[CommandRegistry_text_storage[this30]], "when calling show in CommandRouter, line 212")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	if not(CommandRegistry_CommandRegistry_visible(this30, c6, "when calling visible in CommandRouter, line 214")) then
		dispatch_CommandOutput_show(CommandRegistry_output_storage[this30], sender4, CommandText_unavailable_storage[CommandRegistry_text_storage[this30]], "when calling show in CommandRouter, line 215")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	inlineDone5 = false
	wurst_stack[wurst_stack_depth] = "when calling args in CommandRouter, line 217"
	wurst_stack_depth = (wurst_stack_depth + 1)
	cut = firstSpace(line, "when calling firstSpace in CommandRouter, line 77")
	if (cut < 0) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		inlineRet9 = ""
		inlineDone5 = true
	end
	if not(inlineDone5) then
		stackTrace_tempReturn2 = SubString(line, (cut + 1), StringLength(line))
	end
	if not(inlineDone5) then
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	if not(inlineDone5) then
		inlineRet9 = stackTrace_tempReturn2
		inlineDone5 = true
	end
	if not(inlineDone5) then
		inlineRet9 = ""
	end
	stackTrace_tempReturn2 = inlineRet9
	inlineDone5 = false
	wurst_stack[wurst_stack_depth] = "when calling countArguments in CommandRouter, line 218"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if (inlineRet9 == "") then
		wurst_stack_depth = (wurst_stack_depth - 1)
		inlineRet10 = 0
		inlineDone5 = true
	end
	if not(inlineDone5) then
		n3 = 1
	end
	if not(inlineDone5) then
		i7 = 0
	end
	if not(inlineDone5) then
		temp7 = (StringLength(inlineRet9) - 1)
	end
	if not(inlineDone5) then
		while true do
			if (inlineDone5 or (not(inlineDone5) and (i7 > temp7))) then
				break
			end
			if not(inlineDone5) then
				if (SubString(inlineRet9, i7, (i7 + 1)) == " ") then
					if not(inlineDone5) then
						n3 = (n3 + 1)
					end
				end
			end
			if not(inlineDone5) then
				i7 = (i7 + 1)
			end
		end
	end
	if not(inlineDone5) then
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	if not(inlineDone5) then
		inlineRet10 = n3
		inlineDone5 = true
	end
	if not(inlineDone5) then
		inlineRet10 = 0
	end
	if (not((Command_name_storage[c6] == "help")) and ((inlineRet10 < Command_minimum_storage[c6]) or (inlineRet10 > Command_maximum_storage[c6]))) then
		stackTrace_tempReturn2 = CommandText_invalidArguments_storage[CommandRegistry_text_storage[this30]]
		inlineRet9 = Command_usage_storage[c6]
		wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not((stackTrace_tempReturn2 == nil)) then
			if not((inlineRet9 == nil)) then
				stackTrace_tempReturn2 = __wurst_rawConcat(stackTrace_tempReturn2, inlineRet9)
			end
		else
			stackTrace_tempReturn2 = inlineRet9
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		dispatch_CommandOutput_show(CommandRegistry_output_storage[this30], sender4, stackTrace_tempReturn2, "when calling show in CommandRouter, line 220")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	if (Command_name_storage[c6] == "help") then
		CommandRegistry_CommandRegistry_help(this30, sender4, stackTrace_tempReturn2, "when calling help in CommandRouter, line 223")
	else
		dispatch_CommandHandler_execute(Command_handler_storage[c6], sender4, stackTrace_tempReturn2, "when calling execute in CommandRouter, line 225")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return true
end

function CommandText:create11() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = CommandText
	CommandText_heading_storage[new_inst] = ""
	CommandText_invalidPage_storage[new_inst] = ""
	CommandText_unknownTopic_storage[new_inst] = ""
	CommandText_malformedHelp_storage[new_inst] = ""
	CommandText_unavailable_storage[new_inst] = ""
	CommandText_unknown_storage[new_inst] = ""
	CommandText_invalidArguments_storage[new_inst] = ""
	CommandText_conflict_storage[new_inst] = ""
	return new_inst
end

function CommandText_dealloc(object) 
end

function NewCampaignOriginController:create12() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = NewCampaignOriginController
	OriginCatalog_definitions_storage[new_inst] = ({})
	OriginCatalog_count_storage[new_inst] = 0
	NewCampaignOriginController_pageSize_storage[new_inst] = 0
	NewCampaignOriginController_query_storage[new_inst] = ""
	NewCampaignOriginController_presentation_storage[new_inst] = nil
	NewCampaignOriginController_identity_storage[new_inst] = nil
	NewCampaignOriginController_observer_storage[new_inst] = nil
	return new_inst
end

function NewCampaignOriginController_dealloc(object) 
end

function NewCampaignOriginController_NewCampaignOriginController_setObserver(this31, observer, __wurst_stackPos35) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos35
	wurst_stack_depth = (wurst_stack_depth + 1)
	NewCampaignOriginController_observer_storage[this31] = observer
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function NewCampaignOriginController_NewCampaignOriginController_matchCount(this32, __wurst_stackPos36) 
	local NewCampaignOriginController_query_storage_local = NewCampaignOriginController_query_storage
	local OriginCatalog_definitions_storage_local = OriginCatalog_definitions_storage
	local OriginDefinition_name_storage_local = OriginDefinition_name_storage
	local OriginDefinition_polityId_storage_local = OriginDefinition_polityId_storage
	local wurst_stack_local3 = wurst_stack
	local result = nil
	local i8 = nil
	local temp8 = nil
	local row = nil
	local __wurst_stackPos37 = nil
	local stackTrace_tempReturn3 = nil
	wurst_stack_local3[wurst_stack_depth] = __wurst_stackPos36
	wurst_stack_depth = (wurst_stack_depth + 1)
	result = 0
	i8 = 0
	temp8 = (OriginCatalog_count_storage[this32] - 1)
	while true do
		if (i8 > temp8) then
			break
		end
		row = OriginCatalog_definitions_storage_local[this32][i8]
		wurst_stack_local3[wurst_stack_depth] = "when calling matches in CommandRouter, line 409"
		wurst_stack_depth = (wurst_stack_depth + 1)
		__wurst_stackPos37 = StringCase(NewCampaignOriginController_query_storage_local[this32], false)
		stackTrace_tempReturn3 = (((__wurst_stackPos37 == "") or (string_indexOf(StringCase(OriginDefinition_name_storage_local[row], false), __wurst_stackPos37, "when calling indexOf in CommandRouter, line 404") >= 0)) or (string_indexOf(StringCase(OriginDefinition_polityId_storage_local[row], false), __wurst_stackPos37, "when calling indexOf in CommandRouter, line 404") >= 0))
		wurst_stack_depth = (wurst_stack_depth - 1)
		if stackTrace_tempReturn3 then
			result = (result + 1)
		end
		i8 = (i8 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return result
end

function NewCampaignOriginController_NewCampaignOriginController_pages(this34, __wurst_stackPos39) 
	local a2 = nil
	local b1 = nil
	local q1 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos39
	wurst_stack_depth = (wurst_stack_depth + 1)
	a2 = ((NewCampaignOriginController_NewCampaignOriginController_matchCount(this34, "when calling matchCount in CommandRouter, line 414") + NewCampaignOriginController_pageSize_storage[this34]) - 1)
	b1 = NewCampaignOriginController_pageSize_storage[this34]
	q1 = (a2 // b1)
	if ((q1 < 0) and not(((q1 * b1) == a2))) then
		q1 = (q1 + 1)
	end
	if (q1 < 1) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 1
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return q1
end

function dispatch_OriginSelectionPresentation_showError(receiver, ...) 
	return (__wurst_objectClass[receiver].OriginSelectionPresentation_showError)(receiver, ...)
end

function dispatch_OriginSelectionPresentation_show(receiver, ...) 
	return (__wurst_objectClass[receiver].OriginSelectionPresentation_show)(receiver, ...)
end

function NewCampaignOriginController_NewCampaignOriginController_showPage(this35, page1, __wurst_stackPos40) 
	local wurst_stack_local4 = wurst_stack
	local NewCampaignOriginController_pageSize_storage_local = NewCampaignOriginController_pageSize_storage
	local OriginDefinition_name_storage_local1 = OriginDefinition_name_storage
	local OriginDefinition_polityId_storage_local1 = OriginDefinition_polityId_storage
	local NewCampaignOriginController_query_storage_local1 = NewCampaignOriginController_query_storage
	local OriginCatalog_definitions_storage_local1 = OriginCatalog_definitions_storage
	local matched = nil
	local i9 = nil
	local temp9 = nil
	local row1 = nil
	local stackTrace_tempReturn4 = nil
	local x5 = nil
	local x6 = nil
	local y4 = nil
	wurst_stack_local4[wurst_stack_depth] = __wurst_stackPos40
	wurst_stack_depth = (wurst_stack_depth + 1)
	if PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin(NewCampaignOriginController_identity_storage[this35], "when calling hasOrigin in CommandRouter, line 420") then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 
	end
	if ((page1 < 1) or (page1 > NewCampaignOriginController_NewCampaignOriginController_pages(this35, "when calling pages in CommandRouter, line 422"))) then
		dispatch_OriginSelectionPresentation_showError(NewCampaignOriginController_presentation_storage[this35], "That origin page is not available.", "when calling showError in CommandRouter, line 423")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 
	end
	x5 = ""
	matched = 0
	i9 = 0
	temp9 = (OriginCatalog_count_storage[this35] - 1)
	while true do
		if (i9 > temp9) then
			break
		end
		row1 = OriginCatalog_definitions_storage_local1[this35][i9]
		wurst_stack_local4[wurst_stack_depth] = "when calling matches in CommandRouter, line 429"
		wurst_stack_depth = (wurst_stack_depth + 1)
		x6 = StringCase(NewCampaignOriginController_query_storage_local1[this35], false)
		stackTrace_tempReturn4 = (((x6 == "") or (string_indexOf(StringCase(OriginDefinition_name_storage_local1[row1], false), x6, "when calling indexOf in CommandRouter, line 404") >= 0)) or (string_indexOf(StringCase(OriginDefinition_polityId_storage_local1[row1], false), x6, "when calling indexOf in CommandRouter, line 404") >= 0))
		wurst_stack_depth = (wurst_stack_depth - 1)
		if stackTrace_tempReturn4 then
			if ((matched >= ((page1 - 1) * NewCampaignOriginController_pageSize_storage_local[this35])) and (matched < (page1 * NewCampaignOriginController_pageSize_storage_local[this35]))) then
				if not((x5 == "")) then
					wurst_stack_local4[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not((x5 == nil)) then
						if not(("\n" == nil)) then
							x5 = __wurst_rawConcat(x5, "\n")
						end
					else
						x5 = "\n"
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
				end
				x6 = OriginDefinition_name_storage_local1[row1]
				wurst_stack_local4[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x6 == nil)) then
					if not((" [" == nil)) then
						x6 = __wurst_rawConcat(x6, " [")
					end
				else
					x6 = " ["
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				y4 = OriginDefinition_polityId_storage_local1[row1]
				wurst_stack_local4[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x6 == nil)) then
					if not((y4 == nil)) then
						x6 = __wurst_rawConcat(x6, y4)
					end
				else
					x6 = y4
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local4[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x6 == nil)) then
					if not(("]" == nil)) then
						x6 = __wurst_rawConcat(x6, "]")
					end
				else
					x6 = "]"
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local4[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((x5 == nil)) then
					if not((x6 == nil)) then
						x5 = __wurst_rawConcat(x5, x6)
					end
				else
					x5 = x6
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			matched = (matched + 1)
		end
		i9 = (i9 + 1)
	end
	dispatch_OriginSelectionPresentation_show(NewCampaignOriginController_presentation_storage[this35], "Which country or polity are you from at the start? You play an individual, not the country.", x5, page1, NewCampaignOriginController_NewCampaignOriginController_pages(this35, "when calling pages in CommandRouter, line 435"), "when calling show in CommandRouter, line 435")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function NewCampaignOriginController_NewCampaignOriginController_search(this37, playerQuery, __wurst_stackPos42) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos42
	wurst_stack_depth = (wurst_stack_depth + 1)
	NewCampaignOriginController_query_storage[this37] = playerQuery
	NewCampaignOriginController_NewCampaignOriginController_showPage(this37, 1, "when calling showPage in CommandRouter, line 439")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function dispatch_CampaignHandoff_commitSelection(receiver, ...) 
	return (__wurst_objectClass[receiver].CampaignHandoff_commitSelection)(receiver, ...)
end

function dispatch_OriginSelectionPresentation_close(receiver, ...) 
	return (__wurst_objectClass[receiver].OriginSelectionPresentation_close)(receiver, ...)
end

function dispatch_CampaignHandoff_campaignStarted(receiver, ...) 
	return (__wurst_objectClass[receiver].CampaignHandoff_campaignStarted)(receiver, ...)
end

function NewCampaignOriginController_NewCampaignOriginController_choose(this38, polityId2, __wurst_stackPos43) 
	local NewCampaignOriginController_observer_storage_local = NewCampaignOriginController_observer_storage
	local OriginDefinition_polityId_storage_local2 = OriginDefinition_polityId_storage
	local OriginDefinition_physicalMapId_storage_local = OriginDefinition_physicalMapId_storage
	local OriginDefinition_regionalInstanceId_storage_local = OriginDefinition_regionalInstanceId_storage
	local OriginDefinition_settlementId_storage_local = OriginDefinition_settlementId_storage
	local NewCampaignOriginController_presentation_storage_local = NewCampaignOriginController_presentation_storage
	local NewCampaignOriginController_identity_storage_local = NewCampaignOriginController_identity_storage
	local OriginCatalog_definitions_storage_local2 = OriginCatalog_definitions_storage
	local OriginDefinition_packagePath_storage_local = OriginDefinition_packagePath_storage
	local PlayerCampaignIdentity_originPolityId_storage_local = PlayerCampaignIdentity_originPolityId_storage
	local wurst_stack_local5 = wurst_stack
	local i10 = nil
	local temp10 = nil
	local row2 = nil
	local this39 = nil
	local polityId3 = nil
	local physicalMapId2 = nil
	local regionalInstanceId2 = nil
	local settlementId3 = nil
	local inlineDone6 = nil
	local inlineRet11 = nil
	wurst_stack_local5[wurst_stack_depth] = __wurst_stackPos43
	wurst_stack_depth = (wurst_stack_depth + 1)
	if PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin(NewCampaignOriginController_identity_storage_local[this38], "when calling hasOrigin in CommandRouter, line 442") then
		dispatch_OriginSelectionPresentation_showError(NewCampaignOriginController_presentation_storage_local[this38], "Your campaign origin is already part of your history.", "when calling showError in CommandRouter, line 443")
		wurst_stack_depth = (wurst_stack_depth - 1)
		return false
	end
	i10 = 0
	temp10 = (OriginCatalog_count_storage[this38] - 1)
	while true do
		if (i10 > temp10) then
			break
		end
		row2 = OriginCatalog_definitions_storage_local2[this38][i10]
		if (OriginDefinition_polityId_storage_local2[row2] == polityId2) then
			if (not((NewCampaignOriginController_observer_storage_local[this38] == nil)) and not(dispatch_CampaignHandoff_commitSelection(NewCampaignOriginController_observer_storage_local[this38], OriginDefinition_polityId_storage_local2[row2], OriginDefinition_physicalMapId_storage_local[row2], OriginDefinition_regionalInstanceId_storage_local[row2], OriginDefinition_settlementId_storage_local[row2], "when calling commitSelection in CommandRouter, line 448"))) then
				dispatch_OriginSelectionPresentation_showError(NewCampaignOriginController_presentation_storage_local[this38], "Campaign start could not be committed. Please choose the origin again.", "when calling showError in CommandRouter, line 449")
				wurst_stack_depth = (wurst_stack_depth - 1)
				return false
			end
			this39 = NewCampaignOriginController_identity_storage_local[this38]
			polityId3 = OriginDefinition_polityId_storage_local2[row2]
			physicalMapId2 = OriginDefinition_physicalMapId_storage_local[row2]
			regionalInstanceId2 = OriginDefinition_regionalInstanceId_storage_local[row2]
			settlementId3 = OriginDefinition_settlementId_storage_local[row2]
			inlineDone6 = false
			wurst_stack_local5[wurst_stack_depth] = "when calling startCampaign in CommandRouter, line 451"
			wurst_stack_depth = (wurst_stack_depth + 1)
			if ((((PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin(this39, "when calling hasOrigin in CommandRouter, line 293") or (polityId3 == "")) or (physicalMapId2 == "")) or (regionalInstanceId2 == "")) or (settlementId3 == "")) then
				wurst_stack_depth = (wurst_stack_depth - 1)
				inlineRet11 = false
				inlineDone6 = true
			end
			if not(inlineDone6) then
				PlayerCampaignIdentity_originPolityId_storage_local[this39] = polityId3
			end
			if not(inlineDone6) then
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			if not(inlineDone6) then
				inlineRet11 = true
				inlineDone6 = true
			end
			if not(inlineDone6) then
				inlineRet11 = false
			end
			if inlineRet11 then
				dispatch_OriginSelectionPresentation_close(NewCampaignOriginController_presentation_storage_local[this38], "when calling close in CommandRouter, line 452")
				if not((NewCampaignOriginController_observer_storage_local[this38] == nil)) then
					dispatch_CampaignHandoff_campaignStarted(NewCampaignOriginController_observer_storage_local[this38], OriginDefinition_polityId_storage_local2[row2], OriginDefinition_physicalMapId_storage_local[row2], OriginDefinition_packagePath_storage_local[row2], OriginDefinition_regionalInstanceId_storage_local[row2], OriginDefinition_settlementId_storage_local[row2], "when calling campaignStarted in CommandRouter, line 454")
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				return true
			end
		end
		i10 = (i10 + 1)
	end
	dispatch_OriginSelectionPresentation_showError(NewCampaignOriginController_presentation_storage_local[this38], "That polity is not active in the authoritative starting world.", "when calling showError in CommandRouter, line 456")
	wurst_stack_depth = (wurst_stack_depth - 1)
	return false
end

function OriginCatalog:create13() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = OriginCatalog
	OriginCatalog_definitions_storage[new_inst] = ({})
	OriginCatalog_count_storage[new_inst] = 0
	return new_inst
end

function OriginCatalog_dealloc(object) 
end

function OriginCatalog_OriginCatalog_find(this40, polityId4, __wurst_stackPos44) 
	local OriginCatalog_definitions_storage_local3 = OriginCatalog_definitions_storage
	local OriginDefinition_polityId_storage_local3 = OriginDefinition_polityId_storage
	local i11 = nil
	local temp12 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos44
	wurst_stack_depth = (wurst_stack_depth + 1)
	i11 = 0
	temp12 = (OriginCatalog_count_storage[this40] - 1)
	while true do
		if (i11 > temp12) then
			break
		end
		if (OriginDefinition_polityId_storage_local3[OriginCatalog_definitions_storage_local3[this40][i11]] == polityId4) then
			wurst_stack_depth = (wurst_stack_depth - 1)
			return OriginCatalog_definitions_storage_local3[this40][i11]
		end
		i11 = (i11 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return nil
end

function OriginCatalog_OriginCatalog_setPosition(this41, polityId5, x7, y5, __wurst_stackPos45) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos45
	wurst_stack_depth = (wurst_stack_depth + 1)
	OriginCatalog_OriginCatalog_find(this41, polityId5, "when calling find in CommandRouter, line 371")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function OriginCatalog_OriginCatalog_add(this42, polityId6, name2, physicalMapId3, packagePath3, regionalInstanceId3, settlementId4, __wurst_stackPos46) 
	local this43 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos46
	wurst_stack_depth = (wurst_stack_depth + 1)
	if ((((((((polityId6 == "") or (name2 == "")) or (physicalMapId3 == "")) or (packagePath3 == "")) or (regionalInstanceId3 == "")) or (settlementId4 == "")) or not((OriginCatalog_OriginCatalog_find(this42, polityId6, "when calling find in CommandRouter, line 379") == nil))) or (OriginCatalog_count_storage[this42] >= 256)) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 
	end
	wurst_stack[wurst_stack_depth] = "when calling new_OriginDefinition in CommandRouter, line 381"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this43 = OriginDefinition:create14()
	wurst_stack[wurst_stack_depth] = "when calling construct_OriginDefinition in CommandRouter, line 353"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling OriginDefinition_init in CommandRouter, line 353"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	OriginDefinition_polityId_storage[this43] = polityId6
	OriginDefinition_name_storage[this43] = name2
	OriginDefinition_physicalMapId_storage[this43] = physicalMapId3
	OriginDefinition_packagePath_storage[this43] = packagePath3
	OriginDefinition_regionalInstanceId_storage[this43] = regionalInstanceId3
	OriginDefinition_settlementId_storage[this43] = settlementId4
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	OriginCatalog_definitions_storage[this42][OriginCatalog_count_storage[this42]] = this43
	OriginCatalog_count_storage[this42] = (OriginCatalog_count_storage[this42] + 1)
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function OriginCommandHandler:create15() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = OriginCommandHandler
	OriginCommandHandler_controller_storage[new_inst] = nil
	return new_inst
end

function OriginCommandHandler_dealloc(object) 
end

function OriginCommandHandler_OriginCommandHandler_execute(this44, sender5, arguments1, __wurst_stackPos47) 
	local action = nil
	local value3 = nil
	local i12 = nil
	local temp13 = nil
	local inlineDone7 = nil
	local inlineRet12 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos47
	wurst_stack_depth = (wurst_stack_depth + 1)
	action = arguments1
	inlineDone7 = false
	wurst_stack[wurst_stack_depth] = "when calling splitOriginArgument in CommandRouter, line 470"
	wurst_stack_depth = (wurst_stack_depth + 1)
	i12 = 0
	temp13 = (StringLength(arguments1) - 1)
	while true do
		if (inlineDone7 or (not(inlineDone7) and (i12 > temp13))) then
			break
		end
		if not(inlineDone7) then
			if (SubString(action, i12, (i12 + 1)) == " ") then
				if not(inlineDone7) then
					wurst_stack_depth = (wurst_stack_depth - 1)
				end
				if not(inlineDone7) then
					inlineRet12 = i12
					inlineDone7 = true
				end
			end
		end
		if not(inlineDone7) then
			i12 = (i12 + 1)
		end
	end
	if not(inlineDone7) then
		wurst_stack_depth = (wurst_stack_depth - 1)
	end
	if not(inlineDone7) then
		inlineRet12 = -1
		inlineDone7 = true
	end
	if not(inlineDone7) then
		inlineRet12 = 0
	end
	action = arguments1
	value3 = ""
	if (inlineRet12 >= 0) then
		action = SubString(arguments1, 0, inlineRet12)
		value3 = SubString(arguments1, (inlineRet12 + 1), StringLength(arguments1))
	end
	if ((action == "page") and not((value3 == ""))) then
		NewCampaignOriginController_NewCampaignOriginController_showPage(OriginCommandHandler_controller_storage[this44], S2I(value3), "when calling showPage in CommandRouter, line 477")
	elseif (action == "search") then
		NewCampaignOriginController_NewCampaignOriginController_search(OriginCommandHandler_controller_storage[this44], value3, "when calling search in CommandRouter, line 479")
	elseif ((action == "choose") and not((value3 == ""))) then
		NewCampaignOriginController_NewCampaignOriginController_choose(OriginCommandHandler_controller_storage[this44], value3, "when calling choose in CommandRouter, line 481")
	else
		NewCampaignOriginController_NewCampaignOriginController_showPage(OriginCommandHandler_controller_storage[this44], 1, "when calling showPage in CommandRouter, line 483")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function OriginDefinition:create14() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = OriginDefinition
	OriginDefinition_polityId_storage[new_inst] = ""
	OriginDefinition_name_storage[new_inst] = ""
	OriginDefinition_physicalMapId_storage[new_inst] = ""
	OriginDefinition_packagePath_storage[new_inst] = ""
	OriginDefinition_regionalInstanceId_storage[new_inst] = ""
	OriginDefinition_settlementId_storage[new_inst] = ""
	return new_inst
end

function OriginDefinition_dealloc(object) 
end

function OriginSelectionObserver:create16() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = OriginSelectionObserver
	return new_inst
end

function OriginSelectionObserver_dealloc(object) 
end

function OriginSelectionObserver_OriginSelectionObserver_commitSelection(this45, polityId7, physicalMapId4, regionalInstanceId4, settlementId5, __wurst_stackPos48) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos48
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function OriginSelectionObserver_OriginSelectionObserver_campaignStarted(this46, polityId8, physicalMapId5, packagePath4, regionalInstanceId5, settlementId6, __wurst_stackPos49) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos49
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function OriginSelectionPresentation:create17() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = OriginSelectionPresentation
	return new_inst
end

function OriginSelectionPresentation_dealloc(object) 
end

function OriginSelectionPresentation_OriginSelectionPresentation_show(this47, heading, rows, page2, pages, __wurst_stackPos50) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos50
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function OriginSelectionPresentation_OriginSelectionPresentation_showError(this48, message1, __wurst_stackPos51) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos51
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function OriginSelectionPresentation_OriginSelectionPresentation_close(this49, __wurst_stackPos52) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos52
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function PlayerCampaignIdentity:create18() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = PlayerCampaignIdentity
	PlayerCampaignIdentity_originPolityId_storage[new_inst] = ""
	return new_inst
end

function PlayerCampaignIdentity_dealloc(object) 
end

function PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin(this36, __wurst_stackPos41) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos41
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	return not((PlayerCampaignIdentity_originPolityId_storage[this36] == ""))
end

function WarcraftCommandChatNatives:create19() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = WarcraftCommandChatNatives
	return new_inst
end

function WarcraftCommandChatNatives_dealloc(object) 
end

function WarcraftCommandChatNatives_WarcraftCommandChatNatives_registerChat(this50, listener2, sender6, prefix1, exact1, __wurst_stackPos53) 
	local inlineDone8 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos53
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone8 = false
	if (listener2 == nil) then
		inlineDone8 = true
	end
	if not(inlineDone8) then
		if (sender6 == nil) then
			if not(inlineDone8) then
				inlineDone8 = true
			end
		end
	end
	if not(inlineDone8) then
		TriggerRegisterPlayerChatEvent(listener2, sender6, prefix1, exact1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function WarcraftCommandChatNatives_WarcraftCommandChatNatives_retire(this51, listener3, __wurst_stackPos54) 
	local inlineDone9 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos54
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone9 = false
	if (listener3 == nil) then
		inlineDone9 = true
	end
	if not(inlineDone9) then
		DestroyTrigger(listener3)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventListener(this52, __wurst_stackPos55) 
	local stackTrace_tempReturn5 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos55
	wurst_stack_depth = (wurst_stack_depth + 1)
	stackTrace_tempReturn5 = GetTriggeringTrigger()
	wurst_stack_depth = (wurst_stack_depth - 1)
	return stackTrace_tempReturn5
end

function WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventPlayer(this53, __wurst_stackPos56) 
	local stackTrace_tempReturn6 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos56
	wurst_stack_depth = (wurst_stack_depth + 1)
	stackTrace_tempReturn6 = GetTriggerPlayer()
	wurst_stack_depth = (wurst_stack_depth - 1)
	return stackTrace_tempReturn6
end

function WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventText(this54, __wurst_stackPos57) 
	local stackTrace_tempReturn7 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos57
	wurst_stack_depth = (wurst_stack_depth + 1)
	stackTrace_tempReturn7 = GetEventPlayerChatString()
	wurst_stack_depth = (wurst_stack_depth - 1)
	return stackTrace_tempReturn7
end

function WarcraftOriginPresentation:create20() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = WarcraftOriginPresentation
	return new_inst
end

function WarcraftOriginPresentation_dealloc(object) 
end

function WarcraftOriginPresentation_WarcraftOriginPresentation_show(this55, heading1, rows1, page3, pages1, __wurst_stackPos58) 
	local toPlayer = nil
	local inlineDone10 = nil
	local y6 = nil
	local x8 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos58
	wurst_stack_depth = (wurst_stack_depth + 1)
	toPlayer = Player(0)
	x8 = __wurst_stringConcat(heading1, "\nPage ", "when calling __wurst_stringConcat")
	wurst_stack[wurst_stack_depth] = "when calling toString in CommandRouter, line 337"
	wurst_stack_depth = (wurst_stack_depth + 1)
	y6 = tostring(page3)
	wurst_stack_depth = (wurst_stack_depth - 1)
	x8 = __wurst_stringConcat(x8, y6, "when calling __wurst_stringConcat")
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x8 == nil)) then
		if not(("/" == nil)) then
			x8 = __wurst_rawConcat(x8, "/")
		end
	else
		x8 = "/"
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toString in CommandRouter, line 337"
	wurst_stack_depth = (wurst_stack_depth + 1)
	y6 = tostring(pages1)
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x8 == nil)) then
		if not((y6 == nil)) then
			x8 = __wurst_rawConcat(x8, y6)
		end
	else
		x8 = y6
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x8 == nil)) then
		if not(("\n" == nil)) then
			x8 = __wurst_rawConcat(x8, "\n")
		end
	else
		x8 = "\n"
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x8 == nil)) then
		if not((rows1 == nil)) then
			x8 = __wurst_rawConcat(x8, rows1)
		end
	else
		x8 = rows1
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x8 == nil)) then
		if not(("\nUse /origin page N, /origin search WORDS, or /origin choose ID." == nil)) then
			x8 = __wurst_rawConcat(x8, "\nUse /origin page N, /origin search WORDS, or /origin choose ID.")
		end
	else
		x8 = "\nUse /origin page N, /origin search WORDS, or /origin choose ID."
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	inlineDone10 = false
	if (toPlayer == nil) then
		inlineDone10 = true
	end
	if not(inlineDone10) then
		DisplayTimedTextToPlayer(toPlayer, 0., 0., 30., x8)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function WarcraftOriginPresentation_WarcraftOriginPresentation_showError(this56, message2, __wurst_stackPos59) 
	local toPlayer1 = nil
	local inlineDone11 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos59
	wurst_stack_depth = (wurst_stack_depth + 1)
	toPlayer1 = Player(0)
	inlineDone11 = false
	if (toPlayer1 == nil) then
		inlineDone11 = true
	end
	if not(inlineDone11) then
		DisplayTimedTextToPlayer(toPlayer1, 0., 0., 12., message2)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function WarcraftOriginPresentation_WarcraftOriginPresentation_close(this57, __wurst_stackPos60) 
	local toPlayer2 = nil
	local inlineDone12 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos60
	wurst_stack_depth = (wurst_stack_depth + 1)
	toPlayer2 = Player(0)
	inlineDone12 = false
	if (toPlayer2 == nil) then
		inlineDone12 = true
	end
	if not(inlineDone12) then
		DisplayTimedTextToPlayer(toPlayer2, 0., 0., 12., "Origin confirmed. Your current allegiance begins there, but may change later.")
	end
	PauseGame(false)
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function WarcraftOutput:create21() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = WarcraftOutput
	return new_inst
end

function WarcraftOutput_dealloc(object) 
end

function WarcraftOutput_WarcraftOutput_show(this58, p, message3, __wurst_stackPos61) 
	local inlineDone13 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos61
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone13 = false
	if (p == nil) then
		inlineDone13 = true
	end
	if not(inlineDone13) then
		DisplayTimedTextToPlayer(p, 0., 0., 12., message3)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function ErrorListener:create22() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = ErrorListener
	return new_inst
end

function ErrorListener_dealloc(object) 
end

function ErrorListener_ErrorListener_onError(this59, msg, __wurst_stackPos62) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos62
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function Table:create23() 
	local new_inst
	if (__wurst_objectFreeCount == 0) then
		__wurst_objectMax = (__wurst_objectMax + 1)
		new_inst = __wurst_objectMax
	else
		new_inst = __wurst_objectFree[__wurst_objectFreeCount]
		__wurst_objectFree[__wurst_objectFreeCount] = nil
		__wurst_objectFreeCount = (__wurst_objectFreeCount - 1)
	end
	__wurst_objectClass[new_inst] = Table
	return new_inst
end

function Table_dealloc(object) 
end

function Table_Table_saveString(this60, parentKey, value4, __wurst_stackPos63) 
	local this61 = nil
	local parentKey1 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos63
	wurst_stack_depth = (wurst_stack_depth + 1)
	this61 = Table_ht
	parentKey1 = __wurst_classToIndex(this60)
	wurst_stack[wurst_stack_depth] = "when calling saveString in Table, line 62"
	wurst_stack_depth = (wurst_stack_depth + 1)
	__wurst_SaveStr(this61, parentKey1, parentKey, value4)
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
end

function Table_new_Table(__wurst_stackPos64) 
	local this62 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos64
	wurst_stack_depth = (wurst_stack_depth + 1)
	this62 = Table:create23()
	wurst_stack[wurst_stack_depth] = "when calling construct_Table in Table, line 6"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling Table_init in Table, line 6"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	return this62
end

function initGlobals(__wurst_stackPos65) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos65
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function __wurst_rawConcat(x, y) 
	return x .. y
end

function __wurst_stringConcat(x1, y1, __wurst_stackPos6) 
	local result1 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos6
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x1 == nil)) then
		if not((y1 == nil)) then
			result1 = __wurst_rawConcat(x1, y1)
		else
			result1 = x1
		end
	else
		result1 = y1
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return result1
end

function main() 
	__wurst_init_bootstrap()
	initGlobals("when calling initGlobals")
	wurst_stack[wurst_stack_depth] = "when calling initCompiletimeState in blizzard, line 1"
	wurst_stack_depth = (wurst_stack_depth + 1)
	bridge_initCompiletimeState_0()
	wurst_stack_depth = (wurst_stack_depth - 1)
	InitBlizzard()
	if not xpcall(init_AbilityIds, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package AbilityIds.", "<lua error>")
	end
	if not xpcall(init_Angle, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Angle.", "<lua error>")
	end
	if not xpcall(init_Real, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Real.", "<lua error>")
	end
	if not xpcall(init_Integer, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Integer.", "<lua error>")
	end
	if not xpcall(init_Maths, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Maths.", "<lua error>")
	end
	if not xpcall(init_String, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package String.", "<lua error>")
	end
	if not xpcall(init_Vectors, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Vectors.", "<lua error>")
	end
	if not xpcall(init_Destructable, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Destructable.", "<lua error>")
	end
	if not xpcall(init_Player, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Player.", "<lua error>")
	end
	if not xpcall(init_Basics, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Basics.", "<lua error>")
	end
	if not xpcall(init_Printing, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Printing.", "<lua error>")
	end
	if not xpcall(init_MagicFunctions, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package MagicFunctions.", "<lua error>")
	end
	if not xpcall(init_GameTimer, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package GameTimer.", "<lua error>")
	end
	if not xpcall(init_ErrorHandling, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package ErrorHandling.", "<lua error>")
	end
	if not xpcall(init_Matrices, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Matrices.", "<lua error>")
	end
	if not xpcall(init_Quaternion, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Quaternion.", "<lua error>")
	end
	if not xpcall(init_Table, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Table.", "<lua error>")
	end
	if not xpcall(init_Force, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Force.", "<lua error>")
	end
	if not xpcall(init_Playercolor, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Playercolor.", "<lua error>")
	end
	if not xpcall(init_Colors, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Colors.", "<lua error>")
	end
	if not xpcall(init_Framehandle, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Framehandle.", "<lua error>")
	end
	if not xpcall(init_Group, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Group.", "<lua error>")
	end
	if not xpcall(init_Lightning, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Lightning.", "<lua error>")
	end
	if not xpcall(init_WeatherEffects, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package WeatherEffects.", "<lua error>")
	end
	if not xpcall(init_TypeCasting, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package TypeCasting.", "<lua error>")
	end
	if not xpcall(init_HashList, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package HashList.", "<lua error>")
	end
	if not xpcall(init_EventHelper, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package EventHelper.", "<lua error>")
	end
	if not xpcall(init_WC3Compatibility, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package WC3Compatibility.", "<lua error>")
	end
	if not xpcall(init_CommandRouter, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package CommandRouter.", "<lua error>")
	end
	if not xpcall(init_ScenarioData, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package ScenarioData.", "<lua error>")
	end
	if not xpcall(init_CampaignSaveManager, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package CampaignSaveManager.", "<lua error>")
	end
	if not xpcall(init_ScenarioSettings, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package ScenarioSettings.", "<lua error>")
	end
	if not xpcall(init_CampaignHandoff, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package CampaignHandoff.", "<lua error>")
	end
	if not xpcall(init_Bootstrap, function(err) if err == "__wurst_abort_thread" then return end BJDebugMsg("lua init error: " .. tostring(err)) xpcall(function() error1(tostring(err), "<lua error>") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) end) end) then
	    error1("Could not initialize package Bootstrap.", "<lua error>")
	end
end

function config() 
	__wurst_init_bootstrap()
	local whichPlayer1 = nil
	local color = nil
	local value6 = nil
	SetMapName("Age of Sail: The World")
	SetMapDescription("")
	SetPlayers(1)
	SetTeams(1)
	whichPlayer1 = MAP_PLACEMENT_TEAMS_TOGETHER
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		SetGamePlacement(whichPlayer1)
	end
	DefineStartLocation(0, -(128.0), 64.0)
	whichPlayer1 = Player(0)
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		SetPlayerStartLocation(whichPlayer1, 0)
	end
	whichPlayer1 = Player(0)
	color = ConvertPlayerColor(0)
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		if (color == nil) then
			if not(value6) then
				value6 = true
			end
		end
	end
	if not(value6) then
		SetPlayerColor(whichPlayer1, color)
	end
	whichPlayer1 = Player(0)
	color = RACE_PREF_HUMAN
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		if (color == nil) then
			if not(value6) then
				value6 = true
			end
		end
	end
	if not(value6) then
		SetPlayerRacePreference(whichPlayer1, color)
	end
	whichPlayer1 = Player(0)
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		SetPlayerRaceSelectable(whichPlayer1, true)
	end
	whichPlayer1 = Player(0)
	color = MAP_CONTROL_USER
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		if (color == nil) then
			if not(value6) then
				value6 = true
			end
		end
	end
	if not(value6) then
		SetPlayerController(whichPlayer1, color)
	end
	whichPlayer1 = Player(0)
	value6 = false
	if (whichPlayer1 == nil) then
		value6 = true
	end
	if not(value6) then
		SetPlayerTeam(whichPlayer1, 0)
	end
	SetStartLocPrioCount(0, 0)
	SetEnemyStartLocPrioCount(0, 0)
end

function init_AbilityIds(__wurst_stackPos66) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos66
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Angle(__wurst_stackPos68) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos68
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Basics(__wurst_stackPos76) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos76
	wurst_stack_depth = (wurst_stack_depth + 1)
	Basics_ANIMATION_PERIOD = 0.030
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function __wurst_callback_error(err) 
	if err == "__wurst_abort_thread" then return end
	BJDebugMsg("lua callback error: " .. tostring(err))
	xpcall(function() error1(tostring(err), "in lua callback error handler") end, function(err2) if err2 == "__wurst_abort_thread" then return end BJDebugMsg("error reporting error: " .. tostring(err2)) BJDebugMsg("while reporting: " .. tostring(err)) end)
end

function __wurst_callback_bridge_openBootstrapOriginSelection(...) 
	xpcall(bridge_openBootstrapOriginSelection, __wurst_callback_error, ...)
end

function init_Bootstrap(__wurst_stackPos100) 
	local p1 = nil
	local this63 = nil
	local this64 = nil
	local this65 = nil
	local this66 = nil
	local this67 = nil
	local this68 = nil
	local this69 = nil
	local this70 = nil
	local this71 = nil
	local fileName = nil
	local mission2 = nil
	local this72 = nil
	local this73 = nil
	local this74 = nil
	local whichTimer = nil
	local inlineDone14 = nil
	local toPlayer3 = nil
	local duration1 = nil
	local inlineDone15 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos100
	wurst_stack_depth = (wurst_stack_depth + 1)
	Bootstrap_bootstrapOriginSelection = nil
	wurst_stack[wurst_stack_depth] = "when calling requireWC3Compatibility in Bootstrap, line 21"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if ((((not(WC3Compatibility_WC3_HAS_MODERN_INVENTORY) or not(WC3Compatibility_WC3_HAS_NATIVE_SAVE_MANAGEMENT)) or not(WC3Compatibility_WC3_HAS_FRAME_UI)) or not(WC3Compatibility_WC3_HAS_PATHING_QUERIES)) or not(WC3Compatibility_WC3_HAS_MODERN_UNIT_FIELDS)) then
		fileName = WC3Compatibility_WC3_COMPAT_PATCH_FAMILY
		wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not(("WC3Compatibility: required Warcraft III " == nil)) then
			if not((fileName == nil)) then
				mission2 = __wurst_rawConcat("WC3Compatibility: required Warcraft III ", fileName)
			else
				mission2 = "WC3Compatibility: required Warcraft III "
			end
		else
			mission2 = fileName
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not((mission2 == nil)) then
			if not((" / " == nil)) then
				mission2 = __wurst_rawConcat(mission2, " / ")
			end
		else
			mission2 = " / "
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		fileName = WC3Compatibility_WC3_COMPAT_SCRIPT_BACKEND
		wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not((mission2 == nil)) then
			if not((fileName == nil)) then
				mission2 = __wurst_rawConcat(mission2, fileName)
			end
		else
			mission2 = fileName
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not((mission2 == nil)) then
			if not((" capabilities are unavailable" == nil)) then
				mission2 = __wurst_rawConcat(mission2, " capabilities are unavailable")
			end
		else
			mission2 = " capabilities are unavailable"
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		error1(mission2, "when calling error in WC3Compatibility, line 32")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling createCommandRegistry in Bootstrap, line 22"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling new_WarcraftOutput in CommandRouter, line 279"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this65 = WarcraftOutput:create21()
	wurst_stack[wurst_stack_depth] = "when calling construct_WarcraftOutput in CommandRouter, line 10"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling WarcraftOutput_init in CommandRouter, line 10"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling createCommandRegistry in CommandRouter, line 279"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling new_CommandText in CommandRouter, line 273"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this64 = CommandText:create11()
	wurst_stack[wurst_stack_depth] = "when calling construct_CommandText in CommandRouter, line 13"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling CommandText_init in CommandRouter, line 13"
	wurst_stack_depth = (wurst_stack_depth + 1)
	CommandText_heading_storage[this64] = "Available commands"
	CommandText_invalidPage_storage[this64] = "Invalid help page. Enter a page number between 1 and {pages}."
	CommandText_unknownTopic_storage[this64] = "Unknown help topic: {topic}. Enter /help to list available commands."
	CommandText_malformedHelp_storage[this64] = "Malformed help request. Use /help, /help <page>, or /help <command>."
	CommandText_unavailable_storage[this64] = "That command is unavailable in this build."
	CommandText_unknown_storage[this64] = "Unknown command. Enter /help to list available commands."
	CommandText_invalidArguments_storage[this64] = "Invalid arguments. Usage: /"
	CommandText_conflict_storage[this64] = "Ambiguous command registration: '{token}' is already registered."
	wurst_stack_depth = (((wurst_stack_depth - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_CommandRegistry in CommandRouter, line 273"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this63 = CommandRegistry:create10()
	wurst_stack[wurst_stack_depth] = "when calling construct_CommandRegistry in CommandRouter, line 134"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling CommandRegistry_init in CommandRouter, line 134"
	wurst_stack_depth = (wurst_stack_depth + 1)
	CommandRegistry_size_storage[this63] = 0
	wurst_stack_depth = (wurst_stack_depth - 1)
	CommandRegistry_debug_storage[this63] = false
	CommandRegistry_pageSize_storage[this63] = 6
	CommandRegistry_text_storage[this63] = this64
	CommandRegistry_output_storage[this63] = this65
	if (CommandRegistry_pageSize_storage[this63] < 1) then
		CommandRegistry_pageSize_storage[this63] = 6
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	mission2 = CommandRegistry_CommandRegistry_register(this63, "help", "commands", "help [page|command]", "Show command help.", "List available commands or show help for one command.", 0, 1, CommandRouter_COMMAND_RELEASE, nil, "when calling register in CommandRouter, line 274")
	if not((mission2 == "")) then
		error1(mission2, "when calling error in CommandRouter, line 276")
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_WarcraftOriginPresentation in Bootstrap, line 23"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this68 = WarcraftOriginPresentation:create20()
	wurst_stack[wurst_stack_depth] = "when calling construct_WarcraftOriginPresentation in CommandRouter, line 335"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling WarcraftOriginPresentation_init in CommandRouter, line 335"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_PlayerCampaignIdentity in Bootstrap, line 23"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this69 = PlayerCampaignIdentity:create18()
	wurst_stack[wurst_stack_depth] = "when calling construct_PlayerCampaignIdentity in CommandRouter, line 281"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling PlayerCampaignIdentity_init in CommandRouter, line 281"
	wurst_stack_depth = (wurst_stack_depth + 1)
	PlayerCampaignIdentity_originPolityId_storage[this69] = ""
	wurst_stack_depth = (((wurst_stack_depth - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_NewCampaignOriginController in Bootstrap, line 23"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this66 = NewCampaignOriginController:create12()
	wurst_stack[wurst_stack_depth] = "when calling construct_NewCampaignOriginController in CommandRouter, line 392"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling construct_OriginCatalog in CommandRouter, line 392"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling OriginCatalog_init in CommandRouter, line 361"
	wurst_stack_depth = (wurst_stack_depth + 1)
	OriginCatalog_count_storage[this66] = 0
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling NewCampaignOriginController_init in CommandRouter, line 392"
	wurst_stack_depth = (wurst_stack_depth + 1)
	NewCampaignOriginController_query_storage[this66] = ""
	NewCampaignOriginController_observer_storage[this66] = nil
	wurst_stack_depth = (wurst_stack_depth - 1)
	NewCampaignOriginController_pageSize_storage[this66] = 8
	if (NewCampaignOriginController_pageSize_storage[this66] < 1) then
		NewCampaignOriginController_pageSize_storage[this66] = 8
	end
	NewCampaignOriginController_presentation_storage[this66] = this68
	NewCampaignOriginController_identity_storage[this66] = this69
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	Bootstrap_bootstrapOriginSelection = this66
	fileName = ScenarioSettings_CAMPAIGN_CACHE_FILE
	wurst_stack[wurst_stack_depth] = "when calling new_WarcraftCampaignSaveStorage in Bootstrap, line 24"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this71 = WarcraftCampaignSaveStorage:create5()
	wurst_stack[wurst_stack_depth] = "when calling construct_WarcraftCampaignSaveStorage2 in CampaignSaveManager, line 183"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling WarcraftCampaignSaveStorage_init in CampaignSaveManager, line 183"
	wurst_stack_depth = (wurst_stack_depth + 1)
	WarcraftCampaignSaveStorage_mission_storage[this71] = "campaign"
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling compatInitGameCache in CampaignSaveManager, line 184"
	wurst_stack_depth = (wurst_stack_depth + 1)
	whichTimer = InitGameCache(fileName)
	wurst_stack_depth = (wurst_stack_depth - 1)
	WarcraftCampaignSaveStorage_cache_storage[this71] = whichTimer
	WarcraftCampaignSaveStorage_mission_storage[this71] = "bootstrap"
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_WarcraftPhysicalMapLoader in Bootstrap, line 24"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this72 = WarcraftPhysicalMapLoader:create3()
	wurst_stack[wurst_stack_depth] = "when calling construct_WarcraftPhysicalMapLoader in CampaignHandoff, line 14"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling WarcraftPhysicalMapLoader_init in CampaignHandoff, line 14"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_CampaignHandoff in Bootstrap, line 24"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this70 = CampaignHandoff:create()
	wurst_stack[wurst_stack_depth] = "when calling construct_CampaignHandoff in CampaignHandoff, line 62"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling CampaignHandoff_init in CampaignHandoff, line 62"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	CampaignHandoff_storage_storage[this70] = this71
	CampaignHandoff_loader_storage[this70] = this72
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	NewCampaignOriginController_NewCampaignOriginController_setObserver(Bootstrap_bootstrapOriginSelection, this70, "when calling setObserver in Bootstrap, line 24")
	this67 = Bootstrap_bootstrapOriginSelection
	wurst_stack[wurst_stack_depth] = "when calling configureGeneratedOrigins in Bootstrap, line 25"
	wurst_stack_depth = (wurst_stack_depth + 1)
	OriginCatalog_OriginCatalog_add(this67, "acolhua_texcoco", "Acolhua of Texcoco", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "texcoco", "when calling add in ScenarioData, line 11")
	OriginCatalog_OriginCatalog_setPosition(this67, "acolhua_texcoco", -(64.0), -(6848.0), "when calling setPosition in ScenarioData, line 12")
	OriginCatalog_OriginCatalog_add(this67, "ainu_moshir", "Ainu Mosir", "east_asia", "Maps/EastAsia.w3x", "east_asia_japan", "ainu_council_place", "when calling add in ScenarioData, line 13")
	OriginCatalog_OriginCatalog_setPosition(this67, "ainu_moshir", -(4928.0), 5568.0, "when calling setPosition in ScenarioData, line 14")
	OriginCatalog_OriginCatalog_add(this67, "ajuran_sultanate", "Ajuran Sultanate", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "mareeg", "when calling add in ScenarioData, line 15")
	OriginCatalog_OriginCatalog_setPosition(this67, "ajuran_sultanate", 4672.0, -(5440.0), "when calling setPosition in ScenarioData, line 16")
	OriginCatalog_OriginCatalog_add(this67, "amazonian_regional_societies", "Amazonian Regional Societies", "americas_south", "Maps/AmericasSouth.w3x", "americas_amazon_brazil", "amazonian_earthwork_centers", "when calling add in ScenarioData, line 17")
	OriginCatalog_OriginCatalog_setPosition(this67, "amazonian_regional_societies", -(1472.0), -(3008.0), "when calling setPosition in ScenarioData, line 18")
	OriginCatalog_OriginCatalog_add(this67, "anishinaabe_networks", "Anishinaabe Networks", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_atlantic", "anishinaabe_seasonal_council", "when calling add in ScenarioData, line 19")
	OriginCatalog_OriginCatalog_setPosition(this67, "anishinaabe_networks", 6208.0, -(1088.0), "when calling setPosition in ScenarioData, line 20")
	OriginCatalog_OriginCatalog_add(this67, "aq_qoyunlu", "Aq Qoyunlu Confederation", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_mesopotamia_persia", "amid", "when calling add in ScenarioData, line 21")
	OriginCatalog_OriginCatalog_setPosition(this67, "aq_qoyunlu", 4672.0, -(6592.0), "when calling setPosition in ScenarioData, line 22")
	OriginCatalog_OriginCatalog_add(this67, "austria", "Archduchy of Austria", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "vienna", "when calling add in ScenarioData, line 23")
	OriginCatalog_OriginCatalog_setPosition(this67, "austria", 576.0, 64.0, "when calling setPosition in ScenarioData, line 24")
	OriginCatalog_OriginCatalog_add(this67, "ashikaga_shogunate", "Ashikaga Shogunate", "east_asia", "Maps/EastAsia.w3x", "east_asia_japan", "kyoto", "when calling add in ScenarioData, line 25")
	OriginCatalog_OriginCatalog_setPosition(this67, "ashikaga_shogunate", -(6848.0), 3008.0, "when calling setPosition in ScenarioData, line 26")
	OriginCatalog_OriginCatalog_add(this67, "bahmani_sultanate", "Bahmani Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "bidar", "when calling add in ScenarioData, line 27")
	OriginCatalog_OriginCatalog_setPosition(this67, "bahmani_sultanate", 2752.0, -(3136.0), "when calling setPosition in ScenarioData, line 28")
	OriginCatalog_OriginCatalog_add(this67, "bali_kingdoms", "Balinese Kingdoms", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_java_sunda", "gelgel", "when calling add in ScenarioData, line 29")
	OriginCatalog_OriginCatalog_setPosition(this67, "bali_kingdoms", 4032.0, -(11328.0), "when calling setPosition in ScenarioData, line 30")
	OriginCatalog_OriginCatalog_add(this67, "beja_confederations", "Beja Confederations", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "suakin", "when calling add in ScenarioData, line 31")
	OriginCatalog_OriginCatalog_setPosition(this67, "beja_confederations", -(1472.0), -(2752.0), "when calling setPosition in ScenarioData, line 32")
	OriginCatalog_OriginCatalog_add(this67, "belau_chiefdoms", "Belau Chiefdoms", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "belau_council", "when calling add in ScenarioData, line 33")
	OriginCatalog_OriginCatalog_setPosition(this67, "belau_chiefdoms", -(1216.0), -(1472.0), "when calling setPosition in ScenarioData, line 34")
	OriginCatalog_OriginCatalog_add(this67, "bengal_sultanate", "Bengal Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "gaur", "when calling add in ScenarioData, line 35")
	OriginCatalog_OriginCatalog_setPosition(this67, "bengal_sultanate", 3136.0, -(832.0), "when calling setPosition in ScenarioData, line 36")
	OriginCatalog_OriginCatalog_add(this67, "bismarck_island_communities", "Bismarck Island Communities", "pacific_melanesia", "Maps/PacificMelanesia.w3x", "pacific_melanesia", "bismarck_council", "when calling add in ScenarioData, line 37")
	OriginCatalog_OriginCatalog_setPosition(this67, "bismarck_island_communities", 576.0, -(704.0), "when calling setPosition in ScenarioData, line 38")
	OriginCatalog_OriginCatalog_add(this67, "bonoman", "Bonoman", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "begho", "when calling add in ScenarioData, line 39")
	OriginCatalog_OriginCatalog_setPosition(this67, "bonoman", -(1984.0), -(5056.0), "when calling setPosition in ScenarioData, line 40")
	OriginCatalog_OriginCatalog_add(this67, "brunei_sultanate", "Brunei Sultanate", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_borneo", "brunei", "when calling add in ScenarioData, line 41")
	OriginCatalog_OriginCatalog_setPosition(this67, "brunei_sultanate", -(8256.0), -(5824.0), "when calling setPosition in ScenarioData, line 42")
	OriginCatalog_OriginCatalog_add(this67, "burgundy", "Burgundian State", "europe_west", "Maps/EuropeWest.w3x", "europe_france_low_countries", "dijon", "when calling add in ScenarioData, line 43")
	OriginCatalog_OriginCatalog_setPosition(this67, "burgundy", 6464.0, 3008.0, "when calling setPosition in ScenarioData, line 44")
	OriginCatalog_OriginCatalog_add(this67, "chalco_confederation", "Chalco Confederation", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "chalco_atenco", "when calling add in ScenarioData, line 45")
	OriginCatalog_OriginCatalog_setPosition(this67, "chalco_confederation", -(64.0), -(7232.0), "when calling setPosition in ScenarioData, line 46")
	OriginCatalog_OriginCatalog_add(this67, "chamorro_chiefdoms", "Chamorro Chiefdoms", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "guam_council", "when calling add in ScenarioData, line 47")
	OriginCatalog_OriginCatalog_setPosition(this67, "chamorro_chiefdoms", -(576.0), 1472.0, "when calling setPosition in ScenarioData, line 48")
	OriginCatalog_OriginCatalog_add(this67, "charrua_minuan_networks", "Charrúa and Minuán Networks", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "charrua_seasonal_assemblies", "when calling add in ScenarioData, line 49")
	OriginCatalog_OriginCatalog_setPosition(this67, "charrua_minuan_networks", 6848.0, -(6976.0), "when calling setPosition in ScenarioData, line 50")
	OriginCatalog_OriginCatalog_add(this67, "chincha_lordship", "Chincha Lordship", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "la_cent_in", "when calling add in ScenarioData, line 51")
	OriginCatalog_OriginCatalog_setPosition(this67, "chincha_lordship", 3776.0, -(2624.0), "when calling setPosition in ScenarioData, line 52")
	OriginCatalog_OriginCatalog_add(this67, "provence", "County of Provence", "europe_west", "Maps/EuropeWest.w3x", "europe_france_low_countries", "aix_en_provence", "when calling add in ScenarioData, line 53")
	OriginCatalog_OriginCatalog_setPosition(this67, "provence", 576.0, 448.0, "when calling setPosition in ScenarioData, line 54")
	OriginCatalog_OriginCatalog_add(this67, "crimea", "Crimean Khanate", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "solkhat", "when calling add in ScenarioData, line 55")
	OriginCatalog_OriginCatalog_setPosition(this67, "crimea", -(192.0), -(3904.0), "when calling setPosition in ScenarioData, line 56")
	OriginCatalog_OriginCatalog_add(this67, "aragon", "Crown of Aragon", "europe_west", "Maps/EuropeWest.w3x", "europe_iberia_western_med", "zaragoza", "when calling add in ScenarioData, line 57")
	OriginCatalog_OriginCatalog_setPosition(this67, "aragon", -(6976.0), 4032.0, "when calling setPosition in ScenarioData, line 58")
	OriginCatalog_OriginCatalog_add(this67, "bohemia", "Crown of Bohemia", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "prague", "when calling add in ScenarioData, line 59")
	OriginCatalog_OriginCatalog_setPosition(this67, "bohemia", 704.0, -(2752.0), "when calling setPosition in ScenarioData, line 60")
	OriginCatalog_OriginCatalog_add(this67, "castile", "Crown of Castile", "europe_west", "Maps/EuropeWest.w3x", "europe_iberia_western_med", "toledo", "when calling add in ScenarioData, line 61")
	OriginCatalog_OriginCatalog_setPosition(this67, "castile", -(3520.0), -(1472.0), "when calling setPosition in ScenarioData, line 62")
	OriginCatalog_OriginCatalog_add(this67, "delhi_sultanate", "Delhi Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_ganges_himalaya", "delhi", "when calling add in ScenarioData, line 63")
	OriginCatalog_OriginCatalog_setPosition(this67, "delhi_sultanate", 1984.0, -(576.0), "when calling setPosition in ScenarioData, line 64")
	OriginCatalog_OriginCatalog_add(this67, "diaguita_calchaqui_lordships", "Diaguita-Calchaquí Lordships", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "calchaqui_pukara_network", "when calling add in ScenarioData, line 65")
	OriginCatalog_OriginCatalog_setPosition(this67, "diaguita_calchaqui_lordships", 8000.0, -(8128.0), "when calling setPosition in ScenarioData, line 66")
	OriginCatalog_OriginCatalog_add(this67, "bavaria", "Duchy of Bavaria", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "munich", "when calling add in ScenarioData, line 67")
	OriginCatalog_OriginCatalog_setPosition(this67, "bavaria", 5312.0, 3648.0, "when calling setPosition in ScenarioData, line 68")
	OriginCatalog_OriginCatalog_add(this67, "brittany", "Duchy of Brittany", "europe_west", "Maps/EuropeWest.w3x", "europe_france_low_countries", "nantes", "when calling add in ScenarioData, line 69")
	OriginCatalog_OriginCatalog_setPosition(this67, "brittany", -(6080.0), -(3648.0), "when calling setPosition in ScenarioData, line 70")
	OriginCatalog_OriginCatalog_add(this67, "milan", "Duchy of Milan", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "milan", "when calling add in ScenarioData, line 71")
	OriginCatalog_OriginCatalog_setPosition(this67, "milan", 6080.0, 3264.0, "when calling setPosition in ScenarioData, line 72")
	OriginCatalog_OriginCatalog_add(this67, "savoy", "Duchy of Savoy", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "chambery", "when calling add in ScenarioData, line 73")
	OriginCatalog_OriginCatalog_setPosition(this67, "savoy", 832.0, -(960.0), "when calling setPosition in ScenarioData, line 74")
	OriginCatalog_OriginCatalog_add(this67, "dulkadirids", "Dulkadirid Principality", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_anatolia_levant", "el_bistan", "when calling add in ScenarioData, line 75")
	OriginCatalog_OriginCatalog_setPosition(this67, "dulkadirids", -(4288.0), -(5312.0), "when calling setPosition in ScenarioData, line 76")
	OriginCatalog_OriginCatalog_add(this67, "new_guinea_exchange_communities", "Eastern New Guinea Communities", "pacific_melanesia", "Maps/PacificMelanesia.w3x", "pacific_melanesia", "new_guinea_council", "when calling add in ScenarioData, line 77")
	OriginCatalog_OriginCatalog_setPosition(this67, "new_guinea_exchange_communities", -(2752.0), 704.0, "when calling setPosition in ScenarioData, line 78")
	OriginCatalog_OriginCatalog_add(this67, "palatinate", "Electoral Palatinate", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "heidelberg", "when calling add in ScenarioData, line 79")
	OriginCatalog_OriginCatalog_setPosition(this67, "palatinate", 1728.0, -(5824.0), "when calling setPosition in ScenarioData, line 80")
	OriginCatalog_OriginCatalog_add(this67, "saxony", "Electorate of Saxony", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "wittenberg", "when calling add in ScenarioData, line 81")
	OriginCatalog_OriginCatalog_setPosition(this67, "saxony", 576.0, -(3776.0), "when calling setPosition in ScenarioData, line 82")
	OriginCatalog_OriginCatalog_add(this67, "granada", "Emirate of Granada", "europe_west", "Maps/EuropeWest.w3x", "europe_iberia_western_med", "granada", "when calling add in ScenarioData, line 83")
	OriginCatalog_OriginCatalog_setPosition(this67, "granada", 6848.0, 960.0, "when calling setPosition in ScenarioData, line 84")
	OriginCatalog_OriginCatalog_add(this67, "trebizond_empire", "Empire of Trebizond", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_anatolia_levant", "trebizond", "when calling add in ScenarioData, line 85")
	OriginCatalog_OriginCatalog_setPosition(this67, "trebizond_empire", -(4288.0), -(5312.0), "when calling setPosition in ScenarioData, line 86")
	OriginCatalog_OriginCatalog_add(this67, "ethiopian_empire", "Ethiopian Empire", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "ethiopian_royal_camp", "when calling add in ScenarioData, line 87")
	OriginCatalog_OriginCatalog_setPosition(this67, "ethiopian_empire", -(576.0), 6848.0, "when calling setPosition in ScenarioData, line 88")
	OriginCatalog_OriginCatalog_add(this67, "khandesh_sultanate", "Faruqi Sultanate of Khandesh", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "burhanpur", "when calling add in ScenarioData, line 89")
	OriginCatalog_OriginCatalog_setPosition(this67, "khandesh_sultanate", -(3776.0), -(5568.0), "when calling setPosition in ScenarioData, line 90")
	OriginCatalog_OriginCatalog_add(this67, "fijian_vanua", "Fijian Vanua", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_west_polynesia", "fiji_council", "when calling add in ScenarioData, line 91")
	OriginCatalog_OriginCatalog_setPosition(this67, "fijian_vanua", 5952.0, -(960.0), "when calling setPosition in ScenarioData, line 92")
	OriginCatalog_OriginCatalog_add(this67, "fouta_jallon_polities", "Fouta Jallon Polities", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "timbo", "when calling add in ScenarioData, line 93")
	OriginCatalog_OriginCatalog_setPosition(this67, "fouta_jallon_polities", -(960.0), -(6720.0), "when calling setPosition in ScenarioData, line 94")
	OriginCatalog_OriginCatalog_add(this67, "gajapati_empire", "Gajapati Empire", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "cuttack", "when calling add in ScenarioData, line 95")
	OriginCatalog_OriginCatalog_setPosition(this67, "gajapati_empire", -(4288.0), -(5312.0), "when calling setPosition in ScenarioData, line 96")
	OriginCatalog_OriginCatalog_add(this67, "golden_horde", "Golden Horde", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "saray", "when calling add in ScenarioData, line 97")
	OriginCatalog_OriginCatalog_setPosition(this67, "golden_horde", 7616.0, -(3008.0), "when calling setPosition in ScenarioData, line 98")
	OriginCatalog_OriginCatalog_add(this67, "gond_kingdoms", "Gond Kingdoms", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "garha", "when calling add in ScenarioData, line 99")
	OriginCatalog_OriginCatalog_setPosition(this67, "gond_kingdoms", -(576.0), -(5184.0), "when calling setPosition in ScenarioData, line 100")
	OriginCatalog_OriginCatalog_add(this67, "lithuania", "Grand Duchy of Lithuania", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "vilnius", "when calling add in ScenarioData, line 101")
	OriginCatalog_OriginCatalog_setPosition(this67, "lithuania", -(960.0), 7360.0, "when calling setPosition in ScenarioData, line 102")
	OriginCatalog_OriginCatalog_add(this67, "muscovy", "Grand Principality of Moscow", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "moscow", "when calling add in ScenarioData, line 103")
	OriginCatalog_OriginCatalog_setPosition(this67, "muscovy", 4160.0, -(6592.0), "when calling setPosition in ScenarioData, line 104")
	OriginCatalog_OriginCatalog_add(this67, "ryazan", "Grand Principality of Ryazan", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "ryazan", "when calling add in ScenarioData, line 105")
	OriginCatalog_OriginCatalog_setPosition(this67, "ryazan", -(5184.0), -(3392.0), "when calling setPosition in ScenarioData, line 106")
	OriginCatalog_OriginCatalog_add(this67, "tver", "Grand Principality of Tver", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "tver", "when calling add in ScenarioData, line 107")
	OriginCatalog_OriginCatalog_setPosition(this67, "tver", -(4032.0), 320.0, "when calling setPosition in ScenarioData, line 108")
	OriginCatalog_OriginCatalog_add(this67, "ming_empire", "Great Ming", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_north", "beijing", "when calling add in ScenarioData, line 109")
	OriginCatalog_OriginCatalog_setPosition(this67, "ming_empire", -(5568.0), -(2368.0), "when calling setPosition in ScenarioData, line 110")
	OriginCatalog_OriginCatalog_add(this67, "guarani_tekohas", "Guaraní Tekohas", "americas_south", "Maps/AmericasSouth.w3x", "americas_amazon_brazil", "guarani_assembly_network", "when calling add in ScenarioData, line 111")
	OriginCatalog_OriginCatalog_setPosition(this67, "guarani_tekohas", -(1344.0), -(7744.0), "when calling setPosition in ScenarioData, line 112")
	OriginCatalog_OriginCatalog_add(this67, "gujarat_sultanate", "Gujarat Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "ahmadabad", "when calling add in ScenarioData, line 113")
	OriginCatalog_OriginCatalog_setPosition(this67, "gujarat_sultanate", -(64.0), -(2496.0), "when calling setPosition in ScenarioData, line 114")
	OriginCatalog_OriginCatalog_add(this67, "hafsid_sultanate", "Hafsid Sultanate", "africa", "Maps/Africa.w3x", "africa_maghreb_med_atlantic", "tunis", "when calling add in ScenarioData, line 115")
	OriginCatalog_OriginCatalog_setPosition(this67, "hafsid_sultanate", 832.0, -(3264.0), "when calling setPosition in ScenarioData, line 116")
	OriginCatalog_OriginCatalog_add(this67, "haixi_jurchen", "Haixi Jurchen", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_north", "haixi_court", "when calling add in ScenarioData, line 117")
	OriginCatalog_OriginCatalog_setPosition(this67, "haixi_jurchen", -(4160.0), -(2112.0), "when calling setPosition in ScenarioData, line 118")
	OriginCatalog_OriginCatalog_add(this67, "hanthawaddy_kingdom", "Hanthawaddy Kingdom", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "pegu", "when calling add in ScenarioData, line 119")
	OriginCatalog_OriginCatalog_setPosition(this67, "hanthawaddy_kingdom", 6720.0, -(7872.0), "when calling setPosition in ScenarioData, line 120")
	OriginCatalog_OriginCatalog_add(this67, "haudenosaunee_nations", "Haudenosaunee Nations", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_atlantic", "haudenosaunee_council_fire", "when calling add in ScenarioData, line 121")
	OriginCatalog_OriginCatalog_setPosition(this67, "haudenosaunee_nations", 8128.0, -(1088.0), "when calling setPosition in ScenarioData, line 122")
	OriginCatalog_OriginCatalog_add(this67, "hawaii_chiefdom", "Hawai‘i Chiefdom", "pacific_north", "Maps/PacificNorth.w3x", "pacific_north_hawaii", "hawaii_royal_center", "when calling add in ScenarioData, line 123")
	OriginCatalog_OriginCatalog_setPosition(this67, "hawaii_chiefdom", -(2496.0), -(3136.0), "when calling setPosition in ScenarioData, line 124")
	OriginCatalog_OriginCatalog_add(this67, "holy_roman_empire", "Holy Roman Empire", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "aachen", "when calling add in ScenarioData, line 125")
	OriginCatalog_OriginCatalog_setPosition(this67, "holy_roman_empire", -(5952.0), -(4416.0), "when calling setPosition in ScenarioData, line 126")
	OriginCatalog_OriginCatalog_add(this67, "igala_kingdom", "Igala Kingdom", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "ida", "when calling add in ScenarioData, line 127")
	OriginCatalog_OriginCatalog_setPosition(this67, "igala_kingdom", 448.0, -(2624.0), "when calling setPosition in ScenarioData, line 128")
	OriginCatalog_OriginCatalog_add(this67, "imerina_chiefdoms", "Imerina Highland Chiefdoms", "africa", "Maps/Africa.w3x", "africa_madagascar_indian_ocean", "alasora", "when calling add in ScenarioData, line 129")
	OriginCatalog_OriginCatalog_setPosition(this67, "imerina_chiefdoms", -(3776.0), -(1344.0), "when calling setPosition in ScenarioData, line 130")
	OriginCatalog_OriginCatalog_add(this67, "inuit_north_atlantic_communities", "Inuit North Atlantic Communities", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_atlantic", "inuit_seasonal_camps", "when calling add in ScenarioData, line 131")
	OriginCatalog_OriginCatalog_setPosition(this67, "inuit_north_atlantic_communities", 5568.0, -(8000.0), "when calling setPosition in ScenarioData, line 132")
	OriginCatalog_OriginCatalog_add(this67, "itza_kingdom", "Itza Kingdom", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "nohpeteen", "when calling add in ScenarioData, line 133")
	OriginCatalog_OriginCatalog_setPosition(this67, "itza_kingdom", -(64.0), -(7232.0), "when calling setPosition in ScenarioData, line 134")
	OriginCatalog_OriginCatalog_add(this67, "jabrids", "Jabrid Emirate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_arabia_red_sea", "al_ahsa", "when calling add in ScenarioData, line 135")
	OriginCatalog_OriginCatalog_setPosition(this67, "jabrids", -(5056.0), -(4800.0), "when calling setPosition in ScenarioData, line 136")
	OriginCatalog_OriginCatalog_add(this67, "jaunpur_sultanate", "Jaunpur Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_ganges_himalaya", "jaunpur", "when calling add in ScenarioData, line 137")
	OriginCatalog_OriginCatalog_setPosition(this67, "jaunpur_sultanate", 2624.0, -(6848.0), "when calling setPosition in ScenarioData, line 138")
	OriginCatalog_OriginCatalog_add(this67, "jianzhou_jurchen", "Jianzhou Jurchen", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_north", "jianzhou_court", "when calling add in ScenarioData, line 139")
	OriginCatalog_OriginCatalog_setPosition(this67, "jianzhou_jurchen", -(4160.0), -(2112.0), "when calling setPosition in ScenarioData, line 140")
	OriginCatalog_OriginCatalog_add(this67, "jolof_empire", "Jolof Empire", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "linguere", "when calling add in ScenarioData, line 141")
	OriginCatalog_OriginCatalog_setPosition(this67, "jolof_empire", 7488.0, -(3776.0), "when calling setPosition in ScenarioData, line 142")
	OriginCatalog_OriginCatalog_add(this67, "kiche_kingdom", "K'iche' Kingdom of Q'umarkaj", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "qumarkaj", "when calling add in ScenarioData, line 143")
	OriginCatalog_OriginCatalog_setPosition(this67, "kiche_kingdom", -(64.0), -(6848.0), "when calling setPosition in ScenarioData, line 144")
	OriginCatalog_OriginCatalog_add(this67, "kalinago_island_communities", "Kalinago Island Communities", "americas_caribbean", "Maps/AmericasCaribbean.w3x", "americas_caribbean_islands", "kalinago_council_network", "when calling add in ScenarioData, line 145")
	OriginCatalog_OriginCatalog_setPosition(this67, "kalinago_island_communities", 1728.0, -(704.0), "when calling setPosition in ScenarioData, line 146")
	OriginCatalog_OriginCatalog_add(this67, "kamata_ahom_states", "Kamata and Ahom Kingdoms", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "kamatapur", "when calling add in ScenarioData, line 147")
	OriginCatalog_OriginCatalog_setPosition(this67, "kamata_ahom_states", -(3776.0), -(5568.0), "when calling setPosition in ScenarioData, line 148")
	OriginCatalog_OriginCatalog_add(this67, "kanak_chiefdoms", "Kanak Chiefdoms", "pacific_melanesia", "Maps/PacificMelanesia.w3x", "pacific_melanesia", "kanak_council", "when calling add in ScenarioData, line 149")
	OriginCatalog_OriginCatalog_setPosition(this67, "kanak_chiefdoms", 2368.0, -(2496.0), "when calling setPosition in ScenarioData, line 150")
	OriginCatalog_OriginCatalog_add(this67, "kanem_bornu", "Kanem-Bornu Empire", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "njimi", "when calling add in ScenarioData, line 151")
	OriginCatalog_OriginCatalog_setPosition(this67, "kanem_bornu", 960.0, -(6592.0), "when calling setPosition in ScenarioData, line 152")
	OriginCatalog_OriginCatalog_add(this67, "kaqchikel_kingdom", "Kaqchikel Kingdom", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "ximche", "when calling add in ScenarioData, line 153")
	OriginCatalog_OriginCatalog_setPosition(this67, "kaqchikel_kingdom", -(1344.0), -(6464.0), "when calling setPosition in ScenarioData, line 154")
	OriginCatalog_OriginCatalog_add(this67, "kara_del_hami", "Kara Del", "east_asia", "Maps/EastAsia.w3x", "east_asia_interior", "hami", "when calling add in ScenarioData, line 155")
	OriginCatalog_OriginCatalog_setPosition(this67, "kara_del_hami", 5696.0, -(3264.0), "when calling setPosition in ScenarioData, line 156")
	OriginCatalog_OriginCatalog_add(this67, "karamanids", "Karamanid Emirate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_anatolia_levant", "konya", "when calling add in ScenarioData, line 157")
	OriginCatalog_OriginCatalog_setPosition(this67, "karamanids", -(6080.0), 576.0, "when calling setPosition in ScenarioData, line 158")
	OriginCatalog_OriginCatalog_add(this67, "kashmir_sultanate", "Kashmir Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_ganges_himalaya", "srinagar", "when calling add in ScenarioData, line 159")
	OriginCatalog_OriginCatalog_setPosition(this67, "kashmir_sultanate", -(5056.0), -(4800.0), "when calling setPosition in ScenarioData, line 160")
	OriginCatalog_OriginCatalog_add(this67, "kathiri", "Kathiri Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_arabia_red_sea", "seiyun", "when calling add in ScenarioData, line 161")
	OriginCatalog_OriginCatalog_setPosition(this67, "kathiri", 2624.0, -(6848.0), "when calling setPosition in ScenarioData, line 162")
	OriginCatalog_OriginCatalog_add(this67, "kauai_chiefdom", "Kaua‘i Chiefdom", "pacific_north", "Maps/PacificNorth.w3x", "pacific_north_hawaii", "kauai_royal_center", "when calling add in ScenarioData, line 163")
	OriginCatalog_OriginCatalog_setPosition(this67, "kauai_chiefdom", -(2624.0), 1728.0, "when calling setPosition in ScenarioData, line 164")
	OriginCatalog_OriginCatalog_add(this67, "kazan", "Khanate of Kazan", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "kazan", "when calling add in ScenarioData, line 165")
	OriginCatalog_OriginCatalog_setPosition(this67, "kazan", 1216.0, -(1728.0), "when calling setPosition in ScenarioData, line 166")
	OriginCatalog_OriginCatalog_add(this67, "khoi_san_polities", "Khoi and San Polities", "africa", "Maps/Africa.w3x", "africa_southern_cape", "khoi_san_seasonal_camp", "when calling add in ScenarioData, line 167")
	OriginCatalog_OriginCatalog_setPosition(this67, "khoi_san_polities", -(4672.0), -(1344.0), "when calling setPosition in ScenarioData, line 168")
	OriginCatalog_OriginCatalog_add(this67, "kilwa_sultanate", "Kilwa Sultanate", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "kilwa", "when calling add in ScenarioData, line 169")
	OriginCatalog_OriginCatalog_setPosition(this67, "kilwa_sultanate", -(1984.0), -(4928.0), "when calling setPosition in ScenarioData, line 170")
	OriginCatalog_OriginCatalog_add(this67, "alodia", "Kingdom of Alodia", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "soba", "when calling add in ScenarioData, line 171")
	OriginCatalog_OriginCatalog_setPosition(this67, "alodia", -(2624.0), -(4032.0), "when calling setPosition in ScenarioData, line 172")
	OriginCatalog_OriginCatalog_add(this67, "ava_kingdom", "Kingdom of Ava", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "ava", "when calling add in ScenarioData, line 173")
	OriginCatalog_OriginCatalog_setPosition(this67, "ava_kingdom", 6464.0, -(4160.0), "when calling setPosition in ScenarioData, line 174")
	OriginCatalog_OriginCatalog_add(this67, "ayutthaya_kingdom", "Kingdom of Ayutthaya", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "ayutthaya", "when calling add in ScenarioData, line 175")
	OriginCatalog_OriginCatalog_setPosition(this67, "ayutthaya_kingdom", 9280.0, -(7744.0), "when calling setPosition in ScenarioData, line 176")
	OriginCatalog_OriginCatalog_add(this67, "benin_kingdom", "Kingdom of Benin", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "benin_city", "when calling add in ScenarioData, line 177")
	OriginCatalog_OriginCatalog_setPosition(this67, "benin_kingdom", -(3648.0), -(2368.0), "when calling setPosition in ScenarioData, line 178")
	OriginCatalog_OriginCatalog_add(this67, "bosnia", "Kingdom of Bosnia", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "jajce", "when calling add in ScenarioData, line 179")
	OriginCatalog_OriginCatalog_setPosition(this67, "bosnia", -(5440.0), -(5056.0), "when calling setPosition in ScenarioData, line 180")
	OriginCatalog_OriginCatalog_add(this67, "buganda_kingdom", "Kingdom of Buganda", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "mengo", "when calling add in ScenarioData, line 181")
	OriginCatalog_OriginCatalog_setPosition(this67, "buganda_kingdom", 5952.0, 4416.0, "when calling setPosition in ScenarioData, line 182")
	OriginCatalog_OriginCatalog_add(this67, "bunyoro_kitara", "Kingdom of Bunyoro-Kitara", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "bigo_bya_mugenyi", "when calling add in ScenarioData, line 183")
	OriginCatalog_OriginCatalog_setPosition(this67, "bunyoro_kitara", 7360.0, -(3392.0), "when calling setPosition in ScenarioData, line 184")
	OriginCatalog_OriginCatalog_add(this67, "champa_kingdom", "Kingdom of Champa", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "vijaya", "when calling add in ScenarioData, line 185")
	OriginCatalog_OriginCatalog_setPosition(this67, "champa_kingdom", 11968.0, -(7872.0), "when calling setPosition in ScenarioData, line 186")
	OriginCatalog_OriginCatalog_add(this67, "chimor_kingdom", "Kingdom of Chimor", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "chan_chan", "when calling add in ScenarioData, line 187")
	OriginCatalog_OriginCatalog_setPosition(this67, "chimor_kingdom", 3776.0, -(2624.0), "when calling setPosition in ScenarioData, line 188")
	OriginCatalog_OriginCatalog_add(this67, "cyprus", "Kingdom of Cyprus", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_anatolia_levant", "nicosia", "when calling add in ScenarioData, line 189")
	OriginCatalog_OriginCatalog_setPosition(this67, "cyprus", -(3136.0), -(5952.0), "when calling setPosition in ScenarioData, line 190")
	OriginCatalog_OriginCatalog_add(this67, "dai_viet", "Kingdom of Dai Viet", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "thang_long", "when calling add in ScenarioData, line 191")
	OriginCatalog_OriginCatalog_setPosition(this67, "dai_viet", 12224.0, -(4160.0), "when calling setPosition in ScenarioData, line 192")
	OriginCatalog_OriginCatalog_add(this67, "denmark", "Kingdom of Denmark", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_baltic_scandinavia", "copenhagen", "when calling add in ScenarioData, line 193")
	OriginCatalog_OriginCatalog_setPosition(this67, "denmark", -(6976.0), 5056.0, "when calling setPosition in ScenarioData, line 194")
	OriginCatalog_OriginCatalog_add(this67, "england", "Kingdom of England", "europe_west", "Maps/EuropeWest.w3x", "europe_atlantic_isles", "london", "when calling add in ScenarioData, line 195")
	OriginCatalog_OriginCatalog_setPosition(this67, "england", 4160.0, -(6592.0), "when calling setPosition in ScenarioData, line 196")
	OriginCatalog_OriginCatalog_add(this67, "france", "Kingdom of France", "europe_west", "Maps/EuropeWest.w3x", "europe_france_low_countries", "paris", "when calling add in ScenarioData, line 197")
	OriginCatalog_OriginCatalog_setPosition(this67, "france", -(5568.0), 5184.0, "when calling setPosition in ScenarioData, line 198")
	OriginCatalog_OriginCatalog_add(this67, "georgia", "Kingdom of Georgia", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_anatolia_levant", "tbilisi", "when calling add in ScenarioData, line 199")
	OriginCatalog_OriginCatalog_setPosition(this67, "georgia", -(3776.0), -(5568.0), "when calling setPosition in ScenarioData, line 200")
	OriginCatalog_OriginCatalog_add(this67, "gobir", "Kingdom of Gobir", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "gobir_city", "when calling add in ScenarioData, line 201")
	OriginCatalog_OriginCatalog_setPosition(this67, "gobir", -(5696.0), 4288.0, "when calling setPosition in ScenarioData, line 202")
	OriginCatalog_OriginCatalog_add(this67, "kingdom_hormuz", "Kingdom of Hormuz", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_mesopotamia_persia", "hormuz", "when calling add in ScenarioData, line 203")
	OriginCatalog_OriginCatalog_setPosition(this67, "kingdom_hormuz", -(1856.0), -(3520.0), "when calling setPosition in ScenarioData, line 204")
	OriginCatalog_OriginCatalog_add(this67, "hungary", "Kingdom of Hungary", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "buda", "when calling add in ScenarioData, line 205")
	OriginCatalog_OriginCatalog_setPosition(this67, "hungary", -(5568.0), -(4928.0), "when calling setPosition in ScenarioData, line 206")
	OriginCatalog_OriginCatalog_add(this67, "jaffna", "Kingdom of Jaffna", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "nallur", "when calling add in ScenarioData, line 207")
	OriginCatalog_OriginCatalog_setPosition(this67, "jaffna", -(2112.0), -(5568.0), "when calling setPosition in ScenarioData, line 208")
	OriginCatalog_OriginCatalog_add(this67, "joseon_kingdom", "Kingdom of Joseon", "east_asia", "Maps/EastAsia.w3x", "east_asia_korea", "hanseong", "when calling add in ScenarioData, line 209")
	OriginCatalog_OriginCatalog_setPosition(this67, "joseon_kingdom", 960.0, 4032.0, "when calling setPosition in ScenarioData, line 210")
	OriginCatalog_OriginCatalog_add(this67, "khmer_empire", "Kingdom of Kambuja", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "angkor", "when calling add in ScenarioData, line 211")
	OriginCatalog_OriginCatalog_setPosition(this67, "khmer_empire", 11456.0, -(8000.0), "when calling setPosition in ScenarioData, line 212")
	OriginCatalog_OriginCatalog_add(this67, "kano", "Kingdom of Kano", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "kano_city", "when calling add in ScenarioData, line 213")
	OriginCatalog_OriginCatalog_setPosition(this67, "kano", -(64.0), 3904.0, "when calling setPosition in ScenarioData, line 214")
	OriginCatalog_OriginCatalog_add(this67, "katsina", "Kingdom of Katsina", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "katsina_city", "when calling add in ScenarioData, line 215")
	OriginCatalog_OriginCatalog_setPosition(this67, "katsina", -(4032.0), -(2240.0), "when calling setPosition in ScenarioData, line 216")
	OriginCatalog_OriginCatalog_add(this67, "kongo_kingdom", "Kingdom of Kongo", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "mbanza_kongo", "when calling add in ScenarioData, line 217")
	OriginCatalog_OriginCatalog_setPosition(this67, "kongo_kingdom", -(448.0), -(5056.0), "when calling setPosition in ScenarioData, line 218")
	OriginCatalog_OriginCatalog_add(this67, "kotte", "Kingdom of Kotte", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "sri_jayawardenepura_kotte", "when calling add in ScenarioData, line 219")
	OriginCatalog_OriginCatalog_setPosition(this67, "kotte", -(2880.0), -(5952.0), "when calling setPosition in ScenarioData, line 220")
	OriginCatalog_OriginCatalog_add(this67, "kutai_kingdom", "Kingdom of Kutai", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_borneo", "muara_kaman", "when calling add in ScenarioData, line 221")
	OriginCatalog_OriginCatalog_setPosition(this67, "kutai_kingdom", -(8000.0), -(11328.0), "when calling setPosition in ScenarioData, line 222")
	OriginCatalog_OriginCatalog_add(this67, "lan_na_kingdom", "Kingdom of Lan Na", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "chiang_mai", "when calling add in ScenarioData, line 223")
	OriginCatalog_OriginCatalog_setPosition(this67, "lan_na_kingdom", 4288.0, -(10816.0), "when calling setPosition in ScenarioData, line 224")
	OriginCatalog_OriginCatalog_add(this67, "lan_xang_kingdom", "Kingdom of Lan Xang", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "luang_prabang", "when calling add in ScenarioData, line 225")
	OriginCatalog_OriginCatalog_setPosition(this67, "lan_xang_kingdom", 10048.0, -(4160.0), "when calling setPosition in ScenarioData, line 226")
	OriginCatalog_OriginCatalog_add(this67, "loango_kingdom", "Kingdom of Loango", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "buali", "when calling add in ScenarioData, line 227")
	OriginCatalog_OriginCatalog_setPosition(this67, "loango_kingdom", -(1600.0), -(5568.0), "when calling setPosition in ScenarioData, line 228")
	OriginCatalog_OriginCatalog_add(this67, "luba_kingdom", "Kingdom of Luba", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "mwibele", "when calling add in ScenarioData, line 229")
	OriginCatalog_OriginCatalog_setPosition(this67, "luba_kingdom", -(832.0), -(6848.0), "when calling setPosition in ScenarioData, line 230")
	OriginCatalog_OriginCatalog_add(this67, "mrauk_u_kingdom", "Kingdom of Mrauk U", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "mrauk_u", "when calling add in ScenarioData, line 231")
	OriginCatalog_OriginCatalog_setPosition(this67, "mrauk_u_kingdom", 6592.0, -(11072.0), "when calling setPosition in ScenarioData, line 232")
	OriginCatalog_OriginCatalog_add(this67, "mutapa_kingdom", "Kingdom of Mutapa", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "zvongombe", "when calling add in ScenarioData, line 233")
	OriginCatalog_OriginCatalog_setPosition(this67, "mutapa_kingdom", -(3904.0), -(1856.0), "when calling setPosition in ScenarioData, line 234")
	OriginCatalog_OriginCatalog_add(this67, "naples", "Kingdom of Naples", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "naples", "when calling add in ScenarioData, line 235")
	OriginCatalog_OriginCatalog_setPosition(this67, "naples", 6720.0, -(4160.0), "when calling setPosition in ScenarioData, line 236")
	OriginCatalog_OriginCatalog_add(this67, "navarre", "Kingdom of Navarre", "europe_west", "Maps/EuropeWest.w3x", "europe_iberia_western_med", "pamplona", "when calling add in ScenarioData, line 237")
	OriginCatalog_OriginCatalog_setPosition(this67, "navarre", -(5568.0), 5184.0, "when calling setPosition in ScenarioData, line 238")
	OriginCatalog_OriginCatalog_add(this67, "norway", "Kingdom of Norway", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_baltic_scandinavia", "oslo", "when calling add in ScenarioData, line 239")
	OriginCatalog_OriginCatalog_setPosition(this67, "norway", -(6336.0), 4544.0, "when calling setPosition in ScenarioData, line 240")
	OriginCatalog_OriginCatalog_add(this67, "nupe_kingdom", "Kingdom of Nupe", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "nupeko", "when calling add in ScenarioData, line 241")
	OriginCatalog_OriginCatalog_setPosition(this67, "nupe_kingdom", 1984.0, 6848.0, "when calling setPosition in ScenarioData, line 242")
	OriginCatalog_OriginCatalog_add(this67, "oyo_kingdom", "Kingdom of Oyo", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "oyo_ile", "when calling add in ScenarioData, line 243")
	OriginCatalog_OriginCatalog_setPosition(this67, "oyo_kingdom", -(448.0), -(2368.0), "when calling setPosition in ScenarioData, line 244")
	OriginCatalog_OriginCatalog_add(this67, "poland", "Kingdom of Poland", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "krakow", "when calling add in ScenarioData, line 245")
	OriginCatalog_OriginCatalog_setPosition(this67, "poland", -(832.0), -(4928.0), "when calling setPosition in ScenarioData, line 246")
	OriginCatalog_OriginCatalog_add(this67, "portugal", "Kingdom of Portugal", "europe_west", "Maps/EuropeWest.w3x", "europe_iberia_western_med", "lisbon", "when calling add in ScenarioData, line 247")
	OriginCatalog_OriginCatalog_setPosition(this67, "portugal", -(1600.0), 5056.0, "when calling setPosition in ScenarioData, line 248")
	OriginCatalog_OriginCatalog_add(this67, "ryukyu_kingdom", "Kingdom of Ryukyu", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_south", "shuri", "when calling add in ScenarioData, line 249")
	OriginCatalog_OriginCatalog_setPosition(this67, "ryukyu_kingdom", 1728.0, -(5568.0), "when calling setPosition in ScenarioData, line 250")
	OriginCatalog_OriginCatalog_add(this67, "scotland", "Kingdom of Scotland", "europe_west", "Maps/EuropeWest.w3x", "europe_atlantic_isles", "edinburgh", "when calling add in ScenarioData, line 251")
	OriginCatalog_OriginCatalog_setPosition(this67, "scotland", -(3520.0), 3008.0, "when calling setPosition in ScenarioData, line 252")
	OriginCatalog_OriginCatalog_add(this67, "sunda_kingdom", "Kingdom of Sunda", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_java_sunda", "pakuan_pajajaran", "when calling add in ScenarioData, line 253")
	OriginCatalog_OriginCatalog_setPosition(this67, "sunda_kingdom", 4032.0, -(11328.0), "when calling setPosition in ScenarioData, line 254")
	OriginCatalog_OriginCatalog_add(this67, "sweden", "Kingdom of Sweden", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_baltic_scandinavia", "stockholm", "when calling add in ScenarioData, line 255")
	OriginCatalog_OriginCatalog_setPosition(this67, "sweden", 2624.0, 4160.0, "when calling setPosition in ScenarioData, line 256")
	OriginCatalog_OriginCatalog_add(this67, "zazzau", "Kingdom of Zazzau", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "zazzau_city", "when calling add in ScenarioData, line 257")
	OriginCatalog_OriginCatalog_setPosition(this67, "zazzau", -(320.0), -(7488.0), "when calling setPosition in ScenarioData, line 258")
	OriginCatalog_OriginCatalog_add(this67, "great_zimbabwe", "Kingdom of Zimbabwe", "africa", "Maps/Africa.w3x", "africa_southern_cape", "great_zimbabwe_city", "when calling add in ScenarioData, line 259")
	OriginCatalog_OriginCatalog_setPosition(this67, "great_zimbabwe", -(5696.0), 5312.0, "when calling setPosition in ScenarioData, line 260")
	OriginCatalog_OriginCatalog_add(this67, "kwararafa_confederacy", "Kwararafa Confederacy", "africa", "Maps/Africa.w3x", "africa_west_guinea_congo", "wukari", "when calling add in ScenarioData, line 261")
	OriginCatalog_OriginCatalog_setPosition(this67, "kwararafa_confederacy", -(2624.0), -(2112.0), "when calling setPosition in ScenarioData, line 262")
	OriginCatalog_OriginCatalog_add(this67, "langah_multan", "Langah Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "multan", "when calling add in ScenarioData, line 263")
	OriginCatalog_OriginCatalog_setPosition(this67, "langah_multan", 2624.0, -(6848.0), "when calling setPosition in ScenarioData, line 264")
	OriginCatalog_OriginCatalog_add(this67, "albania", "League of Lezhe", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "lezhe", "when calling add in ScenarioData, line 265")
	OriginCatalog_OriginCatalog_setPosition(this67, "albania", 1728.0, -(5824.0), "when calling setPosition in ScenarioData, line 266")
	OriginCatalog_OriginCatalog_add(this67, "mapungubwe_successors", "Limpopo and Mapungubwe Successor Polities", "africa", "Maps/Africa.w3x", "africa_southern_cape", "mapungubwe", "when calling add in ScenarioData, line 267")
	OriginCatalog_OriginCatalog_setPosition(this67, "mapungubwe_successors", -(1984.0), -(3776.0), "when calling setPosition in ScenarioData, line 268")
	OriginCatalog_OriginCatalog_add(this67, "livonian_confederation", "Livonian Confederation", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_baltic_scandinavia", "riga", "when calling add in ScenarioData, line 269")
	OriginCatalog_OriginCatalog_setPosition(this67, "livonian_confederation", -(1600.0), -(4416.0), "when calling setPosition in ScenarioData, line 270")
	OriginCatalog_OriginCatalog_add(this67, "ireland", "Lordship of Ireland", "europe_west", "Maps/EuropeWest.w3x", "europe_atlantic_isles", "dublin", "when calling add in ScenarioData, line 271")
	OriginCatalog_OriginCatalog_setPosition(this67, "ireland", -(5312.0), -(5312.0), "when calling setPosition in ScenarioData, line 272")
	OriginCatalog_OriginCatalog_add(this67, "lunda_polities", "Lunda Polities", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "lunda_royal_camp", "when calling add in ScenarioData, line 273")
	OriginCatalog_OriginCatalog_setPosition(this67, "lunda_polities", 4544.0, -(5184.0), "when calling setPosition in ScenarioData, line 274")
	OriginCatalog_OriginCatalog_add(this67, "luzon_polities", "Luzon Port Polities", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_philippines", "tondo", "when calling add in ScenarioData, line 275")
	OriginCatalog_OriginCatalog_setPosition(this67, "luzon_polities", 7744.0, 3008.0, "when calling setPosition in ScenarioData, line 276")
	OriginCatalog_OriginCatalog_add(this67, "madagascar_coastal_polities", "Madagascar Coastal Polities", "africa", "Maps/Africa.w3x", "africa_madagascar_indian_ocean", "vohemar", "when calling add in ScenarioData, line 277")
	OriginCatalog_OriginCatalog_setPosition(this67, "madagascar_coastal_polities", -(2368.0), -(2880.0), "when calling setPosition in ScenarioData, line 278")
	OriginCatalog_OriginCatalog_add(this67, "majapahit_empire", "Majapahit Empire", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_java_sunda", "trowulan", "when calling add in ScenarioData, line 279")
	OriginCatalog_OriginCatalog_setPosition(this67, "majapahit_empire", 448.0, -(10176.0), "when calling setPosition in ScenarioData, line 280")
	OriginCatalog_OriginCatalog_add(this67, "malacca_sultanate", "Malacca Sultanate", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_malay_sumatra", "malacca", "when calling add in ScenarioData, line 281")
	OriginCatalog_OriginCatalog_setPosition(this67, "malacca_sultanate", -(6080.0), 832.0, "when calling setPosition in ScenarioData, line 282")
	OriginCatalog_OriginCatalog_add(this67, "mali_empire", "Mali Empire", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "niani", "when calling add in ScenarioData, line 283")
	OriginCatalog_OriginCatalog_setPosition(this67, "mali_empire", -(832.0), -(6848.0), "when calling setPosition in ScenarioData, line 284")
	OriginCatalog_OriginCatalog_add(this67, "malindi", "Malindi", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "malindi_city", "when calling add in ScenarioData, line 285")
	OriginCatalog_OriginCatalog_setPosition(this67, "malindi", -(2112.0), -(4800.0), "when calling setPosition in ScenarioData, line 286")
	OriginCatalog_OriginCatalog_add(this67, "nepal_malla", "Malla Kingdom of Nepal", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_ganges_himalaya", "kathmandu", "when calling add in ScenarioData, line 287")
	OriginCatalog_OriginCatalog_setPosition(this67, "nepal_malla", -(5056.0), -(4800.0), "when calling setPosition in ScenarioData, line 288")
	OriginCatalog_OriginCatalog_add(this67, "malwa_sultanate", "Malwa Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "mandu", "when calling add in ScenarioData, line 289")
	OriginCatalog_OriginCatalog_setPosition(this67, "malwa_sultanate", 2368.0, -(1728.0), "when calling setPosition in ScenarioData, line 290")
	OriginCatalog_OriginCatalog_add(this67, "mamluk_sultanate", "Mamluk Sultanate", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "cairo", "when calling add in ScenarioData, line 291")
	OriginCatalog_OriginCatalog_setPosition(this67, "mamluk_sultanate", -(6592.0), 1472.0, "when calling setPosition in ScenarioData, line 292")
	OriginCatalog_OriginCatalog_add(this67, "mapuche_rewe_confederacies", "Mapuche Rewe Confederacies", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "mapuche_rewe_assemblies", "when calling add in ScenarioData, line 293")
	OriginCatalog_OriginCatalog_setPosition(this67, "mapuche_rewe_confederacies", 4160.0, -(3264.0), "when calling setPosition in ScenarioData, line 294")
	OriginCatalog_OriginCatalog_add(this67, "maravi_polities", "Maravi Polities", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "mankhamba", "when calling add in ScenarioData, line 295")
	OriginCatalog_OriginCatalog_setPosition(this67, "maravi_polities", -(2112.0), 1856.0, "when calling setPosition in ScenarioData, line 296")
	OriginCatalog_OriginCatalog_add(this67, "brandenburg", "Margraviate of Brandenburg", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "berlin", "when calling add in ScenarioData, line 297")
	OriginCatalog_OriginCatalog_setPosition(this67, "brandenburg", 7616.0, -(2880.0), "when calling setPosition in ScenarioData, line 298")
	OriginCatalog_OriginCatalog_add(this67, "marinid_morocco", "Marinid Sultanate", "africa", "Maps/Africa.w3x", "africa_maghreb_med_atlantic", "fez", "when calling add in ScenarioData, line 299")
	OriginCatalog_OriginCatalog_setPosition(this67, "marinid_morocco", -(2880.0), -(3648.0), "when calling setPosition in ScenarioData, line 300")
	OriginCatalog_OriginCatalog_add(this67, "marquesan_chiefdoms", "Marquesan Chiefdoms", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_east_polynesia", "marquesas_council", "when calling add in ScenarioData, line 301")
	OriginCatalog_OriginCatalog_setPosition(this67, "marquesan_chiefdoms", -(4416.0), -(192.0), "when calling setPosition in ScenarioData, line 302")
	OriginCatalog_OriginCatalog_add(this67, "marshallese_irooj_domains", "Marshallese Irooj Domains", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "marshall_council", "when calling add in ScenarioData, line 303")
	OriginCatalog_OriginCatalog_setPosition(this67, "marshallese_irooj_domains", -(704.0), -(1472.0), "when calling setPosition in ScenarioData, line 304")
	OriginCatalog_OriginCatalog_add(this67, "maui_chiefdom", "Maui Chiefdom", "pacific_north", "Maps/PacificNorth.w3x", "pacific_north_hawaii", "maui_royal_center", "when calling add in ScenarioData, line 305")
	OriginCatalog_OriginCatalog_setPosition(this67, "maui_chiefdom", -(2624.0), 1728.0, "when calling setPosition in ScenarioData, line 306")
	OriginCatalog_OriginCatalog_add(this67, "medri_bahri", "Medri Bahri", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "debarwa", "when calling add in ScenarioData, line 307")
	OriginCatalog_OriginCatalog_setPosition(this67, "medri_bahri", -(4672.0), 2880.0, "when calling setPosition in ScenarioData, line 308")
	OriginCatalog_OriginCatalog_add(this67, "mexica_tenochtitlan", "Mexica of Tenochtitlan", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "tenochtitlan", "when calling add in ScenarioData, line 309")
	OriginCatalog_OriginCatalog_setPosition(this67, "mexica_tenochtitlan", -(192.0), -(6848.0), "when calling setPosition in ScenarioData, line 310")
	OriginCatalog_OriginCatalog_add(this67, "minangkabau_kingdom", "Minangkabau Kingdom", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_malay_sumatra", "pagaruyung", "when calling add in ScenarioData, line 311")
	OriginCatalog_OriginCatalog_setPosition(this67, "minangkabau_kingdom", -(5696.0), -(4032.0), "when calling setPosition in ScenarioData, line 312")
	OriginCatalog_OriginCatalog_add(this67, "maguindanao_polities", "Mindanao River Polities", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_philippines", "buayan", "when calling add in ScenarioData, line 313")
	OriginCatalog_OriginCatalog_setPosition(this67, "maguindanao_polities", 9920.0, -(2112.0), "when calling setPosition in ScenarioData, line 314")
	OriginCatalog_OriginCatalog_add(this67, "ming_liaodong_command", "Ming Liaodong Regional Military Commission", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_north", "liaoyang", "when calling add in ScenarioData, line 315")
	OriginCatalog_OriginCatalog_setPosition(this67, "ming_liaodong_command", -(4160.0), -(3136.0), "when calling setPosition in ScenarioData, line 316")
	OriginCatalog_OriginCatalog_add(this67, "cahokian_successor_centers", "Mississippian Successor Centers", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_atlantic", "moundville", "when calling add in ScenarioData, line 317")
	OriginCatalog_OriginCatalog_setPosition(this67, "cahokian_successor_centers", 6208.0, -(5312.0), "when calling setPosition in ScenarioData, line 318")
	OriginCatalog_OriginCatalog_add(this67, "mombasa", "Mombasa", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "mombasa_city", "when calling add in ScenarioData, line 319")
	OriginCatalog_OriginCatalog_setPosition(this67, "mombasa", 4800.0, 3648.0, "when calling setPosition in ScenarioData, line 320")
	OriginCatalog_OriginCatalog_add(this67, "mossi_kingdoms", "Mossi Kingdoms", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "ouagadougou", "when calling add in ScenarioData, line 321")
	OriginCatalog_OriginCatalog_setPosition(this67, "mossi_kingdoms", -(1344.0), -(6208.0), "when calling setPosition in ScenarioData, line 322")
	OriginCatalog_OriginCatalog_add(this67, "muisca_zacazgo", "Muisca Zacazgo", "americas_south", "Maps/AmericasSouth.w3x", "americas_north_south", "hunza", "when calling add in ScenarioData, line 323")
	OriginCatalog_OriginCatalog_setPosition(this67, "muisca_zacazgo", -(64.0), 5056.0, "when calling setPosition in ScenarioData, line 324")
	OriginCatalog_OriginCatalog_add(this67, "muisca_zipazgo", "Muisca Zipazgo", "americas_south", "Maps/AmericasSouth.w3x", "americas_north_south", "bacata", "when calling add in ScenarioData, line 325")
	OriginCatalog_OriginCatalog_setPosition(this67, "muisca_zipazgo", -(64.0), 4416.0, "when calling setPosition in ScenarioData, line 326")
	OriginCatalog_OriginCatalog_add(this67, "maori_iwi_hapu", "Māori Iwi and Hapū", "pacific_new_zealand", "Maps/PacificNewZealand.w3x", "pacific_new_zealand", "aotearoa_runanga", "when calling add in ScenarioData, line 327")
	OriginCatalog_OriginCatalog_setPosition(this67, "maori_iwi_hapu", 704.0, -(1088.0), "when calling setPosition in ScenarioData, line 328")
	OriginCatalog_OriginCatalog_add(this67, "nabhanid_oman", "Nabhanid Kingdom of Oman", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_arabia_red_sea", "nizwa", "when calling add in ScenarioData, line 329")
	OriginCatalog_OriginCatalog_setPosition(this67, "nabhanid_oman", -(5056.0), -(4800.0), "when calling setPosition in ScenarioData, line 330")
	OriginCatalog_OriginCatalog_add(this67, "northern_yuan_khanate", "Northern Yuan", "east_asia", "Maps/EastAsia.w3x", "east_asia_interior", "northern_yuan_mobile_court", "when calling add in ScenarioData, line 331")
	OriginCatalog_OriginCatalog_setPosition(this67, "northern_yuan_khanate", 12224.0, -(2112.0), "when calling setPosition in ScenarioData, line 332")
	OriginCatalog_OriginCatalog_add(this67, "northwest_coast_nations", "Northwest Coast Nations", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_pacific", "northwest_coast_house_councils", "when calling add in ScenarioData, line 333")
	OriginCatalog_OriginCatalog_setPosition(this67, "northwest_coast_nations", -(1472.0), 5056.0, "when calling setPosition in ScenarioData, line 334")
	OriginCatalog_OriginCatalog_add(this67, "novgorod", "Novgorod Republic", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "novgorod", "when calling add in ScenarioData, line 335")
	OriginCatalog_OriginCatalog_setPosition(this67, "novgorod", -(2496.0), -(320.0), "when calling setPosition in ScenarioData, line 336")
	OriginCatalog_OriginCatalog_add(this67, "oirat_confederation", "Oirat Confederation", "east_asia", "Maps/EastAsia.w3x", "east_asia_interior", "oirat_mobile_court", "when calling add in ScenarioData, line 337")
	OriginCatalog_OriginCatalog_setPosition(this67, "oirat_confederation", 8640.0, -(2112.0), "when calling setPosition in ScenarioData, line 338")
	OriginCatalog_OriginCatalog_add(this67, "swiss_confederacy", "Old Swiss Confederacy", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_central_alpine", "lucerne", "when calling add in ScenarioData, line 339")
	OriginCatalog_OriginCatalog_setPosition(this67, "swiss_confederacy", -(1472.0), -(1856.0), "when calling setPosition in ScenarioData, line 340")
	OriginCatalog_OriginCatalog_add(this67, "ottoman_empire", "Ottoman Empire", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "edirne", "when calling add in ScenarioData, line 341")
	OriginCatalog_OriginCatalog_setPosition(this67, "ottoman_empire", -(320.0), -(3392.0), "when calling setPosition in ScenarioData, line 342")
	OriginCatalog_OriginCatalog_add(this67, "oahu_chiefdom", "O‘ahu Chiefdom", "pacific_north", "Maps/PacificNorth.w3x", "pacific_north_hawaii", "oahu_royal_center", "when calling add in ScenarioData, line 343")
	OriginCatalog_OriginCatalog_setPosition(this67, "oahu_chiefdom", -(2624.0), 1728.0, "when calling setPosition in ScenarioData, line 344")
	OriginCatalog_OriginCatalog_add(this67, "papal_states", "Papal States", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "rome", "when calling add in ScenarioData, line 345")
	OriginCatalog_OriginCatalog_setPosition(this67, "papal_states", -(3008.0), 832.0, "when calling setPosition in ScenarioData, line 346")
	OriginCatalog_OriginCatalog_add(this67, "papuan_coastal_polities", "Papuan Coastal Polities", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_new_guinea_west", "raja_ampat", "when calling add in ScenarioData, line 347")
	OriginCatalog_OriginCatalog_setPosition(this67, "papuan_coastal_polities", -(2496.0), 960.0, "when calling setPosition in ScenarioData, line 348")
	OriginCatalog_OriginCatalog_add(this67, "pate_sultanate", "Pate Sultanate", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "pate", "when calling add in ScenarioData, line 349")
	OriginCatalog_OriginCatalog_setPosition(this67, "pate_sultanate", -(2368.0), -(4288.0), "when calling setPosition in ScenarioData, line 350")
	OriginCatalog_OriginCatalog_add(this67, "phagmodrupa_dynasty", "Phagmodrupa Dynasty", "east_asia", "Maps/EastAsia.w3x", "east_asia_interior", "nedong", "when calling add in ScenarioData, line 351")
	OriginCatalog_OriginCatalog_setPosition(this67, "phagmodrupa_dynasty", 10304.0, -(5824.0), "when calling setPosition in ScenarioData, line 352")
	OriginCatalog_OriginCatalog_add(this67, "moldavia", "Principality of Moldavia", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_eastern_black_sea", "suceava", "when calling add in ScenarioData, line 353")
	OriginCatalog_OriginCatalog_setPosition(this67, "moldavia", -(1344.0), 2496.0, "when calling setPosition in ScenarioData, line 354")
	OriginCatalog_OriginCatalog_add(this67, "toungoo_principality", "Principality of Toungoo", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "toungoo", "when calling add in ScenarioData, line 355")
	OriginCatalog_OriginCatalog_setPosition(this67, "toungoo_principality", 5312.0, -(11072.0), "when calling setPosition in ScenarioData, line 356")
	OriginCatalog_OriginCatalog_add(this67, "wallachia", "Principality of Wallachia", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "targoviste", "when calling add in ScenarioData, line 357")
	OriginCatalog_OriginCatalog_setPosition(this67, "wallachia", -(704.0), 3136.0, "when calling setPosition in ScenarioData, line 358")
	OriginCatalog_OriginCatalog_add(this67, "pueblo_world", "Pueblo Communities", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_pacific", "pueblo_council_network", "when calling add in ScenarioData, line 359")
	OriginCatalog_OriginCatalog_setPosition(this67, "pueblo_world", -(64.0), 3520.0, "when calling setPosition in ScenarioData, line 360")
	OriginCatalog_OriginCatalog_add(this67, "purepecha_state", "Purépecha State", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "tzintzuntzan", "when calling add in ScenarioData, line 361")
	OriginCatalog_OriginCatalog_setPosition(this67, "purepecha_state", -(1984.0), -(5440.0), "when calling setPosition in ScenarioData, line 362")
	OriginCatalog_OriginCatalog_add(this67, "qara_qoyunlu", "Qara Qoyunlu Confederation", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_mesopotamia_persia", "tabriz", "when calling add in ScenarioData, line 363")
	OriginCatalog_OriginCatalog_setPosition(this67, "qara_qoyunlu", -(3264.0), 448.0, "when calling setPosition in ScenarioData, line 364")
	OriginCatalog_OriginCatalog_add(this67, "rajput_confederacies", "Rajput Kingdoms", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "chittor", "when calling add in ScenarioData, line 365")
	OriginCatalog_OriginCatalog_setPosition(this67, "rajput_confederacies", 2624.0, -(6848.0), "when calling setPosition in ScenarioData, line 366")
	OriginCatalog_OriginCatalog_add(this67, "rapa_nui_clans", "Rapa Nui Clan Confederation", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_east_polynesia", "anakena", "when calling add in ScenarioData, line 367")
	OriginCatalog_OriginCatalog_setPosition(this67, "rapa_nui_clans", -(1856.0), -(3392.0), "when calling setPosition in ScenarioData, line 368")
	OriginCatalog_OriginCatalog_add(this67, "yemen", "Rasulid Sultanate", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_arabia_red_sea", "taizz", "when calling add in ScenarioData, line 369")
	OriginCatalog_OriginCatalog_setPosition(this67, "yemen", 2624.0, -(6848.0), "when calling setPosition in ScenarioData, line 370")
	OriginCatalog_OriginCatalog_add(this67, "florence", "Republic of Florence", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "florence", "when calling add in ScenarioData, line 371")
	OriginCatalog_OriginCatalog_setPosition(this67, "florence", 7360.0, 2368.0, "when calling setPosition in ScenarioData, line 372")
	OriginCatalog_OriginCatalog_add(this67, "genoa", "Republic of Genoa", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "genoa", "when calling add in ScenarioData, line 373")
	OriginCatalog_OriginCatalog_setPosition(this67, "genoa", -(576.0), 3904.0, "when calling setPosition in ScenarioData, line 374")
	OriginCatalog_OriginCatalog_add(this67, "venice", "Republic of Venice", "europe_west", "Maps/EuropeWest.w3x", "europe_italy_central_med", "venice", "when calling add in ScenarioData, line 375")
	OriginCatalog_OriginCatalog_setPosition(this67, "venice", -(448.0), -(5056.0), "when calling setPosition in ScenarioData, line 376")
	OriginCatalog_OriginCatalog_add(this67, "rinpungpa_house", "Rinpungpa House", "east_asia", "Maps/EastAsia.w3x", "east_asia_interior", "rinpung", "when calling add in ScenarioData, line 377")
	OriginCatalog_OriginCatalog_setPosition(this67, "rinpungpa_house", 8512.0, -(6080.0), "when calling setPosition in ScenarioData, line 378")
	OriginCatalog_OriginCatalog_add(this67, "byzantine_empire", "Roman Empire", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "constantinople", "when calling add in ScenarioData, line 379")
	OriginCatalog_OriginCatalog_setPosition(this67, "byzantine_empire", 7104.0, -(4160.0), "when calling setPosition in ScenarioData, line 380")
	OriginCatalog_OriginCatalog_add(this67, "rwanda_burundi_kingdoms", "Rwanda and Burundi Kingdoms", "africa", "Maps/Africa.w3x", "africa_great_lakes_rift", "nyanza", "when calling add in ScenarioData, line 381")
	OriginCatalog_OriginCatalog_setPosition(this67, "rwanda_burundi_kingdoms", 5952.0, 4416.0, "when calling setPosition in ScenarioData, line 382")
	OriginCatalog_OriginCatalog_add(this67, "sakhalin_communities", "Sakhalin Ainu and Nivkh Communities", "east_asia", "Maps/EastAsia.w3x", "east_asia_northeast_pacific", "sakhalin_council_place", "when calling add in ScenarioData, line 383")
	OriginCatalog_OriginCatalog_setPosition(this67, "sakhalin_communities", 10816.0, 5056.0, "when calling setPosition in ScenarioData, line 384")
	OriginCatalog_OriginCatalog_add(this67, "samma_sindh", "Samma Sultanate of Sindh", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "thatta", "when calling add in ScenarioData, line 385")
	OriginCatalog_OriginCatalog_setPosition(this67, "samma_sindh", -(832.0), -(5184.0), "when calling setPosition in ScenarioData, line 386")
	OriginCatalog_OriginCatalog_add(this67, "samoan_chiefly_districts", "Samoan Chiefly Districts", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_east_polynesia", "samoa_fono", "when calling add in ScenarioData, line 387")
	OriginCatalog_OriginCatalog_setPosition(this67, "samoan_chiefly_districts", -(4928.0), 64.0, "when calling setPosition in ScenarioData, line 388")
	OriginCatalog_OriginCatalog_add(this67, "samudera_pasai", "Samudera Pasai Sultanate", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_malay_sumatra", "pasai", "when calling add in ScenarioData, line 389")
	OriginCatalog_OriginCatalog_setPosition(this67, "samudera_pasai", -(8384.0), 2880.0, "when calling setPosition in ScenarioData, line 390")
	OriginCatalog_OriginCatalog_add(this67, "saudeleur_dynasty", "Saudeleur Dynasty", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "nan_madol", "when calling add in ScenarioData, line 391")
	OriginCatalog_OriginCatalog_setPosition(this67, "saudeleur_dynasty", 960.0, -(3264.0), "when calling setPosition in ScenarioData, line 392")
	OriginCatalog_OriginCatalog_add(this67, "selknam_yaghan_communities", "Selk'nam and Yaghan Communities", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "fuegian_seasonal_camps", "when calling add in ScenarioData, line 393")
	OriginCatalog_OriginCatalog_setPosition(this67, "selknam_yaghan_communities", 8000.0, -(8128.0), "when calling setPosition in ScenarioData, line 394")
	OriginCatalog_OriginCatalog_add(this67, "serbia", "Serbian Despotate", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_balkans_aegean", "smederevo", "when calling add in ScenarioData, line 395")
	OriginCatalog_OriginCatalog_setPosition(this67, "serbia", 3520.0, -(192.0), "when calling setPosition in ScenarioData, line 396")
	OriginCatalog_OriginCatalog_add(this67, "shan_states", "Shan States", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_mainland", "mong_yang", "when calling add in ScenarioData, line 397")
	OriginCatalog_OriginCatalog_setPosition(this67, "shan_states", 6976.0, -(11072.0), "when calling setPosition in ScenarioData, line 398")
	OriginCatalog_OriginCatalog_add(this67, "sharifate_mecca", "Sharifate of Mecca", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_arabia_red_sea", "mecca", "when calling add in ScenarioData, line 399")
	OriginCatalog_OriginCatalog_setPosition(this67, "sharifate_mecca", -(5568.0), -(3648.0), "when calling setPosition in ScenarioData, line 400")
	OriginCatalog_OriginCatalog_add(this67, "shirvan", "Shirvanshah State", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_mesopotamia_persia", "shamakhi", "when calling add in ScenarioData, line 401")
	OriginCatalog_OriginCatalog_setPosition(this67, "shirvan", -(4288.0), -(5312.0), "when calling setPosition in ScenarioData, line 402")
	OriginCatalog_OriginCatalog_add(this67, "solomon_island_chiefdoms", "Solomon Island Chiefdoms", "pacific_melanesia", "Maps/PacificMelanesia.w3x", "pacific_melanesia", "solomon_council", "when calling add in ScenarioData, line 403")
	OriginCatalog_OriginCatalog_setPosition(this67, "solomon_island_chiefdoms", 2368.0, -(2496.0), "when calling setPosition in ScenarioData, line 404")
	OriginCatalog_OriginCatalog_add(this67, "songhai_kingdom", "Songhai Kingdom", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "gao", "when calling add in ScenarioData, line 405")
	OriginCatalog_OriginCatalog_setPosition(this67, "songhai_kingdom", -(1600.0), -(5696.0), "when calling setPosition in ScenarioData, line 406")
	OriginCatalog_OriginCatalog_add(this67, "makassar_polities", "South Sulawesi Kingdoms", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_sulawesi_moluccas", "siang", "when calling add in ScenarioData, line 407")
	OriginCatalog_OriginCatalog_setPosition(this67, "makassar_polities", -(5312.0), 5056.0, "when calling setPosition in ScenarioData, line 408")
	OriginCatalog_OriginCatalog_add(this67, "teutonic_order", "State of the Teutonic Order", "europe_central_east", "Maps/EuropeCentralEast.w3x", "europe_baltic_scandinavia", "marienburg", "when calling add in ScenarioData, line 409")
	OriginCatalog_OriginCatalog_setPosition(this67, "teutonic_order", -(3392.0), 3904.0, "when calling setPosition in ScenarioData, line 410")
	OriginCatalog_OriginCatalog_add(this67, "adal_sultanate", "Sultanate of Adal", "africa", "Maps/Africa.w3x", "africa_nile_red_sea", "dakkar", "when calling add in ScenarioData, line 411")
	OriginCatalog_OriginCatalog_setPosition(this67, "adal_sultanate", 5824.0, 3136.0, "when calling setPosition in ScenarioData, line 412")
	OriginCatalog_OriginCatalog_add(this67, "air_sultanate", "Sultanate of Air", "africa", "Maps/Africa.w3x", "africa_sahara_sahel", "agadez", "when calling add in ScenarioData, line 413")
	OriginCatalog_OriginCatalog_setPosition(this67, "air_sultanate", -(1088.0), -(5056.0), "when calling setPosition in ScenarioData, line 414")
	OriginCatalog_OriginCatalog_add(this67, "mogadishu_sultanate", "Sultanate of Mogadishu", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "mogadishu", "when calling add in ScenarioData, line 415")
	OriginCatalog_OriginCatalog_setPosition(this67, "mogadishu_sultanate", -(2368.0), 704.0, "when calling setPosition in ScenarioData, line 416")
	OriginCatalog_OriginCatalog_add(this67, "sulu_sultanate", "Sultanate of Sulu", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_philippines", "jolo", "when calling add in ScenarioData, line 417")
	OriginCatalog_OriginCatalog_setPosition(this67, "sulu_sultanate", 8000.0, -(704.0), "when calling setPosition in ScenarioData, line 418")
	OriginCatalog_OriginCatalog_add(this67, "ternate_sultanate", "Sultanate of Ternate", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_sulawesi_moluccas", "ternate", "when calling add in ScenarioData, line 419")
	OriginCatalog_OriginCatalog_setPosition(this67, "ternate_sultanate", -(5056.0), 8000.0, "when calling setPosition in ScenarioData, line 420")
	OriginCatalog_OriginCatalog_add(this67, "maldives_sultanate", "Sultanate of the Maldives", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_bengal_ceylon", "male", "when calling add in ScenarioData, line 421")
	OriginCatalog_OriginCatalog_setPosition(this67, "maldives_sultanate", -(1344.0), -(5184.0), "when calling setPosition in ScenarioData, line 422")
	OriginCatalog_OriginCatalog_add(this67, "tidore_sultanate", "Sultanate of Tidore", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_sulawesi_moluccas", "tidore", "when calling add in ScenarioData, line 423")
	OriginCatalog_OriginCatalog_setPosition(this67, "tidore_sultanate", -(5056.0), 7872.0, "when calling setPosition in ScenarioData, line 424")
	OriginCatalog_OriginCatalog_add(this67, "tahiti_chiefdoms", "Tahiti Chiefdoms", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_east_polynesia", "tahiti_council", "when calling add in ScenarioData, line 425")
	OriginCatalog_OriginCatalog_setPosition(this67, "tahiti_chiefdoms", -(4416.0), -(192.0), "when calling setPosition in ScenarioData, line 426")
	OriginCatalog_OriginCatalog_add(this67, "tairona_chiefdoms", "Tairona Chiefdoms", "americas_south", "Maps/AmericasSouth.w3x", "americas_north_south", "tairona_mountain_centers", "when calling add in ScenarioData, line 427")
	OriginCatalog_OriginCatalog_setPosition(this67, "tairona_chiefdoms", -(64.0), -(64.0), "when calling setPosition in ScenarioData, line 428")
	OriginCatalog_OriginCatalog_add(this67, "taiwan_indigenous_domains", "Taiwan Indigenous Domains", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_south", "taiwan_council_place", "when calling add in ScenarioData, line 429")
	OriginCatalog_OriginCatalog_setPosition(this67, "taiwan_indigenous_domains", 1856.0, -(4160.0), "when calling setPosition in ScenarioData, line 430")
	OriginCatalog_OriginCatalog_add(this67, "tawantinsuyu", "Tawantinsuyu", "americas_south", "Maps/AmericasSouth.w3x", "americas_andes_southern_cone", "cusco", "when calling add in ScenarioData, line 431")
	OriginCatalog_OriginCatalog_setPosition(this67, "tawantinsuyu", 3776.0, -(2624.0), "when calling setPosition in ScenarioData, line 432")
	OriginCatalog_OriginCatalog_add(this67, "taino_cacicazgos", "Taíno Cacicazgos", "americas_caribbean", "Maps/AmericasCaribbean.w3x", "americas_caribbean_islands", "taino_cacique_seats", "when calling add in ScenarioData, line 433")
	OriginCatalog_OriginCatalog_setPosition(this67, "taino_cacicazgos", 1728.0, -(704.0), "when calling setPosition in ScenarioData, line 434")
	OriginCatalog_OriginCatalog_add(this67, "tepanec_tlacopan", "Tepanec of Tlacopan", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "tlacopan", "when calling add in ScenarioData, line 435")
	OriginCatalog_OriginCatalog_setPosition(this67, "tepanec_tlacopan", -(64.0), -(8000.0), "when calling setPosition in ScenarioData, line 436")
	OriginCatalog_OriginCatalog_add(this67, "timurid_empire", "Timurid Empire", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_central_asia", "samarkand", "when calling add in ScenarioData, line 437")
	OriginCatalog_OriginCatalog_setPosition(this67, "timurid_empire", -(704.0), 2368.0, "when calling setPosition in ScenarioData, line 438")
	OriginCatalog_OriginCatalog_add(this67, "tlaxcallan_confederation", "Tlaxcallan", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "tlaxcallan_council", "when calling add in ScenarioData, line 439")
	OriginCatalog_OriginCatalog_setPosition(this67, "tlaxcallan_confederation", -(64.0), -(6848.0), "when calling setPosition in ScenarioData, line 440")
	OriginCatalog_OriginCatalog_add(this67, "tuamotu_atoll_communities", "Tuamotu Atoll Communities", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_east_polynesia", "tuamotu_council", "when calling add in ScenarioData, line 441")
	OriginCatalog_OriginCatalog_setPosition(this67, "tuamotu_atoll_communities", -(4416.0), -(192.0), "when calling setPosition in ScenarioData, line 442")
	OriginCatalog_OriginCatalog_add(this67, "tungaru_maneaba_communities", "Tungaru Maneaba Communities", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "tungaru_maneaba", "when calling add in ScenarioData, line 443")
	OriginCatalog_OriginCatalog_setPosition(this67, "tungaru_maneaba_communities", 960.0, -(3264.0), "when calling setPosition in ScenarioData, line 444")
	OriginCatalog_OriginCatalog_add(this67, "tupi_coastal_networks", "Tupí Coastal Networks", "americas_south", "Maps/AmericasSouth.w3x", "americas_amazon_brazil", "tupi_village_councils", "when calling add in ScenarioData, line 445")
	OriginCatalog_OriginCatalog_setPosition(this67, "tupi_coastal_networks", -(832.0), -(3648.0), "when calling setPosition in ScenarioData, line 446")
	OriginCatalog_OriginCatalog_add(this67, "tui_tonga_empire", "Tu‘i Tonga Polity", "pacific_polynesia", "Maps/PacificPolynesia.w3x", "pacific_west_polynesia", "mua", "when calling add in ScenarioData, line 447")
	OriginCatalog_OriginCatalog_setPosition(this67, "tui_tonga_empire", 5184.0, -(1856.0), "when calling setPosition in ScenarioData, line 448")
	OriginCatalog_OriginCatalog_add(this67, "unangan_island_communities", "Unangan Island Communities", "pacific_north", "Maps/PacificNorth.w3x", "pacific_north_hawaii", "unangan_council", "when calling add in ScenarioData, line 449")
	OriginCatalog_OriginCatalog_setPosition(this67, "unangan_island_communities", -(2624.0), 1728.0, "when calling setPosition in ScenarioData, line 450")
	OriginCatalog_OriginCatalog_add(this67, "vanuatu_chiefdoms", "Vanuatu Chiefdoms", "pacific_melanesia", "Maps/PacificMelanesia.w3x", "pacific_melanesia", "vanuatu_council", "when calling add in ScenarioData, line 451")
	OriginCatalog_OriginCatalog_setPosition(this67, "vanuatu_chiefdoms", 2368.0, -(2496.0), "when calling setPosition in ScenarioData, line 452")
	OriginCatalog_OriginCatalog_add(this67, "vijayanagara_empire", "Vijayanagara Empire", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_indus_deccan", "vijayanagara", "when calling add in ScenarioData, line 453")
	OriginCatalog_OriginCatalog_setPosition(this67, "vijayanagara_empire", 3264.0, -(4160.0), "when calling setPosition in ScenarioData, line 454")
	OriginCatalog_OriginCatalog_add(this67, "visayan_polities", "Visayan Polities", "southeast_asia", "Maps/SoutheastAsia.w3x", "sea_philippines", "cebu", "when calling add in ScenarioData, line 455")
	OriginCatalog_OriginCatalog_setPosition(this67, "visayan_polities", 8768.0, 576.0, "when calling setPosition in ScenarioData, line 456")
	OriginCatalog_OriginCatalog_add(this67, "warsangali_sultanate", "Warsangali Sultanate", "africa", "Maps/Africa.w3x", "africa_horn_swahili", "las_khorey", "when calling add in ScenarioData, line 457")
	OriginCatalog_OriginCatalog_setPosition(this67, "warsangali_sultanate", 5312.0, 5056.0, "when calling setPosition in ScenarioData, line 458")
	OriginCatalog_OriginCatalog_add(this67, "wendat_confederacies", "Wendat Confederacies", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_north_atlantic", "wendat_council_network", "when calling add in ScenarioData, line 459")
	OriginCatalog_OriginCatalog_setPosition(this67, "wendat_confederacies", 8128.0, -(1088.0), "when calling setPosition in ScenarioData, line 460")
	OriginCatalog_OriginCatalog_add(this67, "western_himalayan_states", "Western Himalayan Kingdoms", "middle_east_india", "Maps/MiddleEastIndia.w3x", "mei_ganges_himalaya", "jumla", "when calling add in ScenarioData, line 461")
	OriginCatalog_OriginCatalog_setPosition(this67, "western_himalayan_states", -(5056.0), -(4800.0), "when calling setPosition in ScenarioData, line 462")
	OriginCatalog_OriginCatalog_add(this67, "wild_jurchen_confederacies", "Wild Jurchen Confederacies", "east_asia", "Maps/EastAsia.w3x", "east_asia_china_north", "wild_jurchen_court", "when calling add in ScenarioData, line 463")
	OriginCatalog_OriginCatalog_setPosition(this67, "wild_jurchen_confederacies", -(4160.0), -(2112.0), "when calling setPosition in ScenarioData, line 464")
	OriginCatalog_OriginCatalog_add(this67, "yapese_domains", "Yapese Paramount Domains", "pacific_west", "Maps/PacificWest.w3x", "pacific_micronesia", "yap_council", "when calling add in ScenarioData, line 465")
	OriginCatalog_OriginCatalog_setPosition(this67, "yapese_domains", -(576.0), 1344.0, "when calling setPosition in ScenarioData, line 466")
	OriginCatalog_OriginCatalog_add(this67, "yucatan_maya_jurisdictions", "Yucatec Maya Jurisdictions", "americas_north_central", "Maps/AmericasNorthCentral.w3x", "americas_mexico_central", "yucatan_kuchkabal_courts", "when calling add in ScenarioData, line 467")
	OriginCatalog_OriginCatalog_setPosition(this67, "yucatan_maya_jurisdictions", -(64.0), -(6848.0), "when calling setPosition in ScenarioData, line 468")
	OriginCatalog_OriginCatalog_add(this67, "zayyanid_tlemcen", "Zayyanid Kingdom of Tlemcen", "africa", "Maps/Africa.w3x", "africa_maghreb_med_atlantic", "tlemcen_city", "when calling add in ScenarioData, line 469")
	OriginCatalog_OriginCatalog_setPosition(this67, "zayyanid_tlemcen", 5824.0, 3008.0, "when calling setPosition in ScenarioData, line 470")
	wurst_stack_depth = (wurst_stack_depth - 1)
	this66 = Bootstrap_bootstrapOriginSelection
	wurst_stack[wurst_stack_depth] = "when calling registerOriginSelection in Bootstrap, line 26"
	wurst_stack_depth = (wurst_stack_depth + 1)
	p1 = CommandRouter_COMMAND_RELEASE
	wurst_stack[wurst_stack_depth] = "when calling new_OriginCommandHandler in CommandRouter, line 486"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this73 = OriginCommandHandler:create15()
	wurst_stack[wurst_stack_depth] = "when calling construct_OriginCommandHandler in CommandRouter, line 467"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling OriginCommandHandler_init in CommandRouter, line 467"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	OriginCommandHandler_controller_storage[this73] = this66
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	CommandRegistry_CommandRegistry_register(this63, "origin", "citizenship", "origin [page N|search WORDS|choose ID]", "Choose where your individual character is from.", "Search and page through every active starting polity, then confirm one immutable origin. This does not give direct control of that country.", 0, 99, p1, this73, "when calling register in CommandRouter, line 486")
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling installCommandRegistry in Bootstrap, line 27"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling new_WarcraftCommandChatNatives in CommandRouter, line 271"
	wurst_stack_depth = (wurst_stack_depth + 1)
	this74 = WarcraftCommandChatNatives:create19()
	wurst_stack[wurst_stack_depth] = "when calling construct_WarcraftCommandChatNatives in CommandRouter, line 235"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling WarcraftCommandChatNatives_init in CommandRouter, line 235"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	installCommandRegistry(this63, this74, "when calling installCommandRegistry in CommandRouter, line 271")
	wurst_stack_depth = (wurst_stack_depth - 1)
	whichTimer = CreateTimer()
	inlineDone14 = false
	if (whichTimer == nil) then
		inlineDone14 = true
	end
	if not(inlineDone14) then
		TimerStart(whichTimer, 0., false, __wurst_callback_bridge_openBootstrapOriginSelection)
	end
	mission2 = ScenarioSettings_SCENARIO_BOOTSTRAP_MESSAGE
	wurst_stack[wurst_stack_depth] = "when calling print in Bootstrap, line 29"
	wurst_stack_depth = (wurst_stack_depth + 1)
	toPlayer3 = Player_localPlayer
	duration1 = Printing_DEBUG_MSG_DURATION
	inlineDone15 = false
	if (toPlayer3 == nil) then
		inlineDone15 = true
	end
	if not(inlineDone15) then
		DisplayTimedTextToPlayer(toPlayer3, 0., 0., duration1, mission2)
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
end

function init_CampaignHandoff(__wurst_stackPos99) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos99
	wurst_stack_depth = (wurst_stack_depth + 1)
	CampaignHandoff_HANDOFF_REQUEST = "request"
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_CampaignSaveManager(__wurst_stackPos97) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos97
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Colors(__wurst_stackPos86) 
	local this_red = 0
	local this_green = 0
	local x9 = nil
	local number1 = nil
	local q2 = nil
	local x10 = nil
	local y7 = nil
	local tuple_assignment = 0
	local tuple_assignment1 = 0
	wurst_stack[wurst_stack_depth] = __wurst_stackPos86
	wurst_stack_depth = (wurst_stack_depth + 1)
	Colors_hexs[0] = "0"
	Colors_hexs[1] = "1"
	Colors_hexs[2] = "2"
	Colors_hexs[3] = "3"
	Colors_hexs[4] = "4"
	Colors_hexs[5] = "5"
	Colors_hexs[6] = "6"
	Colors_hexs[7] = "7"
	Colors_hexs[8] = "8"
	Colors_hexs[9] = "9"
	Colors_hexs[10] = "A"
	Colors_hexs[11] = "B"
	Colors_hexs[12] = "C"
	Colors_hexs[13] = "D"
	Colors_hexs[14] = "E"
	Colors_hexs[15] = "F"
	Colors_decs = Table_new_Table("when calling new_Table in Colors, line 14")
	Colors_COLOR_WHITE_red = 255
	Colors_COLOR_WHITE_green = 255
	Colors_COLOR_WHITE_blue = 255
	Colors_COLOR_WHITE_alpha = 255
	Colors_COLOR_BLACK_red = 0
	Colors_COLOR_BLACK_green = 0
	Colors_COLOR_BLACK_blue = 0
	Colors_COLOR_BLACK_alpha = 0
	Colors_COLOR_GOLD_red = 255
	Colors_COLOR_GOLD_green = 204
	Colors_COLOR_GOLD_blue = 0
	Colors_COLOR_GOLD_alpha = 255
	this_red = Colors_COLOR_WHITE_red
	this_green = Colors_COLOR_WHITE_green
	tuple_assignment = Colors_COLOR_WHITE_blue
	tuple_assignment1 = Colors_COLOR_WHITE_alpha
	wurst_stack[wurst_stack_depth] = "when calling toColorString in Colors, line 22"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment1 // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment1))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment1 - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not(("|c" == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat("|c", x10)
		else
			x9 = "|c"
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_red // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_red))) then
		q2 = (q2 + 1)
	end
	number1 = (this_red - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_green // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_green))) then
		q2 = (q2 + 1)
	end
	number1 = (this_green - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			__wurst_rawConcat(x9, x10)
		end
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	this_red = Colors_COLOR_BLACK_red
	this_green = Colors_COLOR_BLACK_green
	tuple_assignment = Colors_COLOR_BLACK_blue
	tuple_assignment1 = Colors_COLOR_BLACK_alpha
	wurst_stack[wurst_stack_depth] = "when calling toColorString in Colors, line 23"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment1 // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment1))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment1 - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not(("|c" == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat("|c", x10)
		else
			x9 = "|c"
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_red // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_red))) then
		q2 = (q2 + 1)
	end
	number1 = (this_red - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_green // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_green))) then
		q2 = (q2 + 1)
	end
	number1 = (this_green - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			__wurst_rawConcat(x9, x10)
		end
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	this_red = Colors_COLOR_GOLD_red
	this_green = Colors_COLOR_GOLD_green
	tuple_assignment = Colors_COLOR_GOLD_blue
	tuple_assignment1 = Colors_COLOR_GOLD_alpha
	wurst_stack[wurst_stack_depth] = "when calling toColorString in Colors, line 24"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment1 // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment1))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment1 - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not(("|c" == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat("|c", x10)
		else
			x9 = "|c"
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_red // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_red))) then
		q2 = (q2 + 1)
	end
	number1 = (this_red - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (this_green // 16)
	if ((q2 < 0) and not(((q2 * 16) == this_green))) then
		q2 = (q2 + 1)
	end
	number1 = (this_green - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			x9 = __wurst_rawConcat(x9, x10)
		end
	else
		x9 = x10
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling toHex in Colors, line 195"
	wurst_stack_depth = (wurst_stack_depth + 1)
	q2 = (tuple_assignment // 16)
	if ((q2 < 0) and not(((q2 * 16) == tuple_assignment))) then
		q2 = (q2 + 1)
	end
	number1 = (tuple_assignment - (q2 * 16))
	wurst_stack_depth = (wurst_stack_depth - 1)
	x10 = Colors_hexs[q2]
	y7 = Colors_hexs[number1]
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x10 == nil)) then
		if not((y7 == nil)) then
			x10 = __wurst_rawConcat(x10, y7)
		end
	else
		x10 = y7
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	wurst_stack[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((x9 == nil)) then
		if not((x10 == nil)) then
			__wurst_rawConcat(x9, x10)
		end
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	initializeTable("when calling initializeTable in Colors, line 276")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function initializeTable(__wurst_stackPos102) 
	local wurst_stack_local6 = wurst_stack
	local Colors_hexs_local = Colors_hexs
	local i13 = nil
	local this75 = nil
	local this76 = nil
	local parentKey3 = nil
	local childKey1 = nil
	local this77 = nil
	wurst_stack_local6[wurst_stack_depth] = __wurst_stackPos102
	wurst_stack_depth = (wurst_stack_depth + 1)
	i13 = 0
	while true do
		if (i13 > 15) then
			break
		end
		this75 = Colors_decs
		this77 = Colors_hexs_local[i13]
		wurst_stack_local6[wurst_stack_depth] = "when calling getHash in Colors, line 273"
		wurst_stack_depth = (wurst_stack_depth + 1)
		parentKey3 = StringHash(this77)
		wurst_stack_depth = (wurst_stack_depth - 1)
		childKey1 = parentKey3
		wurst_stack_local6[wurst_stack_depth] = "when calling saveInt in Colors, line 273"
		wurst_stack_depth = (wurst_stack_depth + 1)
		this76 = Table_ht
		parentKey3 = __wurst_classToIndex(this75)
		wurst_stack_local6[wurst_stack_depth] = "when calling saveInt in Table, line 44"
		wurst_stack_depth = (wurst_stack_depth + 1)
		__wurst_SaveInteger(this76, parentKey3, childKey1, i13)
		wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
		i13 = (i13 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_CommandRouter(__wurst_stackPos95) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos95
	wurst_stack_depth = (wurst_stack_depth + 1)
	CommandRouter_COMMAND_RELEASE = 0
	CommandRouter_active = nil
	CommandRouter_chatNatives = nil
	CommandRouter_chatListener = nil
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function firstSpace(s2, __wurst_stackPos28) 
	local i14 = nil
	local temp14 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos28
	wurst_stack_depth = (wurst_stack_depth + 1)
	i14 = 0
	temp14 = (StringLength(s2) - 1)
	while true do
		if (i14 > temp14) then
			break
		end
		if (SubString(s2, i14, (i14 + 1)) == " ") then
			wurst_stack_depth = (wurst_stack_depth - 1)
			return i14
		end
		i14 = (i14 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return -1
end

function normalizeCommandLine(input, __wurst_stackPos27) 
	local wurst_stack_local7 = wurst_stack
	local result2 = nil
	local pending = nil
	local started = nil
	local i15 = nil
	local temp15 = nil
	local c7 = nil
	wurst_stack_local7[wurst_stack_depth] = __wurst_stackPos27
	wurst_stack_depth = (wurst_stack_depth + 1)
	result2 = ""
	pending = false
	started = false
	i15 = 0
	temp15 = (StringLength(input) - 1)
	while true do
		if (i15 > temp15) then
			break
		end
		c7 = SubString(input, i15, (i15 + 1))
		if ((((c7 == " ") or (c7 == "\t")) or (c7 == "\n")) or (c7 == "\r")) then
			if started then
				pending = true
			end
		else
			if pending then
				wurst_stack_local7[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((result2 == nil)) then
					if not((" " == nil)) then
						result2 = __wurst_rawConcat(result2, " ")
					end
				else
					result2 = " "
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
			end
			if (not(started) and (c7 == "/")) then
			else
				wurst_stack_local7[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not((result2 == nil)) then
					if not((c7 == nil)) then
						c7 = __wurst_rawConcat(result2, c7)
					else
						c7 = result2
					end
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				result2 = c7
				started = true
			end
			pending = false
		end
		i15 = (i15 + 1)
	end
	i15 = firstSpace(result2, "when calling firstSpace in CommandRouter, line 67")
	if (i15 < 0) then
		c7 = result2
		wurst_stack_local7[wurst_stack_depth] = "when calling lower in CommandRouter, line 69"
		wurst_stack_depth = (wurst_stack_depth + 1)
		c7 = StringCase(c7, false)
		wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
		return c7
	end
	c7 = SubString(result2, 0, i15)
	wurst_stack_local7[wurst_stack_depth] = "when calling lower in CommandRouter, line 70"
	wurst_stack_depth = (wurst_stack_depth + 1)
	c7 = StringCase(c7, false)
	wurst_stack_depth = (wurst_stack_depth - 1)
	result2 = SubString(result2, i15, StringLength(result2))
	wurst_stack_local7[wurst_stack_depth] = "when calling __wurst_stringConcat"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if not((c7 == nil)) then
		if not((result2 == nil)) then
			c7 = __wurst_rawConcat(c7, result2)
		end
	else
		c7 = result2
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
	return c7
end

function replace(source1, wanted1, value2, __wurst_stackPos29) 
	local wurst_stack_local8 = wurst_stack
	local i16 = nil
	local x11 = nil
	local y8 = nil
	wurst_stack_local8[wurst_stack_depth] = __wurst_stackPos29
	wurst_stack_depth = (wurst_stack_depth + 1)
	x11 = ""
	i16 = 0
	while true do
		if (i16 >= StringLength(source1)) then
			break
		end
		if (((i16 + StringLength(wanted1)) <= StringLength(source1)) and (SubString(source1, i16, (i16 + StringLength(wanted1))) == wanted1)) then
			wurst_stack_local8[wurst_stack_depth] = "when calling __wurst_stringConcat"
			wurst_stack_depth = (wurst_stack_depth + 1)
			if not((x11 == nil)) then
				if not((value2 == nil)) then
					x11 = __wurst_rawConcat(x11, value2)
				end
			else
				x11 = value2
			end
			wurst_stack_depth = (wurst_stack_depth - 1)
			i16 = (i16 + StringLength(wanted1))
		else
			y8 = SubString(source1, i16, (i16 + 1))
			wurst_stack_local8[wurst_stack_depth] = "when calling __wurst_stringConcat"
			wurst_stack_depth = (wurst_stack_depth + 1)
			if not((x11 == nil)) then
				if not((y8 == nil)) then
					x11 = __wurst_rawConcat(x11, y8)
				end
			else
				x11 = y8
			end
			wurst_stack_depth = (wurst_stack_depth - 1)
			i16 = (i16 + 1)
		end
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return x11
end

function hasAlias(aliases, wanted, __wurst_stackPos25) 
	local wurst_stack_local9 = wurst_stack
	local start1 = nil
	local i17 = nil
	local temp16 = nil
	local s5 = nil
	wurst_stack_local9[wurst_stack_depth] = __wurst_stackPos25
	wurst_stack_depth = (wurst_stack_depth + 1)
	start1 = 0
	i17 = 0
	temp16 = StringLength(aliases)
	while true do
		if (i17 > temp16) then
			break
		end
		if ((i17 == StringLength(aliases)) or (SubString(aliases, i17, (i17 + 1)) == ",")) then
			s5 = SubString(aliases, start1, i17)
			wurst_stack_local9[wurst_stack_depth] = "when calling lower in CommandRouter, line 123"
			wurst_stack_depth = (wurst_stack_depth + 1)
			s5 = StringCase(s5, false)
			wurst_stack_depth = (wurst_stack_depth - 1)
			if (s5 == wanted) then
				wurst_stack_depth = (wurst_stack_depth - 1)
				return true
			end
			start1 = (i17 + 1)
		end
		i17 = (i17 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return false
end

function dispatch_CommandChatNatives_retire(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandChatNatives_retire)(receiver, ...)
end

function dispatch_CommandChatNatives_registerChat(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandChatNatives_registerChat)(receiver, ...)
end

function __wurst_callback_bridge_routeChat(...) 
	xpcall(bridge_routeChat, __wurst_callback_error, ...)
end

function installCommandRegistry(registry, natives, __wurst_stackPos101) 
	local i18 = nil
	local temp17 = nil
	local natives1 = nil
	local whichTrigger1 = nil
	local inlineDone16 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos101
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling uninstallCommandRegistry in CommandRouter, line 261"
	wurst_stack_depth = (wurst_stack_depth + 1)
	whichTrigger1 = CommandRouter_chatListener
	natives1 = CommandRouter_chatNatives
	CommandRouter_active = nil
	CommandRouter_chatListener = nil
	CommandRouter_chatNatives = nil
	if not((whichTrigger1 == nil)) then
		dispatch_CommandChatNatives_retire(natives1, whichTrigger1, "when calling retire in CommandRouter, line 259")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	if ((registry == nil) or (natives == nil)) then
		wurst_stack_depth = (wurst_stack_depth - 1)
		return 
	end
	CommandRouter_active = registry
	CommandRouter_chatNatives = natives
	CommandRouter_chatListener = CreateTrigger()
	i18 = 0
	temp17 = (bj_MAX_PLAYERS - 1)
	while true do
		if (i18 > temp17) then
			break
		end
		dispatch_CommandChatNatives_registerChat(natives, CommandRouter_chatListener, Player(i18), "/", false, "when calling registerChat in CommandRouter, line 268")
		i18 = (i18 + 1)
	end
	whichTrigger1 = CommandRouter_chatListener
	inlineDone16 = false
	if (whichTrigger1 == nil) then
		inlineDone16 = true
	end
	if not(inlineDone16) then
		TriggerAddAction(whichTrigger1, __wurst_callback_bridge_routeChat)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_Destructable(__wurst_stackPos74) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos74
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_ErrorHandling(__wurst_stackPos80) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos80
	wurst_stack_depth = (wurst_stack_depth + 1)
	ErrorHandling_MUTE_ERROR_DURATION = 60
	ErrorHandling_PRIMARY_ERROR_KEY = -1
	ErrorHandling_HT = hashtable_compiletime
	ErrorHandling_suppressErrorMessages = false
	ErrorHandling_errorListenerCount = 0
	ErrorHandling_notifyingErrorListeners = false
	ErrorHandling_notifiedListener = 0
	ErrorHandling_notifiedMessage = ""
	ErrorHandling_errorListenerForce = CreateForce()
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function __wurst_callback_bridge_notifyCurrentErrorListener(...) 
	xpcall(bridge_notifyCurrentErrorListener, __wurst_callback_error, ...)
end

function notifyErrorListeners(msg2, __wurst_stackPos103) 
	local i19 = nil
	local temp18 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos103
	wurst_stack_depth = (wurst_stack_depth + 1)
	if ((ErrorHandling_errorListenerCount > 0) and not(ErrorHandling_notifyingErrorListeners)) then
		ErrorHandling_notifyingErrorListeners = true
		ErrorHandling_notifiedMessage = msg2
		i19 = 0
		temp18 = (ErrorHandling_errorListenerCount - 1)
		while true do
			if (i19 > temp18) then
				break
			end
			ErrorHandling_notifiedListener = i19
			__wurst_ForForce(ErrorHandling_errorListenerForce, __wurst_callback_bridge_notifyCurrentErrorListener)
			i19 = (i19 + 1)
		end
		ErrorHandling_notifyingErrorListeners = false
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function error1(msg1, __wurst_stackPos67) 
	local wurst_stack_local10 = wurst_stack
	local hash = nil
	local this78 = nil
	local this79 = nil
	local stackTrace_tempReturn8 = nil
	local showTo = nil
	local temp19 = nil
	local inlineRet13 = nil
	local x12 = nil
	local inlineDone17 = nil
	local temp20 = nil
	local inlineRet14 = nil
	local inlineRet15 = nil
	local temp21 = nil
	local inlineRet16 = nil
	wurst_stack_local10[wurst_stack_depth] = __wurst_stackPos67
	wurst_stack_depth = (wurst_stack_depth + 1)
	if MagicFunctions_compiletime then
		wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
		wurst_stack_depth = (wurst_stack_depth + 1)
		if not(("ERROR: " == nil)) then
			if not((msg1 == nil)) then
				inlineRet16 = __wurst_rawConcat("ERROR: ", msg1)
			else
				inlineRet16 = "ERROR: "
			end
		else
			inlineRet16 = msg1
		end
		wurst_stack_depth = (wurst_stack_depth - 1)
		compileError(inlineRet16, "when calling compileError in ErrorHandling, line 103")
	else
		if not(ErrorHandling_suppressErrorMessages) then
			wurst_stack_local10[wurst_stack_depth] = "when calling getHash in ErrorHandling, line 106"
			wurst_stack_depth = (wurst_stack_depth + 1)
			hash = StringHash(msg1)
			wurst_stack_depth = (wurst_stack_depth - 1)
			this79 = ErrorHandling_HT
			temp19 = ErrorHandling_PRIMARY_ERROR_KEY
			wurst_stack_local10[wurst_stack_depth] = "when calling hasInt in ErrorHandling, line 107"
			wurst_stack_depth = (wurst_stack_depth + 1)
			stackTrace_tempReturn8 = __wurst_HaveSavedInteger(this79, temp19, hash)
			wurst_stack_depth = (wurst_stack_depth - 1)
			this79 = ErrorHandling_HT
			if stackTrace_tempReturn8 then
				temp21 = ErrorHandling_PRIMARY_ERROR_KEY
				wurst_stack_local10[wurst_stack_depth] = "when calling loadInt in ErrorHandling, line 109"
				wurst_stack_depth = (wurst_stack_depth + 1)
				temp21 = __wurst_LoadInteger(this79, temp21, hash)
				wurst_stack_depth = (wurst_stack_depth - 1)
				if ((temp21 + ErrorHandling_MUTE_ERROR_DURATION) < GameTimer_currentTime) then
					inlineRet16 = msg1
					inlineRet14 = " Stacktrace:"
					temp20 = wurst_stack_depth
					temp21 = 0
					while true do
						temp20 = (temp20 - 1)
						temp21 = (temp21 + 1)
						if ((temp21 > 20) or (temp20 < 0)) then
							break
						end
						inlineRet15 = "\n   "
						this78 = wurst_stack_local10[temp20]
						wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
						wurst_stack_depth = (wurst_stack_depth + 1)
						if not(("\n   " == nil)) then
							if not((this78 == nil)) then
								inlineRet15 = __wurst_rawConcat(inlineRet15, this78)
							else
								inlineRet15 = "\n   "
							end
						else
							inlineRet15 = this78
						end
						wurst_stack_depth = (wurst_stack_depth - 1)
						wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
						wurst_stack_depth = (wurst_stack_depth + 1)
						if not((inlineRet14 == nil)) then
							if not((inlineRet15 == nil)) then
								inlineRet14 = __wurst_rawConcat(inlineRet14, inlineRet15)
							end
						else
							inlineRet14 = inlineRet15
						end
						wurst_stack_depth = (wurst_stack_depth - 1)
					end
					if (inlineRet14 == " Stacktrace:") then
						inlineRet14 = " Stacktrace: <none>"
					end
					wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not((inlineRet16 == nil)) then
						if not((inlineRet14 == nil)) then
							inlineRet16 = __wurst_rawConcat(inlineRet16, inlineRet14)
						end
					else
						inlineRet16 = inlineRet14
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
					wurst_stack_local10[wurst_stack_depth] = "when calling error in ErrorHandling, line 111"
					wurst_stack_depth = (wurst_stack_depth + 1)
					showTo = Player_localPlayer
					wurst_stack_local10[wurst_stack_depth] = "when calling printLog in Printing, line 49"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if (Printing_DEBUG_LEVEL <= 4) then
						wurst_stack_local10[wurst_stack_depth] = "when calling getTag in Printing, line 81"
						wurst_stack_depth = (wurst_stack_depth + 1)
						temp19 = 4
						wurst_stack_depth = (wurst_stack_depth - 1)
						inlineRet13 = "|cffFB2700error|r"
						stackTrace_tempReturn8 = true
						wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
						wurst_stack_depth = (wurst_stack_depth + 1)
						if not((inlineRet13 == nil)) then
							if not((" - " == nil)) then
								inlineRet13 = __wurst_rawConcat(inlineRet13, " - ")
							end
						else
							inlineRet13 = " - "
						end
						wurst_stack_depth = (wurst_stack_depth - 1)
						wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
						wurst_stack_depth = (wurst_stack_depth + 1)
						if not((inlineRet13 == nil)) then
							if not((inlineRet16 == nil)) then
								inlineRet16 = __wurst_rawConcat(inlineRet13, inlineRet16)
							else
								inlineRet16 = inlineRet13
							end
						end
						wurst_stack_depth = (wurst_stack_depth - 1)
						x12 = Printing_DEBUG_MSG_DURATION
						inlineDone17 = false
						if (showTo == nil) then
							inlineDone17 = true
						end
						if not(inlineDone17) then
							DisplayTimedTextToPlayer(showTo, 0., 0., x12, inlineRet16)
						end
					end
					wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
					this79 = ErrorHandling_HT
					temp20 = ErrorHandling_PRIMARY_ERROR_KEY
					x12 = GameTimer_currentTime
					wurst_stack_local10[wurst_stack_depth] = "when calling toInt in ErrorHandling, line 112"
					wurst_stack_depth = (wurst_stack_depth + 1)
					temp19 = R2I(x12)
					wurst_stack_depth = (wurst_stack_depth - 1)
					wurst_stack_local10[wurst_stack_depth] = "when calling saveInt in ErrorHandling, line 112"
					wurst_stack_depth = (wurst_stack_depth + 1)
					__wurst_SaveInteger(this79, temp20, hash, temp19)
					wurst_stack_depth = (wurst_stack_depth - 1)
					this79 = ErrorHandling_HT
					temp20 = ErrorHandling_PRIMARY_ERROR_KEY
					wurst_stack_local10[wurst_stack_depth] = "when calling saveBoolean in ErrorHandling, line 113"
					wurst_stack_depth = (wurst_stack_depth + 1)
					__wurst_SaveBoolean(this79, temp20, hash, false)
					wurst_stack_depth = (wurst_stack_depth - 1)
				else
					this79 = ErrorHandling_HT
					temp21 = ErrorHandling_PRIMARY_ERROR_KEY
					wurst_stack_local10[wurst_stack_depth] = "when calling hasBoolean in ErrorHandling, line 114"
					wurst_stack_depth = (wurst_stack_depth + 1)
					stackTrace_tempReturn8 = __wurst_HaveSavedBoolean(this79, temp21, hash)
					wurst_stack_depth = (wurst_stack_depth - 1)
					if stackTrace_tempReturn8 then
						this79 = ErrorHandling_HT
						temp21 = ErrorHandling_PRIMARY_ERROR_KEY
						wurst_stack_local10[wurst_stack_depth] = "when calling loadBoolean in ErrorHandling, line 115"
						wurst_stack_depth = (wurst_stack_depth + 1)
						stackTrace_tempReturn8 = __wurst_LoadBoolean(this79, temp21, hash)
						wurst_stack_depth = (wurst_stack_depth - 1)
						if not(stackTrace_tempReturn8) then
							wurst_stack_local10[wurst_stack_depth] = "when calling error in ErrorHandling, line 116"
							wurst_stack_depth = (wurst_stack_depth + 1)
							showTo = Player_localPlayer
							wurst_stack_local10[wurst_stack_depth] = "when calling printLog in Printing, line 49"
							wurst_stack_depth = (wurst_stack_depth + 1)
							if (Printing_DEBUG_LEVEL <= 4) then
								wurst_stack_local10[wurst_stack_depth] = "when calling getTag in Printing, line 81"
								wurst_stack_depth = (wurst_stack_depth + 1)
								temp20 = 4
								wurst_stack_depth = (wurst_stack_depth - 1)
								inlineRet14 = "|cffFB2700error|r"
								stackTrace_tempReturn8 = true
								inlineRet13 = inlineRet14
								wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
								wurst_stack_depth = (wurst_stack_depth + 1)
								if not((inlineRet14 == nil)) then
									if not((" - " == nil)) then
										inlineRet13 = __wurst_rawConcat(inlineRet14, " - ")
									end
								else
									inlineRet13 = " - "
								end
								wurst_stack_depth = (wurst_stack_depth - 1)
								wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
								wurst_stack_depth = (wurst_stack_depth + 1)
								if not((inlineRet13 == nil)) then
									if not(("|cffFF3A29Excessive repeating errors are being omitted" == nil)) then
										inlineRet16 = __wurst_rawConcat(inlineRet13, "|cffFF3A29Excessive repeating errors are being omitted")
									else
										inlineRet16 = inlineRet13
									end
								else
									inlineRet16 = "|cffFF3A29Excessive repeating errors are being omitted"
								end
								wurst_stack_depth = (wurst_stack_depth - 1)
								x12 = Printing_DEBUG_MSG_DURATION
								inlineDone17 = false
								if (showTo == nil) then
									inlineDone17 = true
								end
								if not(inlineDone17) then
									DisplayTimedTextToPlayer(showTo, 0., 0., x12, inlineRet16)
								end
							end
							wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
							this79 = ErrorHandling_HT
							temp20 = ErrorHandling_PRIMARY_ERROR_KEY
							wurst_stack_local10[wurst_stack_depth] = "when calling saveBoolean in ErrorHandling, line 117"
							wurst_stack_depth = (wurst_stack_depth + 1)
							__wurst_SaveBoolean(this79, temp20, hash, true)
							wurst_stack_depth = (wurst_stack_depth - 1)
						end
					else
						wurst_stack_local10[wurst_stack_depth] = "when calling error in ErrorHandling, line 119"
						wurst_stack_depth = (wurst_stack_depth + 1)
						showTo = Player_localPlayer
						wurst_stack_local10[wurst_stack_depth] = "when calling printLog in Printing, line 49"
						wurst_stack_depth = (wurst_stack_depth + 1)
						if (Printing_DEBUG_LEVEL <= 4) then
							wurst_stack_local10[wurst_stack_depth] = "when calling getTag in Printing, line 81"
							wurst_stack_depth = (wurst_stack_depth + 1)
							temp21 = 4
							wurst_stack_depth = (wurst_stack_depth - 1)
							inlineRet15 = "|cffFB2700error|r"
							stackTrace_tempReturn8 = true
							inlineRet13 = inlineRet15
							wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
							wurst_stack_depth = (wurst_stack_depth + 1)
							if not((inlineRet15 == nil)) then
								if not((" - " == nil)) then
									inlineRet13 = __wurst_rawConcat(inlineRet15, " - ")
								end
							else
								inlineRet13 = " - "
							end
							wurst_stack_depth = (wurst_stack_depth - 1)
							wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
							wurst_stack_depth = (wurst_stack_depth + 1)
							if not((inlineRet13 == nil)) then
								if not(("|cffFF3A29Excessive repeating errors are being omitted" == nil)) then
									inlineRet16 = __wurst_rawConcat(inlineRet13, "|cffFF3A29Excessive repeating errors are being omitted")
								else
									inlineRet16 = inlineRet13
								end
							else
								inlineRet16 = "|cffFF3A29Excessive repeating errors are being omitted"
							end
							wurst_stack_depth = (wurst_stack_depth - 1)
							x12 = Printing_DEBUG_MSG_DURATION
							inlineDone17 = false
							if (showTo == nil) then
								inlineDone17 = true
							end
							if not(inlineDone17) then
								DisplayTimedTextToPlayer(showTo, 0., 0., x12, inlineRet16)
							end
						end
						wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
						this79 = ErrorHandling_HT
						temp20 = ErrorHandling_PRIMARY_ERROR_KEY
						wurst_stack_local10[wurst_stack_depth] = "when calling saveBoolean in ErrorHandling, line 120"
						wurst_stack_depth = (wurst_stack_depth + 1)
						__wurst_SaveBoolean(this79, temp20, hash, true)
						wurst_stack_depth = (wurst_stack_depth - 1)
					end
				end
			else
				temp20 = ErrorHandling_PRIMARY_ERROR_KEY
				x12 = GameTimer_currentTime
				wurst_stack_local10[wurst_stack_depth] = "when calling toInt in ErrorHandling, line 122"
				wurst_stack_depth = (wurst_stack_depth + 1)
				temp19 = R2I(x12)
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local10[wurst_stack_depth] = "when calling saveInt in ErrorHandling, line 122"
				wurst_stack_depth = (wurst_stack_depth + 1)
				__wurst_SaveInteger(this79, temp20, hash, temp19)
				wurst_stack_depth = (wurst_stack_depth - 1)
				wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if not(("Message: " == nil)) then
					if not((msg1 == nil)) then
						inlineRet13 = __wurst_rawConcat("Message: ", msg1)
					else
						inlineRet13 = "Message: "
					end
				else
					inlineRet13 = msg1
				end
				wurst_stack_depth = (wurst_stack_depth - 1)
				inlineRet14 = " Stacktrace:"
				hash = wurst_stack_depth
				temp20 = 0
				while true do
					hash = (hash - 1)
					temp20 = (temp20 + 1)
					if ((temp20 > 20) or (hash < 0)) then
						break
					end
					inlineRet15 = "\n   "
					this78 = wurst_stack_local10[hash]
					wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not(("\n   " == nil)) then
						if not((this78 == nil)) then
							inlineRet15 = __wurst_rawConcat(inlineRet15, this78)
						else
							inlineRet15 = "\n   "
						end
					else
						inlineRet15 = this78
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
					wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not((inlineRet14 == nil)) then
						if not((inlineRet15 == nil)) then
							inlineRet14 = __wurst_rawConcat(inlineRet14, inlineRet15)
						end
					else
						inlineRet14 = inlineRet15
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
				end
				if (inlineRet14 == " Stacktrace:") then
					inlineRet14 = " Stacktrace: <none>"
				end
				inlineRet13 = __wurst_stringConcat(inlineRet13, inlineRet14, "when calling __wurst_stringConcat")
				wurst_stack_local10[wurst_stack_depth] = "when calling error in ErrorHandling, line 123"
				wurst_stack_depth = (wurst_stack_depth + 1)
				showTo = Player_localPlayer
				wurst_stack_local10[wurst_stack_depth] = "when calling printLog in Printing, line 49"
				wurst_stack_depth = (wurst_stack_depth + 1)
				if (Printing_DEBUG_LEVEL <= 4) then
					wurst_stack_local10[wurst_stack_depth] = "when calling getTag in Printing, line 81"
					wurst_stack_depth = (wurst_stack_depth + 1)
					temp21 = 4
					wurst_stack_depth = (wurst_stack_depth - 1)
					inlineRet16 = "|cffFB2700error|r"
					stackTrace_tempReturn8 = true
					wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not((inlineRet16 == nil)) then
						if not((" - " == nil)) then
							inlineRet16 = __wurst_rawConcat(inlineRet16, " - ")
						end
					else
						inlineRet16 = " - "
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
					wurst_stack_local10[wurst_stack_depth] = "when calling __wurst_stringConcat"
					wurst_stack_depth = (wurst_stack_depth + 1)
					if not((inlineRet16 == nil)) then
						if not((inlineRet13 == nil)) then
							inlineRet16 = __wurst_rawConcat(inlineRet16, inlineRet13)
						end
					else
						inlineRet16 = inlineRet13
					end
					wurst_stack_depth = (wurst_stack_depth - 1)
					x12 = Printing_DEBUG_MSG_DURATION
					inlineDone17 = false
					if (showTo == nil) then
						inlineDone17 = true
					end
					if not(inlineDone17) then
						DisplayTimedTextToPlayer(showTo, 0., 0., x12, inlineRet16)
					end
				end
				wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
			end
		end
		notifyErrorListeners(msg1, "when calling notifyErrorListeners in ErrorHandling, line 124")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_EventHelper(__wurst_stackPos93) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos93
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling new_HashMap in EventHelper, line 6"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling construct_HashMap in HashMap, line 7"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling construct_Table in HashMap, line 7"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling Table_init in Table, line 6"
	wurst_stack_depth = (((wurst_stack_depth + 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling HashMap_init in HashMap, line 7"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling new_HashMap in EventHelper, line 7"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling construct_HashMap in HashMap, line 7"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling construct_Table in HashMap, line 7"
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack[wurst_stack_depth] = "when calling Table_init in Table, line 6"
	wurst_stack_depth = (((wurst_stack_depth + 1) - 1) - 1)
	wurst_stack[wurst_stack_depth] = "when calling HashMap_init in HashMap, line 7"
	wurst_stack_depth = ((((wurst_stack_depth + 1) - 1) - 1) - 1)
	Table_new_Table("when calling new_Table in EventHelper, line 8")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_Force(__wurst_stackPos84) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos84
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Framehandle(__wurst_stackPos87) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos87
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function __wurst_callback_bridge_code__startPeriodic_GameTimer(...) 
	xpcall(bridge_code__startPeriodic_GameTimer, __wurst_callback_error, ...)
end

function init_GameTimer(__wurst_stackPos79) 
	local time = nil
	local timerCallBack = nil
	local whichTimer1 = nil
	local inlineDone18 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos79
	wurst_stack_depth = (wurst_stack_depth + 1)
	timerCallBack = CreateTimer()
	whichTimer1 = timerCallBack
	wurst_stack[wurst_stack_depth] = "when calling start in GameTimer, line 6"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone18 = false
	if (timerCallBack == nil) then
		inlineDone18 = true
	end
	if not(inlineDone18) then
		TimerStart(timerCallBack, 100000., false, nil)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	whichTimer1 = CreateTimer()
	time = Basics_ANIMATION_PERIOD
	wurst_stack[wurst_stack_depth] = "when calling startPeriodic in GameTimer, line 21"
	wurst_stack_depth = (wurst_stack_depth + 1)
	inlineDone18 = false
	if (whichTimer1 == nil) then
		inlineDone18 = true
	end
	if not(inlineDone18) then
		TimerStart(whichTimer1, time, true, __wurst_callback_bridge_code__startPeriodic_GameTimer)
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
end

function init_Group(__wurst_stackPos88) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos88
	wurst_stack_depth = (wurst_stack_depth + 1)
	CreateGroup()
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_HashList(__wurst_stackPos92) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos92
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Integer(__wurst_stackPos70) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos70
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Lightning(__wurst_stackPos89) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos89
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_MagicFunctions(__wurst_stackPos78) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos78
	wurst_stack_depth = (wurst_stack_depth + 1)
	MagicFunctions_compiletime = false
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function compileError(msg3, __wurst_stackPos104) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos104
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Maths(__wurst_stackPos71) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos71
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Matrices(__wurst_stackPos81) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos81
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Player(__wurst_stackPos75) 
	local i20 = nil
	local temp22 = nil
	wurst_stack[wurst_stack_depth] = __wurst_stackPos75
	wurst_stack_depth = (wurst_stack_depth + 1)
	Player_localPlayer = GetLocalPlayer()
	wurst_stack[wurst_stack_depth] = "when calling initPlayerArray in Player, line 11"
	wurst_stack_depth = (wurst_stack_depth + 1)
	i20 = 0
	temp22 = (bj_MAX_PLAYER_SLOTS - 1)
	while true do
		if (i20 > temp22) then
			break
		end
		i20 = (i20 + 1)
	end
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
end

function init_Playercolor(__wurst_stackPos85) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos85
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Printing(__wurst_stackPos77) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos77
	wurst_stack_depth = (wurst_stack_depth + 1)
	Printing_DEBUG_LEVEL = 2
	Printing_DEBUG_MSG_DURATION = 45.
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_Quaternion(__wurst_stackPos82) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos82
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_Real(__wurst_stackPos69) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos69
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_ScenarioData(__wurst_stackPos96) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos96
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function init_ScenarioSettings(__wurst_stackPos98) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos98
	wurst_stack_depth = (wurst_stack_depth + 1)
	ScenarioSettings_CAMPAIGN_CACHE_FILE = "AgeOfSailCampaign.w3v"
	ScenarioSettings_SCENARIO_BOOTSTRAP_MESSAGE = "Age of Sail: The World - development bootstrap loaded."
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_String(__wurst_stackPos72) 
	local wurst_stack_local11 = wurst_stack
	local this80 = nil
	local i21 = nil
	local temp23 = nil
	local key2 = nil
	local stop = nil
	local temp71 = nil
	wurst_stack_local11[wurst_stack_depth] = __wurst_stackPos72
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack_local11[wurst_stack_depth] = "when calling substring in String, line 16"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	wurst_stack_local11[wurst_stack_depth] = "when calling getHash in String, line 17"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	String_CONT_BYTE_PROBE = "ЀЁЂЃЄЅІЇЈЉЊЋЌЍЎЏАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмноп"
	String_CONT_BYTE_MAP = __wurst_InitHashtable()
	wurst_stack_local11[wurst_stack_depth] = "when calling substring in String, line 43"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	wurst_stack_local11[wurst_stack_depth] = "when calling getHash in String, line 43"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	String_charset = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	wurst_stack_local11[wurst_stack_depth] = "when calling length in String, line 62"
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
	this80 = String_charset
	wurst_stack_local11[wurst_stack_depth] = "when calling length in String, line 63"
	wurst_stack_depth = (wurst_stack_depth + 1)
	i21 = StringLength(this80)
	wurst_stack_depth = (wurst_stack_depth - 1)
	String_charsetlength = i21
	String_PRINTABLE_ASCII = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
	String_CHAR_ORDER_MAP = __wurst_InitHashtable()
	String_NON_CHARSET_ORDER_BASE = String_charsetlength
	wurst_stack_local11[wurst_stack_depth] = "when calling initCharOrder in String, line 99"
	wurst_stack_depth = (wurst_stack_depth + 1)
	i21 = 0
	this80 = String_PRINTABLE_ASCII
	wurst_stack_local11[wurst_stack_depth] = "when calling length in String, line 91"
	wurst_stack_depth = (wurst_stack_depth + 1)
	temp23 = StringLength(this80)
	wurst_stack_depth = (wurst_stack_depth - 1)
	temp23 = (temp23 - 1)
	while true do
		if (i21 > temp23) then
			break
		end
		this80 = String_PRINTABLE_ASCII
		stop = (i21 + 1)
		wurst_stack_local11[wurst_stack_depth] = "when calling substring in String, line 92"
		wurst_stack_depth = (wurst_stack_depth + 1)
		this80 = SubString(this80, i21, stop)
		wurst_stack_depth = (wurst_stack_depth - 1)
		if (this80 == StringCase(this80, true)) then
			key2 = string_indexOf(String_charset, this80, "when calling indexOf in String, line 94")
			if (key2 >= 0) then
			else
				key2 = ((String_NON_CHARSET_ORDER_BASE + i21) + 32)
			end
			temp71 = String_CHAR_ORDER_MAP
			wurst_stack_local11[wurst_stack_depth] = "when calling getHash in String, line 96"
			wurst_stack_depth = (wurst_stack_depth + 1)
			stop = StringHash(this80)
			wurst_stack_depth = (wurst_stack_depth - 1)
			__wurst_SaveInteger(temp71, 0, stop, (key2 + 1))
		end
		i21 = (i21 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	i21 = 0
	while true do
		if (i21 > 63) then
			break
		end
		temp71 = String_CONT_BYTE_MAP
		this80 = String_CONT_BYTE_PROBE
		temp23 = ((i21 * 2) + 1)
		key2 = ((i21 * 2) + 2)
		wurst_stack_local11[wurst_stack_depth] = "when calling substring in String, line 105"
		wurst_stack_depth = (wurst_stack_depth + 1)
		this80 = SubString(this80, temp23, key2)
		wurst_stack_depth = (wurst_stack_depth - 1)
		wurst_stack_local11[wurst_stack_depth] = "when calling getHash in String, line 105"
		wurst_stack_depth = (wurst_stack_depth + 1)
		temp23 = StringHash(this80)
		wurst_stack_depth = (wurst_stack_depth - 1)
		__wurst_SaveBoolean(temp71, 0, temp23, true)
		i21 = (i21 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function string_indexOf(this33, s4, __wurst_stackPos38) 
	local wurst_stack_local12 = wurst_stack
	local len = nil
	local i22 = nil
	local temp24 = nil
	local this81 = nil
	local stop1 = nil
	wurst_stack_local12[wurst_stack_depth] = __wurst_stackPos38
	wurst_stack_depth = (wurst_stack_depth + 1)
	wurst_stack_local12[wurst_stack_depth] = "when calling length in String, line 262"
	wurst_stack_depth = (wurst_stack_depth + 1)
	len = StringLength(s4)
	wurst_stack_depth = (wurst_stack_depth - 1)
	i22 = 0
	wurst_stack_local12[wurst_stack_depth] = "when calling length in String, line 263"
	wurst_stack_depth = (wurst_stack_depth + 1)
	temp24 = StringLength(this33)
	wurst_stack_depth = (wurst_stack_depth - 1)
	temp24 = (temp24 - len)
	while true do
		if (i22 > temp24) then
			break
		end
		this81 = this33
		stop1 = (i22 + len)
		wurst_stack_local12[wurst_stack_depth] = "when calling substring in String, line 264"
		wurst_stack_depth = (wurst_stack_depth + 1)
		this81 = SubString(this81, i22, stop1)
		wurst_stack_depth = (wurst_stack_depth - 1)
		if (this81 == s4) then
			wurst_stack_depth = (wurst_stack_depth - 1)
			return i22
		end
		i22 = (i22 + 1)
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
	return -1
end

function init_Table(__wurst_stackPos83) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos83
	wurst_stack_depth = (wurst_stack_depth + 1)
	Table_ht = hashtable_compiletime1
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_TypeCasting(__wurst_stackPos91) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos91
	wurst_stack_depth = (wurst_stack_depth + 1)
	TypeCasting_typecastdata = Table_new_Table("when calling new_Table in TypeCasting, line 7")
	__wurst_InitHashtable()
	wurst_stack[wurst_stack_depth] = "when calling initTypecastData in TypeCasting, line 21"
	wurst_stack_depth = (wurst_stack_depth + 1)
	Table_Table_saveString(TypeCasting_typecastdata, 0, "", "when calling saveString in TypeCasting, line 12")
	wurst_stack_depth = ((wurst_stack_depth - 1) - 1)
end

function init_Vectors(__wurst_stackPos73) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos73
	wurst_stack_depth = (wurst_stack_depth + 1)
	Location(0., 0.)
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_WC3Compatibility(__wurst_stackPos94) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos94
	wurst_stack_depth = (wurst_stack_depth + 1)
	WC3Compatibility_WC3_COMPAT_PATCH_FAMILY = "v3.0"
	WC3Compatibility_WC3_COMPAT_SCRIPT_BACKEND = "LUA"
	WC3Compatibility_WC3_HAS_MODERN_INVENTORY = true
	WC3Compatibility_WC3_HAS_NATIVE_SAVE_MANAGEMENT = true
	WC3Compatibility_WC3_HAS_FRAME_UI = true
	WC3Compatibility_WC3_HAS_PATHING_QUERIES = true
	WC3Compatibility_WC3_HAS_MODERN_UNIT_FIELDS = true
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function compatLoadPhysicalMap(mapPath, __wurst_stackPos9) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos9
	wurst_stack_depth = (wurst_stack_depth + 1)
	ChangeLevel(mapPath, true)
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function init_WeatherEffects(__wurst_stackPos90) 
	wurst_stack[wurst_stack_depth] = __wurst_stackPos90
	wurst_stack_depth = ((wurst_stack_depth + 1) - 1)
end

function bridge_openBootstrapOriginSelection() 
	local whichTimer2 = nil
	local inlineDone19 = nil
	wurst_stack[wurst_stack_depth] = "via function reference Bootstrap, line 28"
	wurst_stack_depth = (wurst_stack_depth + 1)
	whichTimer2 = GetExpiredTimer()
	inlineDone19 = false
	if (whichTimer2 == nil) then
		inlineDone19 = true
	end
	if not(inlineDone19) then
		DestroyTimer(whichTimer2)
	end
	if not((Bootstrap_bootstrapOriginSelection == nil)) then
		PauseGame(true)
		NewCampaignOriginController_NewCampaignOriginController_showPage(Bootstrap_bootstrapOriginSelection, 1, "when calling showPage in Bootstrap, line 18")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function dispatch_CommandChatNatives_eventListener(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandChatNatives_eventListener)(receiver, ...)
end

function dispatch_CommandChatNatives_eventPlayer(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandChatNatives_eventPlayer)(receiver, ...)
end

function dispatch_CommandChatNatives_eventText(receiver, ...) 
	return (__wurst_objectClass[receiver].CommandChatNatives_eventText)(receiver, ...)
end

function bridge_routeChat() 
	wurst_stack[wurst_stack_depth] = "via function reference CommandRouter, line 269"
	wurst_stack_depth = (wurst_stack_depth + 1)
	if ((not((CommandRouter_active == nil)) and not((CommandRouter_chatNatives == nil))) and (dispatch_CommandChatNatives_eventListener(CommandRouter_chatNatives, "when calling eventListener in CommandRouter, line 250") == CommandRouter_chatListener)) then
		CommandRegistry_CommandRegistry_dispatch(CommandRouter_active, dispatch_CommandChatNatives_eventPlayer(CommandRouter_chatNatives, "when calling eventPlayer in CommandRouter, line 251"), dispatch_CommandChatNatives_eventText(CommandRouter_chatNatives, "when calling eventText in CommandRouter, line 251"), "when calling dispatch in CommandRouter, line 251")
	end
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function dispatch_ErrorListener_onError(receiver, ...) 
	return (__wurst_objectClass[receiver].onError)(receiver, ...)
end

function bridge_notifyCurrentErrorListener() 
	wurst_stack[wurst_stack_depth] = "via function reference ErrorHandling, line 80"
	wurst_stack_depth = (wurst_stack_depth + 1)
	dispatch_ErrorListener_onError(ErrorHandling_errorListeners[ErrorHandling_notifiedListener], ErrorHandling_notifiedMessage, "when calling onError in ErrorHandling, line 48")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function bridge_code__startPeriodic_GameTimer() 
	wurst_stack[wurst_stack_depth] = "via function reference GameTimer, line 21"
	wurst_stack_depth = (wurst_stack_depth + 1)
	GameTimer_currentTime = (GameTimer_currentTime + Basics_ANIMATION_PERIOD)
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function bridge_initCompiletimeState_0() 
	wurst_stack[wurst_stack_depth] = "via ExecuteFunc in function initCompiletimeState"
	wurst_stack_depth = (wurst_stack_depth + 1)
	__wurst_InitHashtable()
	__wurst_InitHashtable()
	hashtable_compiletime1 = __wurst_InitHashtable()
	hashtable_compiletime = __wurst_InitHashtable()
	__wurst_SaveInteger(hashtable_compiletime1, 1, -242600650, 0)
	__wurst_SaveInteger(hashtable_compiletime1, 1, 1132341824, 1)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -647782241, 2)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -854572045, 3)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -680649701, 4)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -943650483, 5)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -671760605, 6)
	__wurst_SaveInteger(hashtable_compiletime1, 1, 349230650, 7)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1894922563, 8)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1474492777, 9)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1587459251, 10)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1676716706, 11)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1559655710, 12)
	__wurst_SaveInteger(hashtable_compiletime1, 1, -1663695754, 13)
	__wurst_SaveInteger(hashtable_compiletime1, 1, 597637742, 14)
	__wurst_SaveInteger(hashtable_compiletime1, 1, 789744696, 15)
	__wurst_SaveStr(hashtable_compiletime1, 2, 0, "")
	wurst_stack_depth = (wurst_stack_depth - 1)
end

function __wurst_GetEnumUnit() 
	if GetEnumUnit ~= nil then
	    local u = GetEnumUnit()
	    if u ~= nil then return u end
	end
	if __wurst_enumUnit_override ~= nil then return __wurst_enumUnit_override end
	return nil
end

function __wurst_ForGroup(whichGroup, callback) 
	if ForGroup == nil then return end
	local units = {}
	local count = 0
	local prev = __wurst_enumUnit_override
	ForGroup(whichGroup, function()
	    count = count + 1
	    units[count] = GetEnumUnit()
	end)
	for i = 1, count do
	    __wurst_enumUnit_override = units[i]
	    callback()
	end
	__wurst_enumUnit_override = prev
end

function __wurst_safe_IsUnitDeadBJ(whichUnit) 
	local whichUnitState = nil
	local inlineDone20 = nil
	local inlineRet17 = nil
	if (whichUnit == nil) then
		return false
	end
	whichUnitState = UNIT_STATE_LIFE
	inlineDone20 = false
	if (whichUnit == nil) then
		inlineRet17 = 0.0
		inlineDone20 = true
	end
	if not(inlineDone20) then
		if (whichUnitState == nil) then
			if not(inlineDone20) then
				inlineRet17 = 0.0
				inlineDone20 = true
			end
		end
	end
	if not(inlineDone20) then
		inlineRet17 = GetUnitState(whichUnit, whichUnitState)
		inlineDone20 = true
	end
	if not(inlineDone20) then
		inlineRet17 = 0.
	end
	return (inlineRet17 <= 0.)
end

function __wurst_ForForce(whichForce, callback) 
	if ForForce == nil then return end
	local players = {}
	local count = 0
	local prev = __wurst_enumPlayer_override
	ForForce(whichForce, function()
	    count = count + 1
	    players[count] = GetEnumPlayer()
	end)
	for i = 1, count do
	    __wurst_enumPlayer_override = players[i]
	    callback()
	end
	__wurst_enumPlayer_override = prev
end

function __wurst_InitHashtable() 
	return { __wurst_ht_int = {}, __wurst_ht_bool = {}, __wurst_ht_real = {}, __wurst_ht_str = {}, __wurst_ht_handle = {} }
end

function __wurst_SaveInteger(h, p, c, i) 
	local t = h.__wurst_ht_int
	if t == nil then t = {}; h.__wurst_ht_int = t end
	if not t[p] then t[p] = {} end t[p][c] = i
end

function __wurst_SaveBoolean(h, p, c, i) 
	local t = h.__wurst_ht_bool
	if t == nil then t = {}; h.__wurst_ht_bool = t end
	if not t[p] then t[p] = {} end t[p][c] = i
end

function __wurst_SaveStr(h, p, c, i) 
	local t = h.__wurst_ht_str
	if t == nil then t = {}; h.__wurst_ht_str = t end
	if not t[p] then t[p] = {} end t[p][c] = i
end

function __wurst_LoadInteger(h, p, c) 
	local t = h.__wurst_ht_int
	if t == nil or t[p] == nil then return 0 end
	local v = t[p][c]
	if v == nil then return 0 end
	return v
end

function __wurst_LoadBoolean(h, p, c) 
	local t = h.__wurst_ht_bool
	if t == nil or t[p] == nil then return false end
	local v = t[p][c]
	if v == nil then return false end
	return v
end

function __wurst_HaveSavedBoolean(h, p, c) 
	local t = h.__wurst_ht_bool
	return t ~= nil and t[p] ~= nil and t[p][c] ~= nil
end

function __wurst_HaveSavedInteger(h, p, c) 
	local t = h.__wurst_ht_int
	return t ~= nil and t[p] ~= nil and t[p][c] ~= nil
end

__wurst_bootstrap_done = nil

function __wurst_init_bootstrap() 
	if __wurst_bootstrap_done then return end
	__wurst_bootstrap_done = true
	__wurst_objectIndexMap = ({counter=0, })
	__wurst_number_wrapper_map = ({counter=0, })
	__wurst_string_index_map = ({counter=0, byString=({}), byIndex=({}), })
	Basics_ANIMATION_PERIOD = 0.
	Bootstrap_bootstrapOriginSelection = nil
	CampaignHandoff_HANDOFF_REQUEST = ""
	Colors_hexs = setmetatable(({}), __wurst_arrMt_string)
	Colors_decs = nil
	Colors_COLOR_WHITE_red = 0
	Colors_COLOR_WHITE_green = 0
	Colors_COLOR_WHITE_blue = 0
	Colors_COLOR_WHITE_alpha = 0
	Colors_COLOR_BLACK_red = 0
	Colors_COLOR_BLACK_green = 0
	Colors_COLOR_BLACK_blue = 0
	Colors_COLOR_BLACK_alpha = 0
	Colors_COLOR_GOLD_red = 0
	Colors_COLOR_GOLD_green = 0
	Colors_COLOR_GOLD_blue = 0
	Colors_COLOR_GOLD_alpha = 0
	CommandRouter_COMMAND_RELEASE = 0
	CommandRouter_active = nil
	CommandRouter_chatNatives = nil
	CommandRouter_chatListener = nil
	ErrorHandling_MUTE_ERROR_DURATION = 0
	ErrorHandling_PRIMARY_ERROR_KEY = 0
	ErrorHandling_HT = nil
	ErrorHandling_suppressErrorMessages = false
	ErrorHandling_errorListeners = ({})
	ErrorHandling_errorListenerCount = 0
	ErrorHandling_notifyingErrorListeners = false
	ErrorHandling_notifiedListener = 0
	ErrorHandling_notifiedMessage = ""
	ErrorHandling_errorListenerForce = nil
	GameTimer_currentTime = 0.
	MagicFunctions_compiletime = false
	Player_localPlayer = nil
	Printing_DEBUG_LEVEL = 0
	Printing_DEBUG_MSG_DURATION = 0.
	ScenarioSettings_CAMPAIGN_CACHE_FILE = ""
	ScenarioSettings_SCENARIO_BOOTSTRAP_MESSAGE = ""
	String_CONT_BYTE_PROBE = ""
	String_CONT_BYTE_MAP = nil
	String_charset = ""
	String_charsetlength = 0
	String_PRINTABLE_ASCII = ""
	String_CHAR_ORDER_MAP = nil
	String_NON_CHARSET_ORDER_BASE = 0
	Table_ht = nil
	TypeCasting_typecastdata = nil
	WC3Compatibility_WC3_COMPAT_PATCH_FAMILY = ""
	WC3Compatibility_WC3_COMPAT_SCRIPT_BACKEND = ""
	WC3Compatibility_WC3_HAS_MODERN_INVENTORY = false
	WC3Compatibility_WC3_HAS_NATIVE_SAVE_MANAGEMENT = false
	WC3Compatibility_WC3_HAS_FRAME_UI = false
	WC3Compatibility_WC3_HAS_PATHING_QUERIES = false
	WC3Compatibility_WC3_HAS_MODERN_UNIT_FIELDS = false
	hashtable_compiletime = nil
	hashtable_compiletime1 = nil
	wurst_stack_depth = 0
	wurst_stack = setmetatable(({}), __wurst_arrMt_string)
	CampaignHandoff.__wurst_dealloc = CampaignHandoff_dealloc
	CampaignStartRequest.__wurst_dealloc = CampaignStartRequest_dealloc
	PhysicalMapLoader.__wurst_dealloc = PhysicalMapLoader_dealloc
	WarcraftPhysicalMapLoader.__wurst_dealloc = WarcraftPhysicalMapLoader_dealloc
	CampaignSaveStorage.__wurst_dealloc = CampaignSaveStorage_dealloc
	WarcraftCampaignSaveStorage.__wurst_dealloc = WarcraftCampaignSaveStorage_dealloc
	Command.__wurst_dealloc = Command_dealloc
	CommandChatNatives.__wurst_dealloc = CommandChatNatives_dealloc
	CommandHandler.__wurst_dealloc = CommandHandler_dealloc
	CommandOutput.__wurst_dealloc = CommandOutput_dealloc
	CommandRegistry.__wurst_dealloc = CommandRegistry_dealloc
	CommandText.__wurst_dealloc = CommandText_dealloc
	NewCampaignOriginController.__wurst_dealloc = NewCampaignOriginController_dealloc
	OriginCatalog.__wurst_dealloc = OriginCatalog_dealloc
	OriginCommandHandler.__wurst_dealloc = OriginCommandHandler_dealloc
	OriginDefinition.__wurst_dealloc = OriginDefinition_dealloc
	OriginSelectionObserver.__wurst_dealloc = OriginSelectionObserver_dealloc
	OriginSelectionPresentation.__wurst_dealloc = OriginSelectionPresentation_dealloc
	PlayerCampaignIdentity.__wurst_dealloc = PlayerCampaignIdentity_dealloc
	WarcraftCommandChatNatives.__wurst_dealloc = WarcraftCommandChatNatives_dealloc
	WarcraftOriginPresentation.__wurst_dealloc = WarcraftOriginPresentation_dealloc
	WarcraftOutput.__wurst_dealloc = WarcraftOutput_dealloc
	ErrorListener.__wurst_dealloc = ErrorListener_dealloc
	Table.__wurst_dealloc = Table_dealloc
	CampaignHandoff.CampaignHandoff_CampaignHandoff_campaignStarted = CampaignHandoff_CampaignHandoff_campaignStarted
	CampaignHandoff.CampaignHandoff_CampaignHandoff_commitSelection = CampaignHandoff_CampaignHandoff_commitSelection
	CampaignHandoff.CampaignHandoff_CampaignHandoff_hasRequest = CampaignHandoff_CampaignHandoff_hasRequest
	CampaignHandoff.CampaignHandoff_CampaignHandoff_readRequest = CampaignHandoff_CampaignHandoff_readRequest
	CampaignHandoff.CampaignHandoff_campaignStarted = CampaignHandoff_CampaignHandoff_campaignStarted
	CampaignHandoff.CampaignHandoff_commitSelection = CampaignHandoff_CampaignHandoff_commitSelection
	CampaignHandoff.CampaignHandoff_hasRequest = CampaignHandoff_CampaignHandoff_hasRequest
	CampaignHandoff.CampaignHandoff_readRequest = CampaignHandoff_CampaignHandoff_readRequest
	CampaignHandoff.OriginSelectionObserver_CampaignHandoff_campaignStarted = CampaignHandoff_CampaignHandoff_campaignStarted
	CampaignHandoff.OriginSelectionObserver_CampaignHandoff_commitSelection = CampaignHandoff_CampaignHandoff_commitSelection
	CampaignHandoff.OriginSelectionObserver_campaignStarted = CampaignHandoff_CampaignHandoff_campaignStarted
	CampaignHandoff.OriginSelectionObserver_commitSelection = CampaignHandoff_CampaignHandoff_commitSelection
	CampaignHandoff.__wurst_supertypes = ({[CampaignHandoff] = true, [OriginSelectionObserver] = true, })
	CampaignHandoff.__typeId__ = 18
	CampaignStartRequest.CampaignStartRequest_CampaignStartRequest_encode = CampaignStartRequest_CampaignStartRequest_encode
	CampaignStartRequest.CampaignStartRequest_encode = CampaignStartRequest_CampaignStartRequest_encode
	CampaignStartRequest.__wurst_supertypes = ({[CampaignStartRequest] = true, })
	CampaignStartRequest.__typeId__ = 3
	PhysicalMapLoader.__wurst_supertypes = ({[PhysicalMapLoader] = true, })
	PhysicalMapLoader.__typeId__ = 21
	WarcraftPhysicalMapLoader.PhysicalMapLoader_PhysicalMapLoader_load = WarcraftPhysicalMapLoader_WarcraftPhysicalMapLoader_load
	WarcraftPhysicalMapLoader.PhysicalMapLoader_load = WarcraftPhysicalMapLoader_WarcraftPhysicalMapLoader_load
	WarcraftPhysicalMapLoader.WarcraftPhysicalMapLoader_PhysicalMapLoader_load = WarcraftPhysicalMapLoader_WarcraftPhysicalMapLoader_load
	WarcraftPhysicalMapLoader.WarcraftPhysicalMapLoader_load = WarcraftPhysicalMapLoader_WarcraftPhysicalMapLoader_load
	WarcraftPhysicalMapLoader.__wurst_supertypes = ({[WarcraftPhysicalMapLoader] = true, [PhysicalMapLoader] = true, })
	WarcraftPhysicalMapLoader.__typeId__ = 22
	CampaignSaveStorage.__wurst_supertypes = ({[CampaignSaveStorage] = true, })
	CampaignSaveStorage.__typeId__ = 1
	WarcraftCampaignSaveStorage.CampaignSaveStorage_CampaignSaveStorage_contains = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains
	WarcraftCampaignSaveStorage.CampaignSaveStorage_CampaignSaveStorage_read = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read
	WarcraftCampaignSaveStorage.CampaignSaveStorage_CampaignSaveStorage_writeTransactional = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_writeTransactional
	WarcraftCampaignSaveStorage.CampaignSaveStorage_contains = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains
	WarcraftCampaignSaveStorage.CampaignSaveStorage_read = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read
	WarcraftCampaignSaveStorage.CampaignSaveStorage_writeTransactional = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_writeTransactional
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_CampaignSaveStorage_contains = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_CampaignSaveStorage_read = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_CampaignSaveStorage_writeTransactional = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_writeTransactional
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_contains = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_contains
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_read = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_read
	WarcraftCampaignSaveStorage.WarcraftCampaignSaveStorage_writeTransactional = WarcraftCampaignSaveStorage_WarcraftCampaignSaveStorage_writeTransactional
	WarcraftCampaignSaveStorage.__wurst_supertypes = ({[WarcraftCampaignSaveStorage] = true, [CampaignSaveStorage] = true, })
	WarcraftCampaignSaveStorage.__typeId__ = 2
	Command.__wurst_supertypes = ({[Command] = true, })
	Command.__typeId__ = 4
	CommandChatNatives.__wurst_supertypes = ({[CommandChatNatives] = true, })
	CommandChatNatives.__typeId__ = 5
	CommandHandler.__wurst_supertypes = ({[CommandHandler] = true, })
	CommandHandler.__typeId__ = 7
	CommandOutput.__wurst_supertypes = ({[CommandOutput] = true, })
	CommandOutput.__typeId__ = 9
	CommandRegistry.CommandRegistry_CommandRegistry_dispatch = CommandRegistry_CommandRegistry_dispatch
	CommandRegistry.CommandRegistry_CommandRegistry_find = CommandRegistry_CommandRegistry_find
	CommandRegistry.CommandRegistry_CommandRegistry_help = CommandRegistry_CommandRegistry_help
	CommandRegistry.CommandRegistry_CommandRegistry_helpPage = CommandRegistry_CommandRegistry_helpPage
	CommandRegistry.CommandRegistry_CommandRegistry_pages = CommandRegistry_CommandRegistry_pages
	CommandRegistry.CommandRegistry_CommandRegistry_register = CommandRegistry_CommandRegistry_register
	CommandRegistry.CommandRegistry_CommandRegistry_visible = CommandRegistry_CommandRegistry_visible
	CommandRegistry.CommandRegistry_CommandRegistry_visibleCount = CommandRegistry_CommandRegistry_visibleCount
	CommandRegistry.CommandRegistry_dispatch = CommandRegistry_CommandRegistry_dispatch
	CommandRegistry.CommandRegistry_find = CommandRegistry_CommandRegistry_find
	CommandRegistry.CommandRegistry_help = CommandRegistry_CommandRegistry_help
	CommandRegistry.CommandRegistry_helpPage = CommandRegistry_CommandRegistry_helpPage
	CommandRegistry.CommandRegistry_pages = CommandRegistry_CommandRegistry_pages
	CommandRegistry.CommandRegistry_register = CommandRegistry_CommandRegistry_register
	CommandRegistry.CommandRegistry_visible = CommandRegistry_CommandRegistry_visible
	CommandRegistry.CommandRegistry_visibleCount = CommandRegistry_CommandRegistry_visibleCount
	CommandRegistry.__wurst_supertypes = ({[CommandRegistry] = true, })
	CommandRegistry.__typeId__ = 11
	CommandText.__wurst_supertypes = ({[CommandText] = true, })
	CommandText.__typeId__ = 12
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_choose = NewCampaignOriginController_NewCampaignOriginController_choose
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_matchCount = NewCampaignOriginController_NewCampaignOriginController_matchCount
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_pages = NewCampaignOriginController_NewCampaignOriginController_pages
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_search = NewCampaignOriginController_NewCampaignOriginController_search
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_setObserver = NewCampaignOriginController_NewCampaignOriginController_setObserver
	NewCampaignOriginController.NewCampaignOriginController_NewCampaignOriginController_showPage = NewCampaignOriginController_NewCampaignOriginController_showPage
	NewCampaignOriginController.NewCampaignOriginController_add = OriginCatalog_OriginCatalog_add
	NewCampaignOriginController.NewCampaignOriginController_choose = NewCampaignOriginController_NewCampaignOriginController_choose
	NewCampaignOriginController.NewCampaignOriginController_find = OriginCatalog_OriginCatalog_find
	NewCampaignOriginController.NewCampaignOriginController_matchCount = NewCampaignOriginController_NewCampaignOriginController_matchCount
	NewCampaignOriginController.NewCampaignOriginController_pages = NewCampaignOriginController_NewCampaignOriginController_pages
	NewCampaignOriginController.NewCampaignOriginController_search = NewCampaignOriginController_NewCampaignOriginController_search
	NewCampaignOriginController.NewCampaignOriginController_setObserver = NewCampaignOriginController_NewCampaignOriginController_setObserver
	NewCampaignOriginController.NewCampaignOriginController_setPosition = OriginCatalog_OriginCatalog_setPosition
	NewCampaignOriginController.NewCampaignOriginController_showPage = NewCampaignOriginController_NewCampaignOriginController_showPage
	NewCampaignOriginController.OriginCatalog_OriginCatalog_add = OriginCatalog_OriginCatalog_add
	NewCampaignOriginController.OriginCatalog_OriginCatalog_find = OriginCatalog_OriginCatalog_find
	NewCampaignOriginController.OriginCatalog_OriginCatalog_setPosition = OriginCatalog_OriginCatalog_setPosition
	NewCampaignOriginController.OriginCatalog_add = OriginCatalog_OriginCatalog_add
	NewCampaignOriginController.OriginCatalog_choose = NewCampaignOriginController_NewCampaignOriginController_choose
	NewCampaignOriginController.OriginCatalog_find = OriginCatalog_OriginCatalog_find
	NewCampaignOriginController.OriginCatalog_matchCount = NewCampaignOriginController_NewCampaignOriginController_matchCount
	NewCampaignOriginController.OriginCatalog_pages = NewCampaignOriginController_NewCampaignOriginController_pages
	NewCampaignOriginController.OriginCatalog_search = NewCampaignOriginController_NewCampaignOriginController_search
	NewCampaignOriginController.OriginCatalog_setObserver = NewCampaignOriginController_NewCampaignOriginController_setObserver
	NewCampaignOriginController.OriginCatalog_setPosition = OriginCatalog_OriginCatalog_setPosition
	NewCampaignOriginController.OriginCatalog_showPage = NewCampaignOriginController_NewCampaignOriginController_showPage
	NewCampaignOriginController.__wurst_supertypes = ({[NewCampaignOriginController] = true, [OriginCatalog] = true, })
	NewCampaignOriginController.__typeId__ = 15
	OriginCatalog.OriginCatalog_OriginCatalog_add = OriginCatalog_OriginCatalog_add
	OriginCatalog.OriginCatalog_OriginCatalog_find = OriginCatalog_OriginCatalog_find
	OriginCatalog.OriginCatalog_OriginCatalog_setPosition = OriginCatalog_OriginCatalog_setPosition
	OriginCatalog.OriginCatalog_add = OriginCatalog_OriginCatalog_add
	OriginCatalog.OriginCatalog_find = OriginCatalog_OriginCatalog_find
	OriginCatalog.OriginCatalog_setPosition = OriginCatalog_OriginCatalog_setPosition
	OriginCatalog.__wurst_supertypes = ({[OriginCatalog] = true, })
	OriginCatalog.__typeId__ = 14
	OriginCommandHandler.CommandHandler_CommandHandler_execute = OriginCommandHandler_OriginCommandHandler_execute
	OriginCommandHandler.CommandHandler_execute = OriginCommandHandler_OriginCommandHandler_execute
	OriginCommandHandler.OriginCommandHandler_CommandHandler_execute = OriginCommandHandler_OriginCommandHandler_execute
	OriginCommandHandler.OriginCommandHandler_execute = OriginCommandHandler_OriginCommandHandler_execute
	OriginCommandHandler.__wurst_supertypes = ({[OriginCommandHandler] = true, [CommandHandler] = true, })
	OriginCommandHandler.__typeId__ = 8
	OriginDefinition.__wurst_supertypes = ({[OriginDefinition] = true, })
	OriginDefinition.__typeId__ = 16
	OriginSelectionObserver.__wurst_supertypes = ({[OriginSelectionObserver] = true, })
	OriginSelectionObserver.__typeId__ = 17
	OriginSelectionPresentation.__wurst_supertypes = ({[OriginSelectionPresentation] = true, })
	OriginSelectionPresentation.__typeId__ = 19
	PlayerCampaignIdentity.PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin = PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin
	PlayerCampaignIdentity.PlayerCampaignIdentity_hasOrigin = PlayerCampaignIdentity_PlayerCampaignIdentity_hasOrigin
	PlayerCampaignIdentity.__wurst_supertypes = ({[PlayerCampaignIdentity] = true, })
	PlayerCampaignIdentity.__typeId__ = 23
	WarcraftCommandChatNatives.CommandChatNatives_CommandChatNatives_eventListener = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventListener
	WarcraftCommandChatNatives.CommandChatNatives_CommandChatNatives_eventPlayer = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventPlayer
	WarcraftCommandChatNatives.CommandChatNatives_CommandChatNatives_eventText = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventText
	WarcraftCommandChatNatives.CommandChatNatives_CommandChatNatives_registerChat = WarcraftCommandChatNatives_WarcraftCommandChatNatives_registerChat
	WarcraftCommandChatNatives.CommandChatNatives_CommandChatNatives_retire = WarcraftCommandChatNatives_WarcraftCommandChatNatives_retire
	WarcraftCommandChatNatives.CommandChatNatives_eventListener = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventListener
	WarcraftCommandChatNatives.CommandChatNatives_eventPlayer = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventPlayer
	WarcraftCommandChatNatives.CommandChatNatives_eventText = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventText
	WarcraftCommandChatNatives.CommandChatNatives_registerChat = WarcraftCommandChatNatives_WarcraftCommandChatNatives_registerChat
	WarcraftCommandChatNatives.CommandChatNatives_retire = WarcraftCommandChatNatives_WarcraftCommandChatNatives_retire
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_CommandChatNatives_eventListener = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventListener
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_CommandChatNatives_eventPlayer = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventPlayer
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_CommandChatNatives_eventText = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventText
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_CommandChatNatives_registerChat = WarcraftCommandChatNatives_WarcraftCommandChatNatives_registerChat
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_CommandChatNatives_retire = WarcraftCommandChatNatives_WarcraftCommandChatNatives_retire
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_eventListener = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventListener
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_eventPlayer = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventPlayer
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_eventText = WarcraftCommandChatNatives_WarcraftCommandChatNatives_eventText
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_registerChat = WarcraftCommandChatNatives_WarcraftCommandChatNatives_registerChat
	WarcraftCommandChatNatives.WarcraftCommandChatNatives_retire = WarcraftCommandChatNatives_WarcraftCommandChatNatives_retire
	WarcraftCommandChatNatives.__wurst_supertypes = ({[WarcraftCommandChatNatives] = true, [CommandChatNatives] = true, })
	WarcraftCommandChatNatives.__typeId__ = 6
	WarcraftOriginPresentation.OriginSelectionPresentation_OriginSelectionPresentation_close = WarcraftOriginPresentation_WarcraftOriginPresentation_close
	WarcraftOriginPresentation.OriginSelectionPresentation_OriginSelectionPresentation_show = WarcraftOriginPresentation_WarcraftOriginPresentation_show
	WarcraftOriginPresentation.OriginSelectionPresentation_OriginSelectionPresentation_showError = WarcraftOriginPresentation_WarcraftOriginPresentation_showError
	WarcraftOriginPresentation.OriginSelectionPresentation_close = WarcraftOriginPresentation_WarcraftOriginPresentation_close
	WarcraftOriginPresentation.OriginSelectionPresentation_show = WarcraftOriginPresentation_WarcraftOriginPresentation_show
	WarcraftOriginPresentation.OriginSelectionPresentation_showError = WarcraftOriginPresentation_WarcraftOriginPresentation_showError
	WarcraftOriginPresentation.WarcraftOriginPresentation_OriginSelectionPresentation_close = WarcraftOriginPresentation_WarcraftOriginPresentation_close
	WarcraftOriginPresentation.WarcraftOriginPresentation_OriginSelectionPresentation_show = WarcraftOriginPresentation_WarcraftOriginPresentation_show
	WarcraftOriginPresentation.WarcraftOriginPresentation_OriginSelectionPresentation_showError = WarcraftOriginPresentation_WarcraftOriginPresentation_showError
	WarcraftOriginPresentation.WarcraftOriginPresentation_close = WarcraftOriginPresentation_WarcraftOriginPresentation_close
	WarcraftOriginPresentation.WarcraftOriginPresentation_show = WarcraftOriginPresentation_WarcraftOriginPresentation_show
	WarcraftOriginPresentation.WarcraftOriginPresentation_showError = WarcraftOriginPresentation_WarcraftOriginPresentation_showError
	WarcraftOriginPresentation.__wurst_supertypes = ({[WarcraftOriginPresentation] = true, [OriginSelectionPresentation] = true, })
	WarcraftOriginPresentation.__typeId__ = 20
	WarcraftOutput.CommandOutput_CommandOutput_show = WarcraftOutput_WarcraftOutput_show
	WarcraftOutput.CommandOutput_show = WarcraftOutput_WarcraftOutput_show
	WarcraftOutput.WarcraftOutput_CommandOutput_show = WarcraftOutput_WarcraftOutput_show
	WarcraftOutput.WarcraftOutput_show = WarcraftOutput_WarcraftOutput_show
	WarcraftOutput.__wurst_supertypes = ({[WarcraftOutput] = true, [CommandOutput] = true, })
	WarcraftOutput.__typeId__ = 10
	ErrorListener.__wurst_supertypes = ({[ErrorListener] = true, })
	ErrorListener.__typeId__ = 13
	Table.Table_Table_saveString = Table_Table_saveString
	Table.Table_saveString = Table_Table_saveString
	Table.__wurst_supertypes = ({[Table] = true, })
	Table.__typeId__ = 24
end

